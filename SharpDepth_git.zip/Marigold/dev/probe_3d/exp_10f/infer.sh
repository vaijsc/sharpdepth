export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
ckpt=${1:-"../marigold_exp/training/probe_3d/10f_2/train_marigold/checkpoint/iter_010500/"}
subfolder=${2:-"eval"}

source activate mvsplat 
pip install -U setuptools
cd ../UniDepth
pip install -e .
cd -

PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/probe_3d/exp_10f/infer_reprod.py  \
    --weights $ckpt \
    --seed 1234 \
    --config dev/probe_3d/exp_10f/configs/train_marigold.yaml \
    --base_data_dir $BASE_DATA_DIR \
    --dataset_config config/dataset/data_nyu_test.yaml \
    --output_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/${subfolder}/dev/probe_3d/10f_2/nyuv2/prediction \
