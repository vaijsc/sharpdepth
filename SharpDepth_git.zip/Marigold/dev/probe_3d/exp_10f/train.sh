export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
source activate mvsplat 
pip install -U setuptools
cd ../UniDepth
pip install -e .
cd -
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/probe_3d/exp_10f/train.py --config dev/probe_3d/exp_10f/configs/train_marigold.yaml --output_dir ../marigold_exp/training/probe_3d/10f_2 --do_not_copy_data --no_wandb \
--base_ckpt_dir prs-eth --resume_run ../marigold_exp/training/probe_3d/10f_2/train_marigold/checkpoint/latest/