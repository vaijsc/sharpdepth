import logging
import os
import warnings
import argparse

import diffusers
import numpy as np
import torch
import torch.nn.functional as F
from diffusers import DDIMScheduler, MarigoldDepthPipeline
from PIL import Image

warnings.simplefilter(action="ignore", category=FutureWarning)
diffusers.utils.logging.disable_progress_bar()


def sig_loss(depth_pr, depth_gt, mask, sigma=0.85, eps=0.001, only_mean=False):
    """
    SigLoss
        This follows `AdaBins <https://arxiv.org/abs/2011.14141>`_.
        adapated from DINOv2 code

    Args:
        depth_pr (FloatTensor): predicted depth
        depth_gt (FloatTensor): groundtruth depth
        eps (float): to avoid exploding gradient
    """
    # ignore invalid depth pixels
    valid = mask
    depth_pr = depth_pr[valid]
    depth_gt = depth_gt[valid]

    g = torch.log(depth_pr + eps) - torch.log(depth_gt + eps)

    loss = g.pow(2).mean() - sigma * g.mean().pow(2)
    loss = loss.sqrt()
    return loss


class SparseGuidancePipeline(MarigoldDepthPipeline):
    """
    Pipeline for Marigold Depth Completion.
    Extends the MarigoldDepthPipeline to include depth completion functionality.
    """
    def __call__(
        self, image: Image.Image, sparse_depth: np.ndarray,
        num_inference_steps: int = 50, processing_resolution: int = 768, seed: int = 2024
    ) -> np.ndarray:
        
        """
        Args:
            image (PIL.Image.Image): Input image of shape [H, W] with 3 channels.
            sparse_depth (np.ndarray): Sparse depth guidance of shape [H, W].
            num_inference_steps (int, optional): Number of denoising steps. Defaults to 50.
            processing_resolution (int, optional): Resolution for processing. Defaults to 768.
            seed (int, optional): Random seed. Defaults to 2024.

        Returns:
            np.ndarray: Dense depth prediction of shape [H, W].

        """
        # Resolving variables
        device = self._execution_device
        generator = torch.Generator(device=device).manual_seed(seed)

        # Check inputs.
        if num_inference_steps is None:
            raise ValueError("Invalid num_inference_steps")
        if type(sparse_depth) is not np.ndarray or sparse_depth.ndim != 2:
            raise ValueError("Sparse depth should be a 2D numpy ndarray with zeros at missing positions")

        # Prepare empty text conditioning
        with torch.no_grad():
            if self.empty_text_embedding is None:
                text_inputs = self.tokenizer("", padding="do_not_pad", 
                    max_length=self.tokenizer.model_max_length, truncation=True, return_tensors="pt")
                text_input_ids = text_inputs.input_ids.to(device)
                self.empty_text_embedding = self.text_encoder(text_input_ids)[0]  # [1,2,1024]

        # Preprocess input images
        image, padding, original_resolution = self.image_processor.preprocess(
            image, processing_resolution=processing_resolution, device=device, dtype=self.dtype
        )  # [N,3,PPH,PPW]

        # Check sparse depth dimensions
        if sparse_depth.shape != original_resolution:
            raise ValueError(
                f"Sparse depth dimensions ({sparse_depth.shape}) must match that of the image ({image.shape[-2:]})"
            )
        
        # Encode input image into latent space
        with torch.no_grad():
            image_latent, pred_latent = self.prepare_latents(image, None, generator, 1, 1)  # [N*E,4,h,w], [N*E,4,h,w]
        del image

        # Preprocess sparse depth
        sparse_depth = torch.from_numpy(sparse_depth)[None, None].float().to(device)
        sparse_mask = sparse_depth > 0
        logging.info(f"Using {sparse_mask.int().sum().item()} guidance points")

        # pred_latent = torch.nn.Parameter(pred_latent)
        sparse_range = (sparse_depth[sparse_mask].max() - sparse_depth[sparse_mask].min()).item() # (cmax − cmin)
        sparse_lower = (sparse_depth[sparse_mask].min()).item() # cmin
        
        def affine_to_metric(depth: torch.Tensor) -> torch.Tensor:
            # Convert affine invariant depth predictions to metric depth predictions using the parametrized scale and shift. See Equation 2 of the paper.
            return sparse_range * depth + sparse_lower

        def loss_l1l2(input: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
            # Compute L1 and L2 loss between input and target.
            out_l1 = torch.nn.functional.l1_loss(input, target)
            out_l2 = torch.nn.functional.mse_loss(input, target)
            out = out_l1 + out_l2
            return out

        def latent_to_metric(latent: torch.Tensor) -> torch.Tensor:
            # Decode latent to affine invariant depth predictions and subsequently to metric depth predictions.
            affine_invariant_prediction = self.decode_prediction(latent)  # [E,1,PPH,PPW]
            prediction = affine_to_metric(affine_invariant_prediction)
            prediction = self.image_processor.unpad_image(prediction, padding)  # [E,1,PH,PW]
            prediction = self.image_processor.resize_antialias(
                prediction, original_resolution, "bilinear", is_aa=False
            )  # [1,1,H,W]
            return prediction


        alphas_cumprod = self.scheduler.alphas_cumprod
        alphas_cumprod = alphas_cumprod.to(device)

        image_latent_curr = image_latent
        # Denoising loop
        self.scheduler.set_timesteps(num_inference_steps, device=device)
        for i, t in enumerate(
            self.progress_bar(self.scheduler.timesteps, desc=f"Marigold-DC steps ({str(device)})...")
        ):
            image_latent_sds = image_latent.clone().detach()
            image_latent_curr = image_latent_curr.clone().detach()
            pred_latent_curr = pred_latent.clone().detach()
            image_latent_curr.requires_grad = True
            optimizer = torch.optim.Adam([image_latent_curr], lr=1e-2 * (1. - i / 100.))


            for j in range(2):
                # Forward pass through the U-Net
                batch_latent = torch.cat([image_latent_curr, pred_latent_curr], dim=1)  # [1,8,h,w]
                noise = self.unet(batch_latent, t, encoder_hidden_states=self.empty_text_embedding, return_dict=False)[0]  # [1,4,h,w]

                step_output = self.scheduler.step(noise, t, pred_latent_curr, generator=generator)
                # Preview the final output depth with Tweedie's formula (See Equation 1 of the paper)
                pred_original_sample = step_output.pred_original_sample

                # Decode to metric space, compute loss with guidance and backpropagate
                current_metric_estimate = latent_to_metric(pred_original_sample)
                loss_recons = loss_l1l2(current_metric_estimate[sparse_mask], sparse_depth[sparse_mask])
                # loss_recons = sig_loss(current_metric_estimate, sparse_depth, sparse_mask)
                
                # Add SDS Loss 
                # score_grads = []
                timesteps_range = torch.tensor([0.02, 0.98]) * self.scheduler.config.num_train_timesteps
                timesteps = torch.randint(*timesteps_range.long(), (batch_latent.shape[0],), device=device).long()

                randn_noise = torch.randn_like(pred_latent_curr)
                noisy_samples = self.scheduler.add_noise(pred_latent_curr, randn_noise, timesteps)
                unet_input = torch.cat([image_latent_sds, noisy_samples], dim=1)  # this order is important
                    
                with torch.no_grad():
                    unet_pred = self.unet(unet_input, t, encoder_hidden_states=self.empty_text_embedding).sample
                    
                    # ----------------------------------------------------------
                    # convert v-prediction to e-prediction
                    sqrt_alpha_prod = alphas_cumprod[timesteps] ** 0.5
                    sqrt_alpha_prod = sqrt_alpha_prod.flatten()
                    while len(sqrt_alpha_prod.shape) < len(noisy_samples.shape):
                        sqrt_alpha_prod = sqrt_alpha_prod.unsqueeze(-1)
                    sqrt_one_minus_alpha_prod = (1 - alphas_cumprod[timesteps]) ** 0.5
                    sqrt_one_minus_alpha_prod = sqrt_one_minus_alpha_prod.flatten()
                    while len(sqrt_one_minus_alpha_prod.shape) < len(noisy_samples.shape):
                        sqrt_one_minus_alpha_prod = sqrt_one_minus_alpha_prod.unsqueeze(-1)
                    noise_pred = sqrt_alpha_prod * unet_pred + sqrt_one_minus_alpha_prod * noisy_samples
                    # ----------------------------------------------------------

                sigma_t = ((1 - alphas_cumprod[timesteps]) ** 0.5).view(-1, 1, 1, 1)
                score_gradient = torch.nan_to_num(sigma_t**2 * (noise_pred - randn_noise))
                # score_grads.append(score_gradient)

                # Compute the SDS loss for the model
                target = (pred_latent_curr - score_gradient).detach()
                sds_loss = 0.5 * F.mse_loss(pred_latent_curr, target, reduction="mean")
                # sds_loss = torch.tensor(0.0).to(device)
                
                # print(f'SDS: {sds_loss}, Recons: {loss_recons}')
                loss = sds_loss + loss_recons*0.8

                # Execute the update step through guidance backprop
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            with torch.no_grad():
                # compute the previous noisy sample x_t -> x_t-1
                batch_latent = torch.cat([image_latent_curr, pred_latent_curr], dim=1)  # [1,8,h,w]
                noise = self.unet(batch_latent, t, encoder_hidden_states=self.empty_text_embedding, return_dict=False)[0] 
                pred_latent = self.scheduler.step(noise, t, pred_latent, generator=generator).prev_sample

            # del pred_original_sample, current_metric_estimate, step_output, 
            # torch.cuda.empty_cache()

        del image_latent

        # Decode predictions from latent into pixel space
        with torch.no_grad():
            prediction = latent_to_metric(pred_latent.detach())

        # return Numpy array
        prediction = self.image_processor.pt_to_numpy(prediction)  # [N,H,W,1]
        self.maybe_free_model_hooks()

        return prediction.squeeze()
    

def main():
    parser = argparse.ArgumentParser(description="Marigold-DC Pipeline")

    DEPTH_CHECKPOINT = "prs-eth/marigold-depth-v1-0"
    parser.add_argument("--in-image", type=str, default="data/image.png", help="Input image")
    parser.add_argument("--in-depth", type=str, default="data/sparse_100.npy", help="Input sparse depth")
    parser.add_argument("--out-depth", type=str, default="data/dense_100.npy", help="Output dense depth")
    parser.add_argument("--num_inference_steps", type=int, default=50, help="Denoising steps")
    parser.add_argument("--processing_resolution", type=int, default=768, help="Denoising resolution")
    parser.add_argument("--checkpoint", type=str, default=DEPTH_CHECKPOINT, help="Depth checkpoint")
    args = parser.parse_args()

    num_inference_steps = args.num_inference_steps
    processing_resolution = args.processing_resolution
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        if torch.backends.mps.is_available():
            device = torch.device("mps")
        else:
            device = torch.device("cpu")
        processing_resolution_non_cuda = 512
        num_inference_steps_non_cuda = 10
        if processing_resolution > processing_resolution_non_cuda:
            logging.warning(f"CUDA not found: Reducing processing_resolution to {processing_resolution_non_cuda}")
            processing_resolution = processing_resolution_non_cuda
        if num_inference_steps > num_inference_steps_non_cuda:
            logging.warning(f"CUDA not found: Reducing num_inference_steps to {num_inference_steps_non_cuda}")
            num_inference_steps = num_inference_steps_non_cuda

    pipe = MarigoldDepthCompletionPipeline.from_pretrained(args.checkpoint, prediction_type="depth").to(device)
    pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config, timestep_spacing="trailing")

    if not torch.cuda.is_available():
        logging.warning("CUDA not found: Using a lightweight VAE")
        del pipe.vae
        pipe.vae = diffusers.AutoencoderTiny.from_pretrained("madebyollin/taesd").to(device)

    pred = pipe(
        image=Image.open(args.in_image),
        sparse_depth=np.load(args.in_depth),
        num_inference_steps=num_inference_steps,
        processing_resolution=processing_resolution,
    )

    np.save(args.out_depth, pred)
    vis = pipe.image_processor.visualize_depth(pred, val_min=pred.min(), val_max=pred.max())[0]
    vis.save(os.path.splitext(args.out_depth)[0] + "_vis.jpg")


if __name__ == "__main__":
    main()