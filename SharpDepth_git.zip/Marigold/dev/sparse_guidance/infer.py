import argparse
import logging
import os
import shutil
from datetime import datetime, timedelta
from typing import List
from pathlib import Path
from packaging import version
import math
import itertools
import numpy as np
from PIL import Image

from tqdm import tqdm
from omegaconf import OmegaConf

import torch
import torch.nn.functional as F
import torchvision
from torch.utils.data import ConcatDataset, DataLoader

from src.dataset import BaseDepthDataset, DatasetMode, get_dataset
from src.dataset.mixed_sampler import MixedBatchSampler
from src.trainer import get_trainer_cls
from src.util.logging_util import config_logging
from src.util.config_util import (
                                    find_value_in_omegaconf,
                                    recursive_load_config,
                                )
from src.util.depth_transform import (
                                        DepthNormalizerBase,
                                        get_depth_normalizer,
                                    )
from src.util.slurm_util import get_local_scratch_dir, is_on_slurm


import transformers
from transformers import AutoTokenizer, PretrainedConfig

import diffusers
from diffusers import UNet2DConditionModel, DDPMScheduler, AutoencoderKL
from diffusers.utils.import_utils import is_xformers_available
from diffusers.utils.torch_utils import is_compiled_module
from diffusers.optimization import get_scheduler
from diffusers.training_utils import EMAModel
from ema_pytorch import EMA

from accelerate.logging import get_logger
from accelerate import Accelerator, DataLoaderConfiguration
from accelerate.utils import ProjectConfiguration, set_seed

# for visualization
from src.util.metric import *
from src.util.alignment import *
import matplotlib.pyplot as plt
import matplotlib
from marigold.util.image_util import (
                                            chw2hwc,
                                            colorize_depth_maps,
                                            get_tv_resample_method,
                                            resize_max_res,
                                        )
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from dev.sparse_guidance.sparse_guidance import *

logger = get_logger(__name__)

def to_gpu(ob, device):
    if isinstance(ob, dict):
        return {k: to_gpu(v, device) for k, v in ob.items()}
    elif isinstance(ob, tuple):
        return tuple(to_gpu(k, device) for k in ob)
    elif isinstance(ob, list):
        return [to_gpu(k, device) for k in ob]
    else:
        try:
            return ob.to(device)
        except Exception:
            return ob


if "__main__" == __name__:
    t_start = datetime.now()
    print(f"start at {t_start}")

    # -------------------- Arguments --------------------
    parser = argparse.ArgumentParser(description="Run single-image depth estimation using Marigold")
    DEPTH_CHECKPOINT = "prs-eth/marigold-depth-v1-0"
    parser.add_argument(
        "--config",
        type=str,
        default="prs-eth/marigold-v1-0",
        help="sth.",
    )
    parser.add_argument("--use_ema", action="store_true", help="Whether to use EMA model.")
    # dataset setting
    parser.add_argument(
        "--dataset_config",
        type=str,
        required=True,
        help="Path to config file of evaluation dataset.",
    )

    parser.add_argument(
        "--base_data_dir", type=str, default=None, help="directory of training data"
    )
    parser.add_argument(
        "--base_ckpt_dir",
        type=str,
        default=None,
        help="directory of pretrained checkpoint",
    )

    parser.add_argument(
        "--output_dir", type=str, required=True, help="Output directory."
    )

    parser.add_argument("--seed", type=int, default=None, help="Random seed.")
    parser.add_argument("--num_inference_steps", type=int, default=50, help="Denoising steps")
    parser.add_argument("--processing_resolution", type=int, default=768, help="Denoising resolution")
    parser.add_argument("--checkpoint", type=str, default=DEPTH_CHECKPOINT, help="Depth checkpoint")

    args = parser.parse_args()
    checkpoint_path = args.checkpoint
    output_dir = args.output_dir

    base_data_dir = (
        args.base_data_dir
        if args.base_data_dir is not None
        else os.environ["BASE_DATA_DIR"]
    )



    # -------------------- Initialization --------------------
    dataset_config = args.dataset_config    
    cfg_data = OmegaConf.load(dataset_config)

    # Full job name
    def check_directory(directory):
        if os.path.exists(directory):
            response = (
                input(
                    f"The directory '{directory}' already exists. Are you sure to continue? (y/n): "
                )
                .strip()
                .lower()
            )
            if "y" == response:
                pass
            elif "n" == response:
                print("Exiting...")
                exit()
            else:
                print("Invalid input. Please enter 'y' (for Yes) or 'n' (for No).")
                check_directory(directory)  # Recursive call to ask again

    # check_directory(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    logging.info(f"output dir = {output_dir}")


    # -------------------- set seed --------------------
    if args.seed is not None:
        set_seed(args.seed)
    # ---------------------------------------------------------------------

    # -------------------- Device --------------------
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
        logging.warning("CUDA is not available. Running on CPU will be slow.")
    logging.info(f"device = {device}")


    # -------------------- Create dataset --------------------
    if args.seed is None:
        loader_generator = None
    else:
        loader_generator = torch.Generator().manual_seed(args.seed)

    dataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )
    dataloader = DataLoader(dataset, batch_size=1, num_workers=0)

    num_inference_steps = args.num_inference_steps
    processing_resolution = args.processing_resolution
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        if torch.backends.mps.is_available():
            device = torch.device("mps")
        else:
            device = torch.device("cpu")
        processing_resolution_non_cuda = 512
        num_inference_steps_non_cuda = 10
        if processing_resolution > processing_resolution_non_cuda:
            logging.warning(f"CUDA not found: Reducing processing_resolution to {processing_resolution_non_cuda}")
            processing_resolution = processing_resolution_non_cuda
        if num_inference_steps > num_inference_steps_non_cuda:
            logging.warning(f"CUDA not found: Reducing num_inference_steps to {num_inference_steps_non_cuda}")
            num_inference_steps = num_inference_steps_non_cuda

    pipe = SparseGuidancePipeline.from_pretrained(args.checkpoint, prediction_type="depth").to(device)
    pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config, timestep_spacing="trailing")

    if not torch.cuda.is_available():
        logging.warning("CUDA not found: Using a lightweight VAE")
        del pipe.vae
        pipe.vae = diffusers.AutoencoderTiny.from_pretrained("madebyollin/taesd").to(device)

    # -------------------- Inference and saving --------------------
    for batch in tqdm(
        dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
    ):
        batch           = to_gpu(batch, device)
        rgb             = batch["rgb_int"][:, :3, :, :]             # rgn in range [-1, 1]
        depth_unidepth  = batch['depth_filled_linear']  # unidepth in meters
        sky_mask        = batch['valid_mask_filled'] 

        
        rgb_np = rgb.squeeze().permute(1,2,0).cpu().numpy().astype(np.uint8)
        depth_np = depth_unidepth.squeeze().cpu().numpy()
        pred = pipe(
            image=Image.fromarray(rgb_np),
            sparse_depth=depth_np,
            num_inference_steps=num_inference_steps,
            processing_resolution=processing_resolution,
        )
        gt = batch['depth_raw_linear'].squeeze()
        valid = batch['valid_mask_raw'].squeeze()
        pred_ = torch.from_numpy(pred).to(device)

        mae_score = mae(pred_, gt, valid)
        print(mae_score)

        # Save predictions
        rgb_filename = batch["rgb_relative_path"][0]
        rgb_basename = os.path.basename(rgb_filename)
        scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
        if not os.path.exists(scene_dir):
            os.makedirs(scene_dir)
        pred_basename = get_pred_name(rgb_basename, dataset.name_mode, suffix=".npy")
        save_to = os.path.join(scene_dir, pred_basename)
        if os.path.exists(save_to):
            logging.warning(f"Existing file: '{save_to}' will be overwritten")

        np.save(save_to, pred)
