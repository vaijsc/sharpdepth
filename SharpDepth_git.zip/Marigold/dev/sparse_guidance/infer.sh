export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

export OUT_DIR=../marigold_exp/eval/dev/sparse_guidance/demo_recons_w08_2iter/nyu_dc/prediction 
export EVAL_DIR=../marigold_exp/eval/dev/sparse_guidance/demo_recons_w08_2iter/nyu_dc/eval_metric

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

# python dev/sparse_guidance/infer.py \
#         --base_data_dir $BASE_DATA_DIR \
#         --dataset_config config/dataset/data_kitti_eigen_test_dc.yaml \
#         --output_dir $OUT_DIR \


python dev/sparse_guidance/infer.py \
        --base_data_dir $BASE_DATA_DIR \
        --dataset_config config/dataset/data_nyu_test.yaml \
        --output_dir $OUT_DIR \

