#!/usr/bin/env bash
set -e
set -x

# Use specified checkpoint path, otherwise, default value
ckpt=${1:-"stabilityai/stable-diffusion-2-1-base"}
subfolder=${2:-"eval"}

export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/

python infer_reprod.py  \
    --checkpoint $ckpt \
    --weights ../marigold_exp/training/vkitti_only/0e/train_marigold/checkpoint/latest \
    --seed 1234 \
    --base_data_dir $BASE_DATA_DIR \
    --denoise_steps 50 \
    --ensemble_size 10 \
    --processing_res 0 \
    --dataset_config config/dataset/data_kitti_eigen_test.yaml \
    --output_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/${subfolder}/kitti_eigen_test_full_0e/prediction \
