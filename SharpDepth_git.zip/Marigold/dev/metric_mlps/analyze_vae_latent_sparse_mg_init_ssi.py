from omegaconf import OmegaConf
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)
from torch.utils.data import DataLoader
from src.util.depth_transform import (
    DepthNormalizerBase,
    get_depth_normalizer,
)
from src.util.config_util import (
    find_value_in_omegaconf,
    recursive_load_config,
)
import torch
from diffusers import AutoencoderKL, UNet2DConditionModel, PNDMScheduler
from src.util.metric import *
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
from PIL import Image

import torch.optim as optim
import torch.nn as nn
from dev.probe_3d.model.depth_loss import DepthLoss
from dev.probe_3d.model.ssi_loss import *
from dev.probe_3d.model.virtual_normal_loss import *
from elatentlpips import ELatentLPIPS
import logging
from src.util.logging_util import (
    config_logging,
    init_wandb,
    load_wandb_job_id,
    log_slurm_job_id,
    save_wandb_job_id,
    tb_logger,
)

import os
from marigold import MarigoldPipeline

def colorize(
    value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "magma_r"
):
    # if already RGB, do nothing
    if value.ndim > 2:
        if value.shape[-1] > 1:
            return value
        value = value[..., 0]
    invalid_mask = value < 0.0001
    # normalize
    vmin = value.min() if vmin is None else vmin
    vmax = value.max() if vmax is None else vmax
    value = (value - vmin) / (vmax - vmin)  # vmin..vmax

    # set color
    cmapper = matplotlib.cm.get_cmap(cmap)
    value = cmapper(value, bytes=True)  # (nxmx4)
    value[invalid_mask] = 0
    img = value[..., :3]
    return img

def abs_relative_difference_full(output, target, valid_mask=None):
    actual_output = output
    actual_target = target
    abs_relative_diff = torch.abs(actual_output - actual_target) / actual_target
    if valid_mask is not None:
        abs_relative_diff[~valid_mask] = 0
        n = valid_mask.sum((-1, -2))
    else:
        n = output.shape[-1] * output.shape[-2]
    return abs_relative_diff




if __name__ == "__main__":
    ## Load data ##

    # choose 5 images from a dataset
    data_names = ["kitti", "nyu"]
    dataset_configs = ["config/dataset/data_kitti_eigen_test.yaml", "config/dataset/data_nyu_test.yaml"]
    idx = [0, 100, 200, 400, 600]
    # idx = idx[::-1]
    # dataset_configs = dataset_configs[::-1]
    # data_names = data_names[::-1]
    # dataset_config = "config/dataset/data_hypersim_val.yaml"
    # dataset_config = "config/dataset/data_vkitti_val.yaml"
    # dataset_config = "config/dataset/data_kitti_eigen_test.yaml"

    base_data_dir = "/home/ubuntu/Working/haipd13/diffusion/data"
    config = "config/train_marigold.yaml"
    out_dir = "../marigold_exp/training/metric_mlps/elatentlpips_mse_si_sparse_mg_init_ssi"


    for j in range(len(data_names)):
        dataset_config = dataset_configs[j]
        name = data_names[j]
        cfg_data = OmegaConf.load(dataset_config)
        cfg = recursive_load_config(config)
        print(cfg.depth_normalization)
        
        config_logging(cfg.logging, out_dir=out_dir)

        depth_transform: DepthNormalizerBase = get_depth_normalizer(
            cfg_normalizer=cfg.depth_normalization
        )

        dataset_scaled = get_dataset(
            cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.TRAIN,
            depth_transform=depth_transform
        )

        torch_device = "cuda"

        # vae = AutoencoderKL.from_pretrained("prs-eth/marigold-v1-0", subfolder="vae", use_safetensors=True)
        # vae.to(torch_device)
        pipe = MarigoldPipeline.from_pretrained(
            "prs-eth/marigold-v1-0",
        )
        pipe = pipe.to(torch_device)

        lr = 1e-2
        mse_loss = nn.MSELoss()
        si_loss = DepthLoss(max_depth=200)
        elatentlpips = ELatentLPIPS(encoder="sd21", augment='bg').to("cuda").eval()    

        num_steps = 20000
        
        
        losses = []
        for i in idx:
            out_scaled = dataset_scaled.__getitem__(i)
            depth_og = out_scaled['depth_raw_norm'].to(torch_device).unsqueeze(0)
            depth_og = (depth_og + 1.0) / 2.0
            # depth_og = depth_og.clamp(0, 200)
            images = out_scaled['rgb_norm'].unsqueeze(0).to(torch_device)
            
            with torch.no_grad():
                
                lat = pipe.vae.encoder(depth_og.repeat(1,3,1,1))
                moments = pipe.vae.quant_conv(lat) # 44, 154, 4
                mean, logvar = torch.chunk(moments, 2, dim=1)
                rgb_latent = pipe.encode_rgb(images)

                ## Denoise one-step ##
                
                pipe.scheduler.set_timesteps(50, device=torch_device)
                timesteps = pipe.scheduler.timesteps[-1]  # [T]

            trainable_param = torch.nn.Parameter(torch.randn(mean.shape).to(torch_device), requires_grad=True)
            optimizer = optim.Adam([trainable_param], lr=lr)
            
            
            # os.makedirs(os.path.join(out_dir, "out"), exist_ok=True)
            # os.makedirs(os.path.join(out_dir, "out", os.path.dirname(out_scaled['rgb_relative_path'])), exist_ok=True)
            # out_path_np = os.path.join(out_dir, "out", os.path.dirname(out_scaled['rgb_relative_path']), os.path.basename(out_scaled['rgb_relative_path']).replace('png', 'pt').replace('jpg', 'pt'))
            # print(out_path_np)
            # torch.save(trainable_param, out_path_np)
            
            for step in range(num_steps):
                optimizer.zero_grad()


                # Initial depth map (noise)
                depth_latent = torch.randn(
                    rgb_latent.shape,
                    device=torch_device,
                )  # [B, 4, h, w]
                # Batched empty text embedding
                if pipe.empty_text_embed is None:
                    pipe.encode_empty_text()
                batch_empty_text_embed = pipe.empty_text_embed.repeat(
                    (rgb_latent.shape[0], 1, 1)
                ).to(torch_device)  # [B, 2, 1024]
                
                unet_input = torch.cat(
                    [rgb_latent, trainable_param], dim=1
                )  # this order is important

                # predict the noise residual
                noise_pred = pipe.unet(
                    unet_input, timesteps, encoder_hidden_states=batch_empty_text_embed
                ).sample  # [B, 4, h, w]

                depth_latent_og = pipe.scheduler.step(noise_pred, timesteps, depth_latent).pred_original_sample
                depth = pipe.decode_depth(depth_latent_og)
                depth = torch.clip(depth, -1.0, 1.0)
                # shift to [0, 1]
                depth = (depth + 1.0) / 2.0

                # depth_latent_og /= pipe.depth_latent_scale_factor
                # z = pipe.vae.post_quant_conv(depth_latent_og)
                # stacked = pipe.vae.decoder(z)
                # depth = (stacked.mean(1)*10).clamp(-10,10).exp()

                mask = depth_og > 0
                elpips = elatentlpips(rgb_latent, trainable_param, normalize=True, ensembling=True, add_l1_loss=False).mean()
                si = si_loss(depth, depth_og)
                mse = mse_loss(depth[mask], depth_og[mask]) 

                loss = mse  + elpips + si
                # Backward pass and optimization
                loss.backward(retain_graph=True)
                optimizer.step()



                with torch.no_grad():
                    if (step + 1) % 2000 == 0:                
                        # Calculate MSE loss
                        # Print the current step and loss values
                        print(f'Step [{step+1}/{num_steps}], MSE Loss: {loss:.4f}')

                        depth_pred_ts = depth.squeeze(0).squeeze(0).cpu()
                        depth_raw_ts = depth_og.squeeze(0).squeeze(0).cpu()
                        valid_mask_ts = depth_raw_ts > 0

                        out = abs_relative_difference_full(depth_pred_ts, depth_raw_ts, valid_mask_ts).numpy()
                        colors = colorize(out, vmin=0.0, vmax=0.1, cmap="coolwarm")

                        plt.figure(figsize=(20,20))
                        plt.axis('off')
                        plt.imshow(colors)
                        os.makedirs(os.path.join(out_dir, "error"), exist_ok=True)
                        plt.savefig(os.path.join(out_dir, "error", f'err_{name}_{i}_{step+1}.jpg'))

                        os.makedirs(os.path.join(out_dir, "prediction", os.path.dirname(out_scaled['rgb_relative_path'])), exist_ok=True)
                        out_path_np = os.path.join(out_dir, "prediction", os.path.dirname(out_scaled['rgb_relative_path']), os.path.basename(out_scaled['rgb_relative_path']).replace('png', 'npy'))
                        np.save(out_path_np, depth_pred_ts.cpu().numpy())

                        logging.info(f"error: {mse}")
                
                torch.cuda.empty_cache()

            losses.append(mse)
            
            os.makedirs(os.path.join(out_dir, "out"), exist_ok=True)
            os.makedirs(os.path.join(out_dir, "out", os.path.dirname(out_scaled['rgb_relative_path'])), exist_ok=True)
            out_path_np = os.path.join(out_dir, "out", os.path.dirname(out_scaled['rgb_relative_path']), os.path.basename(out_scaled['rgb_relative_path']).replace('png', 'pt').replace('jpg', 'pt'))

            torch.save(trainable_param, out_path_np)

        logging.info(f"Full error {name}: {sum(losses)/len(losses)}")