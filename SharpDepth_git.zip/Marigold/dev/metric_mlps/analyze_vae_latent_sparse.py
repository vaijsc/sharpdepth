from omegaconf import OmegaConf
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)
from torch.utils.data import DataLoader
from src.util.depth_transform import (
    DepthNormalizerBase,
    get_depth_normalizer,
)
from src.util.config_util import (
    find_value_in_omegaconf,
    recursive_load_config,
)
import torch
from diffusers import AutoencoderKL, UNet2DConditionModel, PNDMScheduler
from src.util.metric import *
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
from PIL import Image

import torch.optim as optim
import torch.nn as nn
from dev.probe_3d.model.depth_loss import DepthLoss
from dev.probe_3d.model.ssi_loss import *
from dev.probe_3d.model.virtual_normal_loss import *
from elatentlpips import ELatentLPIPS
import logging
from src.util.logging_util import (
    config_logging,
    init_wandb,
    load_wandb_job_id,
    log_slurm_job_id,
    save_wandb_job_id,
    tb_logger,
)

import os

def colorize(
    value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "magma_r"
):
    # if already RGB, do nothing
    if value.ndim > 2:
        if value.shape[-1] > 1:
            return value
        value = value[..., 0]
    # invalid_mask = value < 0.0001
    # normalize
    vmin = value.min() if vmin is None else vmin
    vmax = value.max() if vmax is None else vmax
    value = (value - vmin) / (vmax - vmin)  # vmin..vmax

    # set color
    cmapper = matplotlib.cm.get_cmap(cmap)
    value = cmapper(value, bytes=True)  # (nxmx4)
    # value[invalid_mask] = 0
    img = value[..., :3]
    return img

def abs_relative_difference_full(output, target, valid_mask=None):
    actual_output = output
    actual_target = target
    abs_relative_diff = torch.abs(actual_output - actual_target) / actual_target
    if valid_mask is not None:
        abs_relative_diff[~valid_mask] = 0
        n = valid_mask.sum((-1, -2))
    else:
        n = output.shape[-1] * output.shape[-2]
    return abs_relative_diff




if __name__ == "__main__":
    ## Load data ##

    # choose 5 images from a dataset
    data_names = ["kitti", "nyu"]
    dataset_configs = ["config/dataset/data_kitti_eigen_test.yaml", "config/dataset/data_nyu_test.yaml"]
    idx = [0, 100, 200, 400, 600]
    # idx = idx[::-1]
    # dataset_configs = dataset_configs[::-1]
    # data_names = data_names[::-1]
    # dataset_config = "config/dataset/data_hypersim_val.yaml"
    # dataset_config = "config/dataset/data_vkitti_val.yaml"
    # dataset_config = "config/dataset/data_kitti_eigen_test.yaml"

    base_data_dir = "/home/ubuntu/Working/haipd13/diffusion/data"
    config = "config/train_marigold.yaml"
    out_dir = "../marigold_exp/training/metric_mlps/elatentlpips_mse_si_sparse_inv_mae"


    for j in range(len(data_names)):
        dataset_config = dataset_configs[j]
        name = data_names[j]
        cfg_data = OmegaConf.load(dataset_config)
        cfg = recursive_load_config(config)
        print(cfg.depth_normalization)
        
        config_logging(cfg.logging, out_dir=out_dir)

        depth_transform: DepthNormalizerBase = get_depth_normalizer(
            cfg_normalizer=cfg.depth_normalization
        )

        dataset_scaled = get_dataset(
            cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.TRAIN,
            depth_transform=depth_transform
        )

        torch_device = "cuda"

        vae = AutoencoderKL.from_pretrained("prs-eth/marigold-v1-0", subfolder="vae", use_safetensors=True)
        vae.to(torch_device)

        lr = 1e-2
        mae_loss = nn.L1Loss()
        si_loss = DepthLoss(max_depth=200)
        elatentlpips = ELatentLPIPS(encoder="sd21", augment='bg').to("cuda").eval()    

        num_steps = 20000
        
        
        losses = []
        for i in idx:
            out_scaled = dataset_scaled.__getitem__(i)
            depth_og = out_scaled['depth_raw_linear'].to(torch_device)
            depth_og = depth_og.clamp(0, 200)
            images = out_scaled['rgb_norm'].unsqueeze(0).to(torch_device)
            
            with torch.no_grad():
                lat = vae.encoder(depth_og.unsqueeze(0).repeat(1,3,1,1))
                moments = vae.quant_conv(lat) # 44, 154, 4
                mean, logvar = torch.chunk(moments, 2, dim=1)
                img_lat = vae.encode(images).latent_dist.sample()

            trainable_param = torch.nn.Parameter(torch.randn(mean.shape).to("cuda"), requires_grad=True)
            optimizer = optim.Adam([trainable_param], lr=lr)
            
            
            # os.makedirs(os.path.join(out_dir, "out"), exist_ok=True)
            # os.makedirs(os.path.join(out_dir, "out", os.path.dirname(out_scaled['rgb_relative_path'])), exist_ok=True)
            # out_path_np = os.path.join(out_dir, "out", os.path.dirname(out_scaled['rgb_relative_path']), os.path.basename(out_scaled['rgb_relative_path']).replace('png', 'pt').replace('jpg', 'pt'))
            # print(out_path_np)
            # torch.save(trainable_param, out_path_np)
            
            for step in range(num_steps):
                optimizer.zero_grad()

                z = vae.post_quant_conv(trainable_param)
                stacked = vae.decoder(z)


                depth = (stacked.mean(1)*10).clamp(-10,10).exp()

                mask = depth_og > 0
                pred_inv_depth_all = 1/depth
                inv_depth_gt_all = 1/depth_og.clamp(1e-4, 200)
                mse = mae_loss(pred_inv_depth_all[mask], inv_depth_gt_all[mask]) 

                elpips = elatentlpips(img_lat, trainable_param, normalize=True, ensembling=True, add_l1_loss=False).mean()
                si = si_loss(depth.unsqueeze(0), depth_og.clone().unsqueeze(0))
                loss = mse + si + elpips
                # Backward pass and optimization
                loss.backward()
                optimizer.step()


                with torch.no_grad():
                    if (step + 1) % 2000 == 0:                
                        # Calculate MSE loss
                        # Print the current step and loss values
                        print(f'Step [{step+1}/{num_steps}], MSE Loss: {loss:.4f}')

                        depth_pred_ts = depth.squeeze(0)
                        depth_raw_ts = depth_og.squeeze(0)
                        valid_mask_ts = depth_raw_ts.squeeze(0) > 0

                        out = abs_relative_difference_full(depth_pred_ts, depth_raw_ts, valid_mask_ts).cpu().numpy()
                        colors = colorize(out, vmin=0.0, vmax=0.1, cmap="coolwarm")

                        plt.figure(figsize=(20,20))
                        plt.axis('off')
                        plt.imshow(colors)
                        os.makedirs(os.path.join(out_dir, "error"), exist_ok=True)
                        plt.savefig(os.path.join(out_dir, "error", f'err_{name}_{i}_{step+1}.jpg'))

                        os.makedirs(os.path.join(out_dir, "prediction", os.path.dirname(out_scaled['rgb_relative_path'])), exist_ok=True)
                        out_path_np = os.path.join(out_dir, "prediction", os.path.dirname(out_scaled['rgb_relative_path']), os.path.basename(out_scaled['rgb_relative_path']).replace('png', 'npy'))
                        np.save(out_path_np, depth_pred_ts.cpu().numpy())

                        logging.info(f"error: {mse}")
            losses.append(mse)
            
            os.makedirs(os.path.join(out_dir, "out"), exist_ok=True)
            os.makedirs(os.path.join(out_dir, "out", os.path.dirname(out_scaled['rgb_relative_path'])), exist_ok=True)
            out_path_np = os.path.join(out_dir, "out", os.path.dirname(out_scaled['rgb_relative_path']), os.path.basename(out_scaled['rgb_relative_path']).replace('png', 'pt').replace('jpg', 'pt'))

            torch.save(trainable_param, out_path_np)

        logging.info(f"Full error {name}: {sum(losses)/len(losses)}")