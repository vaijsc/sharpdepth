export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
source activate mvsplat
cd ../elatentlpips
pip install -e .
cd -
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 
python dev/metric_mlps/analyze_vae_latent.py