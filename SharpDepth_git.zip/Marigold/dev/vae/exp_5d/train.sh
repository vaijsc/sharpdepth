export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
source activate mvsplat 
pip install datasets
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH accelerate launch dev/vae/exp_5d/train_vae.py --mixed_precision="no" \
    --pretrained_model_name_or_path="stabilityai/stable-diffusion-2-1" \
    --train_batch_size=2 \
    --dataset_name="nateraw/pascal-voc-2012" \
    --gradient_accumulation_steps=32 \
    --gradient_checkpointing \
    --validation_epochs=6 \
    --config dev/vae/exp_5a/configs/train_marigold.yaml \
    --output_dir ../marigold_exp/training/vae/5e/vae-model-finetuned \
    --checkpointing_steps 1000 \
    --num_train_epochs 50 \
    --kl_scale 1e-7 \
    --lpips_scale 0
    # --resume_run ../marigold_exp/training/vae/5a/vae-model-finetuned/checkpoint-12000