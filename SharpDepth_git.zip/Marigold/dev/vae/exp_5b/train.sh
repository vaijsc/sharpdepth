export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
source activate mvsplat 
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH accelerate launch --num_processes=1 dev/vae/exp_5b/train_vae.py --mixed_precision="no" \
    --pretrained_model_name_or_path="stabilityai/stable-diffusion-2-1" \
    --train_batch_size=4 \
    --dataset_name="nateraw/pascal-voc-2012" \
    --gradient_accumulation_steps=4 \
    --gradient_checkpointing \
    --validation_epochs=6 \
    --config dev/vae/exp_5a/configs/train_marigold.yaml \
    --output_dir ../marigold_exp/training/vae/5b/vae-model-finetuned \
    --checkpointing_steps 1000 \
    --num_train_epochs 50 \
    # --resume_run ../marigold_exp/training/vae/5a/vae-model-finetuned/checkpoint-12000