source activate mvsplat
pip install datasets
accelerate launch train_vae.py --mixed_precision="no" \
    --pretrained_model_name_or_path="stabilityai/stable-diffusion-2-1" \
    --dataset_name="nateraw/pascal-voc-2012" \
    --train_batch_size=1 \
    --gradient_accumulation_steps=4 \
    --gradient_checkpointing \
    --validation_epochs=6\
