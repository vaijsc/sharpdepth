export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

python dev/refine_plus/refiner_1d/infer.py \
        --config dev/refine_plus/refiner_1d/configs/train_lotus_refined.yaml \
        --base_data_dir $BASE_DATA_DIR \
        --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
        --dataset_config config/dataset/data_nyu_test_unidepth.yaml \
        --output_dir ../marigold_exp/eval/dev/refiner/refiner_1e_19k/nyuv2/prediction \
        --checkpoint ../marigold_exp/training/refiner/refiner_1e/checkpoint-19000 \
        # --processing_res 756 \

        # /lustre/scratch/client/vinai/users/tungdt33/depth_estimation/code/MetricDepthDiffusion/exp_lotus_student_0.05/checkpoint-17000