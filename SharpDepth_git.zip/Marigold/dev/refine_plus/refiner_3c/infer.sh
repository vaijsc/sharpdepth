export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

export OUT_DIR=../marigold_exp/eval/dev/refiner/refiner_3c/kitti_dc/prediction 
export EVAL_DIR=../marigold_exp/eval/dev/refiner/refiner_3c/kitti_dc/eval_metric
export CKPT_DIR=../marigold_exp/training/refiner/refiner_3c/checkpoint-16000

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

python dev/refine_plus/refiner_3c/infer.py \
        --config dev/refine_plus/refiner_3a/configs/main.yaml \
        --base_data_dir $BASE_DATA_DIR \
        --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
        --dataset_config config/dataset/data_kitti_eigen_test_dc.yaml \
        --output_dir $OUT_DIR \
        --checkpoint $CKPT_DIR\

# python eval.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_kitti_eigen_test.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \