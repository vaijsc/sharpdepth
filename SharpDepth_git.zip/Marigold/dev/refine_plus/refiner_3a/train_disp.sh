export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

CUDA_VISIBLE_DEVICES=$GPU_STRING torchrun --nnodes 1 --nproc_per_node $GPU_COUNT \
                                        --rdzv-backend=c10d --rdzv-endpoint=localhost:0 dev/refine_plus/refiner_3a/train_disp.py \
                                        --config dev/refine_plus/refiner_3a/configs/main.yaml \
                                        --output_dir ../marigold_exp/training/refiner/refiner_3a \
                                        --depth_weight 0.5 \
                                        --base_data_dir $BASE_DATA_DIR \
                                        --base_ckpt_dir jingheya/lotus-depth-g-v2-0-disparity \
                                        --student_ckpt_dir jingheya/lotus-depth-g-v2-0-disparity \
                                        --add_datetime_prefix \
                                        --report_to tensorboard \
                                        --mixed_precision no \
                                        --seed 42 \
                                        --gradient_checkpointing \
                                        --enable_xformers_memory_efficient_attention \
                                        --allow_tf32 \
                                        --learning_rate 1e-6 \
                                        --scale_lr \
                                        --max_grad_norm 0.1 \
                                        --lr_scheduler cosine \
                                        --lr_warmup_steps 200 \
                                        --tracker_project_name main \
                                        --set_grads_to_none \
                                        --checkpointing_steps 1000 \
                                        --validation_steps 1000 \
                                        --train_batch_size 1 \
                                        --gradient_accumulation_steps 16 \
                                        --num_train_epochs 20 \
                                        --use_ema \
                                        # --resume_from_checkpoint marigold_exp/training/refiner/main_tung_04_disp_200k_data/checkpoint-10000



