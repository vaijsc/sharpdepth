export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

export OUT_DIR=../marigold_exp/eval/dev/refiner/refiner_2b_no_si/sintel_quick_inf/prediction 
export EVAL_DIR=../marigold_exp/eval/dev/refiner/refiner_2b_no_si/sintel_quick_inf/eval_metric
export CKPT_DIR=../marigold_exp/training/refiner/refiner_2b_no_si/checkpoint-4000
GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

# python dev/refine_plus/refiner_2b/infer.py \
#         --config dev/refine_plus/refiner_2a/configs/train_lotus_refined.yaml \
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_sintel_test_unidepth.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\

python eval_f1.py \
    --base_data_dir $BASE_DATA_DIR \
    --dataset_config config/dataset/data_sintel_test.yaml \
    --prediction_dir $OUT_DIR \
    --output_dir $EVAL_DIR \

