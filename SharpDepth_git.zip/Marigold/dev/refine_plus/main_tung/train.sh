export BASE_DATA_DIR=/home/ubuntu/Working/diffusion/data
export HF_HOME=/home/ubuntu/Working/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

CUDA_VISIBLE_DEVICES=$GPU_STRING torchrun --nnodes 1 --nproc_per_node $GPU_COUNT \
                                        --rdzv-backend=c10d --rdzv-endpoint=localhost:0 dev/refine_plus/main_tung/train.py \
                                        --config dev/refine_plus/main_tung/configs/main.yaml \
                                        --output_dir ../marigold_exp/training/rebuttal/main_tung_05_90k_data \
                                        --depth_weight 0.5 \
                                        --base_data_dir $BASE_DATA_DIR \
                                        --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
                                        --student_ckpt_dir jingheya/lotus-depth-g-v1-0 \
                                        --add_datetime_prefix \
                                        --report_to tensorboard \
                                        --mixed_precision no \
                                        --seed 42 \
                                        --gradient_checkpointing \
                                        --enable_xformers_memory_efficient_attention \
                                        --allow_tf32 \
                                        --learning_rate 1e-6 \
                                        --scale_lr \
                                        --max_grad_norm 0.1 \
                                        --lr_scheduler cosine \
                                        --lr_warmup_steps 200 \
                                        --tracker_project_name main \
                                        --set_grads_to_none \
                                        --checkpointing_steps 2000 \
                                        --validation_steps 2000 \
                                        --train_batch_size 1 \
                                        --gradient_accumulation_steps 16 \
                                        --num_train_epochs 20 \
                                        --use_ema \
                                        --resume_from_checkpoint ../marigold_exp/training/rebuttal/main_tung_05_90k_data/checkpoint-8000




