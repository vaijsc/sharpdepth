export BASE_DATA_DIR=/root/data_hai/diffusion/data
export HF_HOME=/root/data_hai/diffusion/
export BASE_CKPT_DIR=/root/data_hai/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

export OUT_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data/kitti_001_mask/prediction 
export EVAL_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data/kitti_001_mask/eval_metric
export CKPT_DIR=../marigold_exp/training/rebuttal/main_tung_03_metric3dv2_90k_data/checkpoint-4000



python dev/refine_plus/main_tung/measure_real_flops.py \
        --config dev/refine_plus/main_tung/configs/main.yaml \
        --base_data_dir $BASE_DATA_DIR \
        --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
        --dataset_config config/dataset/data_kitti_eigen_test_unidepth.yaml \
        --output_dir $OUT_DIR \
        --checkpoint $CKPT_DIR\


# Computational vae encoder complexity:  2913.46 GMac
# Number of vae encoder parameters:  83.65 M
# Warning! No positional inputs found for a module, assuming batch size is 1.
# Computational unet complexity:  554.17 GMac
# Number of unet parameters:  867.57 M
# ('527.13 GMac', '347.0 M')