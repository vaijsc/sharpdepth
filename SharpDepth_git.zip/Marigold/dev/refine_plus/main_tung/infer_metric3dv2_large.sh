export BASE_DATA_DIR=/home/ubuntu/Working/diffusion/data
export HF_HOME=/home/ubuntu/Working/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

export OUT_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/kitti/prediction 
export EVAL_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/kitti/eval_metric
export CKPT_DIR=../marigold_exp/training/rebuttal/main_tung_03_metric3dv2_90k_data/checkpoint-12000

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

# python dev/refine_plus/main_tung/infer.py \
#         --config dev/refine_plus/main_tung/configs/main_metric3dv2.yaml \
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_kitti_eigen_test_metric3dv2_large.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\

# python eval.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_kitti_eigen_test.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \

# export OUT_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/nyuv2/prediction 
# export EVAL_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/nyuv2/eval_metric

# python dev/refine_plus/main_tung/infer_metric3dv2.py \
#         --config dev/refine_plus/main_tung/configs/main_metric3dv2.yaml\
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_nyu_test_metric3dv2_large.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\

# python eval.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_nyu_test.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \

# export OUT_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/sintel/prediction 
# export EVAL_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/sintel/eval_metric

# python dev/refine_plus/main_tung/infer.py \
#         --config dev/refine_plus/main_tung/configs/main_metric3dv2.yaml\
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_sintel_test_metric3dv2_large.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\

# python eval_f1.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_sintel_test.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \



# export OUT_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/diode/prediction 
# export EVAL_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/diode/eval_metric

# python dev/refine_plus/main_tung/infer_metric3dv2.py \
#         --config dev/refine_plus/main_tung/configs/main_metric3dv2.yaml\
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_diode_all_metric3dv2_large.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\

# python eval.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_diode_all.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \


# export OUT_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/ibims/prediction 
# export EVAL_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/ibims/eval_metric

# python dev/refine_plus/main_tung/infer.py \
#         --config dev/refine_plus/main_tung/configs/main_metric3dv2.yaml\
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_ibims_test_metric3dv2_large.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\

# python eval_ibims.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_ibims_test.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \


export OUT_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/unrealstereo/prediction 
export EVAL_DIR=../marigold_exp/eval/dev/rebuttal/main_tung_03_metric3dv2_90k_data_large/unrealstereo/eval_metric

python dev/refine_plus/main_tung/infer.py \
        --config dev/refine_plus/main_tung/configs/main_metric3dv2.yaml\
        --base_data_dir $BASE_DATA_DIR \
        --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
        --dataset_config config/dataset/data_unrealstereo_test_main_metric3dv2_large.yaml \
        --output_dir $OUT_DIR \
        --checkpoint $CKPT_DIR\

python eval_f1.py \
    --base_data_dir $BASE_DATA_DIR \
    --dataset_config config/dataset/data_unrealstereo_test.yaml \
    --prediction_dir $OUT_DIR \
    --output_dir $EVAL_DIR \


