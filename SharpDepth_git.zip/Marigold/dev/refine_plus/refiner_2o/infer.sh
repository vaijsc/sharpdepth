export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

# export OUT_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_main_ckpt/kitti/prediction 
# export EVAL_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_main_ckpt/kitti/eval_metric
# export CKPT_DIR=../marigold_exp/training/refiner/refiner_2o_final/checkpoint-14000
export CKPT_DIR=../../tungdt33/MetricDepthDiffusion/exp_main/checkpoint-13000_saved
# export CKPT_DIR=../marigold_exp/training/refiner/refiner_2o_final_03_no_mask/checkpoint-22000
# export CKPT_DIR=../marigold_exp/training/refiner/refiner_2o_final_03_no_mask/checkpoint-13000
GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

# python dev/refine_plus/refiner_2o/infer.py \
#         --config dev/refine_plus/refiner_2o/configs/train_lotus_refined.yaml \
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_kitti_eigen_test_metric3dv2.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\
# #         --n_iter 3

# python eval.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_kitti_eigen_test.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \

# export OUT_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_sky_mask/sintel/prediction 
# export EVAL_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_sky_mask/sintel/eval_metric

# python dev/refine_plus/refiner_2o/infer.py \
#         --config dev/refine_plus/refiner_2o/configs/train_lotus_refined.yaml \
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_sintel_test_metric3dv2.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\
# #         --n_iter 3
# #         # --use_ema
    
# python eval_f1.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_sintel_test.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \
    

export OUT_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_main_ckpt/nyuv2/prediction 
export EVAL_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_main_ckpt/nyuv2/eval_metric

python dev/refine_plus/refiner_2o/infer.py \
        --config dev/refine_plus/refiner_2o/configs/train_lotus_refined.yaml \
        --base_data_dir $BASE_DATA_DIR \
        --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
        --dataset_config config/dataset/data_nyu_test_metric3dv2.yaml \
        --output_dir $OUT_DIR \
        --checkpoint $CKPT_DIR\

python eval.py \
    --base_data_dir $BASE_DATA_DIR \
    --dataset_config config/dataset/data_nyu_test.yaml \
    --prediction_dir $OUT_DIR \
    --output_dir $EVAL_DIR \


# export OUT_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_main_ckpt/diode/prediction 
# export EVAL_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_main_ckpt/diode/eval_metric

# python dev/refine_plus/refiner_2n/infer.py \
#         --config dev/refine_plus/refiner_2n/configs/train_lotus_refined.yaml \
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_diode_all_unidepth.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\

# python eval.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_diode_all.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \


# export OUT_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_main_ckpt/nuscenes/prediction 
# export EVAL_DIR=../marigold_exp/eval/dev/refiner/refiner_2o_final_main_ckpt/nuscenes/eval_metric

# python dev/refine_plus/refiner_2n/infer.py \
#         --config dev/refine_plus/refiner_2n/configs/train_lotus_refined.yaml \
#         --base_data_dir $BASE_DATA_DIR \
#         --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
#         --dataset_config config/dataset/data_nuscenes_val_unidepth.yaml \
#         --output_dir $OUT_DIR \
#         --checkpoint $CKPT_DIR\

# python eval.py \
#     --base_data_dir $BASE_DATA_DIR \
#     --dataset_config config/dataset/data_nuscenes_val.yaml \
#     --prediction_dir $OUT_DIR \
#     --output_dir $EVAL_DIR \




