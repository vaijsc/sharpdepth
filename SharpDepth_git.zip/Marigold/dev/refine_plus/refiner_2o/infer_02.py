import argparse
import logging
import os
import shutil
from datetime import datetime, timedelta
from typing import List
from pathlib import Path
from packaging import version
import math
import itertools
import numpy as np
from PIL import Image

from tqdm import tqdm
from omegaconf import OmegaConf

import torch
import torch.nn.functional as F
import torchvision
from torch.utils.data import ConcatDataset, DataLoader

from src.dataset import BaseDepthDataset, DatasetMode, get_dataset
from src.dataset.mixed_sampler import MixedBatchSampler
from src.trainer import get_trainer_cls
from src.util.logging_util import config_logging
from src.util.config_util import (
                                    find_value_in_omegaconf,
                                    recursive_load_config,
                                )
from src.util.depth_transform import (
                                        DepthNormalizerBase,
                                        get_depth_normalizer,
                                    )
from src.util.slurm_util import get_local_scratch_dir, is_on_slurm


import transformers
from transformers import AutoTokenizer, PretrainedConfig

import diffusers
from diffusers import UNet2DConditionModel, DDPMScheduler, AutoencoderKL
from diffusers.utils.import_utils import is_xformers_available
from diffusers.utils.torch_utils import is_compiled_module
from diffusers.optimization import get_scheduler
from diffusers.training_utils import EMAModel
from ema_pytorch import EMA

from accelerate.logging import get_logger
from accelerate import Accelerator, DataLoaderConfiguration
from accelerate.utils import ProjectConfiguration, set_seed

# for visualization
from src.util.metric import *
from src.util.alignment import *
import matplotlib.pyplot as plt
import matplotlib
from marigold.util.image_util import (
                                            chw2hwc,
                                            colorize_depth_maps,
                                            get_tv_resample_method,
                                            resize_max_res,
                                        )
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)
logger = get_logger(__name__)

@torch.no_grad()
def encode_image(vae, rgb):
    rgb_latent = vae.encode(rgb).latent_dist.sample()
    rgb_latent = rgb_latent * vae.config.scaling_factor
    return rgb_latent

@torch.no_grad()
def encode_depth(vae, depth):
    depth_latent = vae.encode(depth.repeat(1, 3, 1, 1)).latent_dist.sample()
    depth_latent = depth_latent * vae.config.scaling_factor
    return depth_latent

@torch.no_grad()
def decode_image(vae, latent):
    # scale latent
    latent = latent / vae.config.scaling_factor
    # decode
    z = vae.post_quant_conv(latent)
    rgb = vae.decoder(z)
    return rgb


def to_gpu(ob, device):
    if isinstance(ob, dict):
        return {k: to_gpu(v, device) for k, v in ob.items()}
    elif isinstance(ob, tuple):
        return tuple(to_gpu(k, device) for k in ob)
    elif isinstance(ob, list):
        return [to_gpu(k, device) for k in ob]
    else:
        try:
            return ob.to(device)
        except Exception:
            return ob


def sig_loss(depth_pr, depth_gt, mask, sigma=0.85, eps=0.001, only_mean=False):
    """
    SigLoss
        This follows `AdaBins <https://arxiv.org/abs/2011.14141>`_.
        adapated from DINOv2 code

    Args:
        depth_pr (FloatTensor): predicted depth
        depth_gt (FloatTensor): groundtruth depth
        eps (float): to avoid exploding gradient
    """
    depth_pr = torch.clip(depth_pr, -1.0, 1.0)
    depth_pr = (depth_pr + 1.0) / 2.0
    depth_gt = torch.clip(depth_gt, -1.0, 1.0)
    depth_gt = (depth_gt + 1.0) / 2.0

    # ignore invalid depth pixels
    valid = mask
    depth_pr = depth_pr[valid]
    depth_gt = depth_gt[valid]

    g = torch.log(depth_pr + eps) - torch.log(depth_gt + eps)

    loss = g.pow(2).mean() - sigma * g.mean().pow(2)
    loss = loss.sqrt()
    return loss


def visualize_depth(pred_depth, path):
    colorized_depth = []
    for pt_depth in pred_depth:
        np_depth      = pt_depth.squeeze().detach().cpu().numpy()
        depth_colored = colorize_depth_maps(np_depth, np_depth.min(), np_depth.max(), cmap="Spectral").squeeze()  # [3, H, W], value in (0, 1)
        depth_colored = (depth_colored * 255).astype(np.uint8)
        depth_colored = chw2hwc(depth_colored)
        colorized_depth.append(depth_colored)

    saved_image = np.concatenate(colorized_depth, axis=-2)
    Image.fromarray(saved_image).save(path)


def encode_empty_text(tokenizer, text_encoder):
    """
    Encode text embedding for empty prompt
    """
    prompt = ""
    text_inputs = tokenizer(
        prompt,
        padding="do_not_pad",
        max_length=tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
    text_input_ids = text_inputs.input_ids.to(text_encoder.device)
    empty_text_embed = text_encoder(text_input_ids)[0]

    return empty_text_embed


def import_model_class_from_model_name_or_path(pretrained_model_name_or_path: str, revision: str):
    text_encoder_config = PretrainedConfig.from_pretrained(
        pretrained_model_name_or_path, subfolder="text_encoder", revision=revision
    )
    model_class = text_encoder_config.architectures[0]

    if model_class == "CLIPTextModel":
        from transformers import CLIPTextModel

        return CLIPTextModel
    elif model_class == "CLIPTextModelWithProjection":
        from transformers import CLIPTextModelWithProjection

        return CLIPTextModelWithProjection
    else:
        raise ValueError(f"{model_class} is not supported.")


def colorize(
    value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "magma_r"
):
    # if already RGB, do nothing
    if value.ndim > 2:
        if value.shape[-1] > 1:
            return value
        value = value[..., 0]
    invalid_mask = value < 0.0001
    # normalize
    vmin = value.min() if vmin is None else vmin
    vmax = value.max() if vmax is None else vmax
    value = (value - vmin) / (vmax - vmin)  # vmin..vmax

    # set color
    cmapper = matplotlib.cm.get_cmap(cmap)
    value = cmapper(value, bytes=True)  # (nxmx4)
    value[invalid_mask] = 0
    img = value[..., :3]
    return img

def abs_relative_difference_full(output, target, valid_mask=None):
    actual_output = output
    actual_target = target
    abs_relative_diff = torch.abs(actual_output - actual_target) / actual_target
    if valid_mask is not None:
        abs_relative_diff[~valid_mask] = 0
        n = valid_mask.sum((-1, -2))
    else:
        n = output.shape[-1] * output.shape[-2]
    return abs_relative_diff


if "__main__" == __name__:
    t_start = datetime.now()
    print(f"start at {t_start}")

    # -------------------- Arguments --------------------
    parser = argparse.ArgumentParser(description="Run single-image depth estimation using Marigold")
    
    parser.add_argument(
        "--checkpoint",
        type=str,
        default="prs-eth/marigold-v1-0",
        help="Checkpoint path or hub name.",
    )
    parser.add_argument(
        "--config",
        type=str,
        default="prs-eth/marigold-v1-0",
        help="sth.",
    )
    parser.add_argument("--use_ema", action="store_true", help="Whether to use EMA model.")
    # dataset setting
    parser.add_argument(
        "--dataset_config",
        type=str,
        required=True,
        help="Path to config file of evaluation dataset.",
    )

    parser.add_argument(
        "--base_data_dir", type=str, default=None, help="directory of training data"
    )
    parser.add_argument(
        "--base_ckpt_dir",
        type=str,
        default=None,
        help="directory of pretrained checkpoint",
    )

    parser.add_argument(
        "--output_dir", type=str, required=True, help="Output directory."
    )

    parser.add_argument("--n_iter", type=int, default=1, help="Random seed.")
    parser.add_argument("--seed", type=int, default=None, help="Random seed.")

    args = parser.parse_args()
    checkpoint_path = args.checkpoint
    output_dir = args.output_dir

    base_data_dir = (
        args.base_data_dir
        if args.base_data_dir is not None
        else os.environ["BASE_DATA_DIR"]
    )
    base_ckpt_dir = (
        args.base_ckpt_dir
        if args.base_ckpt_dir is not None
        else os.environ["BASE_CKPT_DIR"]
    )



    # -------------------- Initialization --------------------
    dataset_config = args.dataset_config    
    cfg_data = OmegaConf.load(dataset_config)
    cfg = recursive_load_config(args.config)

    # Full job name
    def check_directory(directory):
        if os.path.exists(directory):
            response = (
                input(
                    f"The directory '{directory}' already exists. Are you sure to continue? (y/n): "
                )
                .strip()
                .lower()
            )
            if "y" == response:
                pass
            elif "n" == response:
                print("Exiting...")
                exit()
            else:
                print("Invalid input. Please enter 'y' (for Yes) or 'n' (for No).")
                check_directory(directory)  # Recursive call to ask again

    # check_directory(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    logging.info(f"output dir = {output_dir}")


    # -------------------- set seed --------------------
    if args.seed is not None:
        set_seed(args.seed)
    # ---------------------------------------------------------------------

    # -------------------- Device --------------------
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
        logging.warning("CUDA is not available. Running on CPU will be slow.")
    logging.info(f"device = {device}")


    # -------------------- Create dataset --------------------
    if args.seed is None:
        loader_generator = None
    else:
        loader_generator = torch.Generator().manual_seed(args.seed)

    dataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )
    dataloader = DataLoader(dataset, batch_size=1, num_workers=0)

    # -------------------- Model --------------------
    tokenizer = AutoTokenizer.from_pretrained(base_ckpt_dir, subfolder="tokenizer")
    text_encoder_cls = import_model_class_from_model_name_or_path(base_ckpt_dir, revision=None)
    text_encoder = text_encoder_cls.from_pretrained(base_ckpt_dir, subfolder="text_encoder", revision=None)
    vae = AutoencoderKL.from_pretrained(base_ckpt_dir, subfolder="vae", revision=None)
    unidepth_transform = get_depth_normalizer(cfg_normalizer=cfg.unidepth_normalization)
    student_unet = UNet2DConditionModel.from_pretrained(os.path.join(checkpoint_path, "unet"), revision=None)
    noise_scheduler = DDPMScheduler.from_pretrained(base_ckpt_dir, subfolder="scheduler")

    # Load checkpoint
    if args.use_ema:
        # ema_unet = EMAModel.from_pretrained(os.path.join(checkpoint_path, "unet_ema"), UNet2DConditionModel)
        # ema_unet.copy_to(student_unet.parameters())
        # del ema_unet
        ema_model = EMA(
                            student_unet,
                            beta = 0.9999,              # exponential moving average factor
                            update_after_step = 100,    # only after this number of .update() calls will it start updating
                            update_every = 10,          # how often to actually update, to save on compute (updates every 10th .update() call)
                        )
        data = torch.load(os.path.join(checkpoint_path, "unet_ema.pt"))
        ema_model.load_state_dict(data["ema"], strict=False)
        del data

        ema_model.to(device)

    student_unet.to(device)
    vae.to(device)
    text_encoder.to(device)
    weight_dtype = torch.float32

    # -------------------- Precompute null & task embedding --------------------
    empty_text_emb = encode_empty_text(tokenizer, text_encoder).to(device, dtype=weight_dtype)
    del tokenizer
    del text_encoder
    task_emb = torch.tensor([1, 0]).float().unsqueeze(0).repeat(1, 1)
    task_emb = torch.cat([torch.sin(task_emb), torch.cos(task_emb)], dim=-1)

    # -------------------- Inference and saving --------------------
    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            batch           = to_gpu(batch, device)
            rgb             = batch["rgb_norm"]             # rgn in range [-1, 1]
            depth_unidepth  = batch['depth_filled_linear']  # unidepth in meters
            sky_mask        = batch['valid_mask_filled'] 
            sky_mask        = torch.ones(sky_mask.shape).to(device).bool()
            transformed_output  = unidepth_transform(depth_unidepth, sky_mask=sky_mask)
            norm_depth_unidepth = transformed_output["norm_depth"]

            rgb_latent = encode_image(vae, rgb).to(dtype=weight_dtype)
            lotus_timesteps = torch.ones((rgb_latent.shape[0],), device=device) * (noise_scheduler.config.num_train_timesteps - 1)
            lotus_timesteps = lotus_timesteps.long()

            unidepth_latent = encode_depth(vae, norm_depth_unidepth).to(dtype=weight_dtype)

            batch_empty_text_embed = empty_text_emb.repeat((rgb_latent.shape[0], 1, 1)).to(device, dtype=weight_dtype)
            batch_task_emb = task_emb.repeat((rgb_latent.shape[0], 1)).to(device, dtype=weight_dtype)

            # --------------------------------- 
            # extract mask
            lotus_input = torch.cat([rgb_latent.detach(), torch.randn_like(rgb_latent)], dim=1)  # this order is important
            pred_latent  = student_unet(lotus_input, lotus_timesteps, batch_empty_text_embed, class_labels=batch_task_emb).sample

            for i in range(args.n_iter):
                # --------------------------------- 
                # decode pred_latent to depth
                latent = pred_latent / vae.config.scaling_factor
                z = vae.post_quant_conv(latent)
                lotus_depth = vae.decoder(z).mean(dim=1, keepdim=True)
                # ---------------------------------

                lotus_depth = torch.nn.functional.interpolate(lotus_depth, norm_depth_unidepth.shape[-2:], mode="bilinear")
                # --------------------------------- 
                # calculate difference
                l1_error            = torch.abs(lotus_depth -  norm_depth_unidepth)
                l1_error            = l1_error/l1_error.max()
                l1_error            = l1_error.clip(0, 1)
                # l1_error[~sky_mask] = 0.0
                latent_mask = torch.nn.functional.interpolate(l1_error, scale_factor=1/8)
                # ---------------------------------

                noise                   = torch.randn_like(unidepth_latent)
                noisy_lotus_latent      = noise_scheduler.add_noise(pred_latent, noise, lotus_timesteps)
                noisy_latent            = noisy_lotus_latent * latent_mask + unidepth_latent * (1 - latent_mask)
                student_input           = torch.cat([rgb_latent, noisy_latent], dim=1)
                # ---------------------------------
                
                pred_latent     = student_unet(student_input, lotus_timesteps, encoder_hidden_states=batch_empty_text_embed, class_labels=batch_task_emb).sample

            # --------------------------------- 
            # decode pred_latent to depth
            latent = pred_latent / vae.config.scaling_factor
            z = vae.post_quant_conv(latent)
            pred_depth = vae.decoder(z).mean(dim=1, keepdim=True)
            pred_depth = torch.nn.functional.interpolate(pred_depth, norm_depth_unidepth.shape[-2:], mode="bilinear")
            # ---------------------------------

            depth_pred = (pred_depth.squeeze().clip(-1,1).cpu().numpy() + 1.0) / 2.0
            depth_scale = depth_unidepth.squeeze().cpu().numpy()

            valid_mask = 1 - l1_error
            valid_mask[~sky_mask] = 0.0
            valid_mask = np.ones(valid_mask.cpu().numpy().shape).astype(np.bool_)
            # valid_mask = valid_mask.cpu().numpy() > 0.02
            depth, scale, shift = align_depth_least_square(
                                                            gt_arr=depth_scale,
                                                            pred_arr=depth_pred,
                                                            valid_mask_arr=valid_mask,
                                                            return_scale_shift=True,
                                                            max_resolution=None,
                                                    )

            # Save predictions
            rgb_filename = batch["rgb_relative_path"][0]
            rgb_basename = os.path.basename(rgb_filename)
            scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
            if not os.path.exists(scene_dir):
                os.makedirs(scene_dir)
            pred_basename = get_pred_name(rgb_basename, dataset.name_mode, suffix=".npy")
            save_to = os.path.join(scene_dir, pred_basename)
            if os.path.exists(save_to):
                logging.warning(f"Existing file: '{save_to}' will be overwritten")

            np.save(save_to, depth)
            visualize_depth(pred_depth, save_to.replace("npy", "png"))

