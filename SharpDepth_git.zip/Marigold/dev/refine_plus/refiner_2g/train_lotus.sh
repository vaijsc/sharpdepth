export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

source activate mvsplat

accelerate launch --main_process_port=29504 dev/refine_plus/refiner_2g/train_lotus_refined.py \
                                        --config dev/refine_plus/refiner_2a/configs/train_lotus_refined.yaml \
                                        --output_dir ../marigold_exp/training/refiner/refiner_2g \
                                        --base_data_dir $BASE_DATA_DIR \
                                        --base_ckpt_dir jingheya/lotus-depth-g-v1-0 \
                                        --student_ckpt_dir jingheya/lotus-depth-g-v1-0 \
                                        --add_datetime_prefix \
                                        --report_to tensorboard \
                                        --mixed_precision no \
                                        --seed 42 \
                                        --gradient_checkpointing \
                                        --enable_xformers_memory_efficient_attention \
                                        --allow_tf32 \
                                        --learning_rate 1e-6 \
                                        --scale_lr \
                                        --max_grad_norm 0.1 \
                                        --lr_scheduler cosine \
                                        --lr_warmup_steps 200 \
                                        --tracker_project_name lotus_refined_base \
                                        --set_grads_to_none \
                                        --checkpointing_steps 1500 \
                                        --validation_steps 1500 \
                                        --train_batch_size 1 \
                                        --gradient_accumulation_steps 16 \
                                        --num_train_epochs 10 \
                                        --depth_weight 0.5 \
                                        # --use_ema \
                                        # --resume_from_checkpoint ../marigold_exp/training/refiner/refiner_2b/checkpoint-4000

                                        # 



