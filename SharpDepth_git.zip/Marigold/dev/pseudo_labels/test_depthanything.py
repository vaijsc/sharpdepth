from transformers import pipeline
from PIL import Image
import requests

from transformers import AutoImageProcessor, AutoModelForDepthEstimation
import torch
import numpy as np

if __name__ == "__main__":
    # load pipe
    image_processor = AutoImageProcessor.from_pretrained("depth-anything/Depth-Anything-V2-Large-hf")
    model = AutoModelForDepthEstimation.from_pretrained("depth-anything/Depth-Anything-V2-Large-hf")

    # load image
    image = Image.open("../data/kitti_complet/depth_selection/test_depth_completion_anonymous/image/0000000000.png")

    # prepare image for the model
    inputs = image_processor(images=image, return_tensors="pt")

    with torch.no_grad():
        outputs = model(**inputs)
        predicted_depth = outputs.predicted_depth

    # interpolate to original size
    prediction = torch.nn.functional.interpolate(
        predicted_depth.unsqueeze(1),
        size=image.size[::-1],
        mode="bicubic",
        align_corners=False,
    )

    breakpoint()