export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
ckpt=${1:-"../marigold_exp/training/e2eft_vae_decoder/14g/train_marigold/checkpoint/latest/"}
subfolder=${2:-"eval"}
source activate mvsplat
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/unidepth_conditioning/infer_refine_unidepthv1.py  \
    --seed 1234 \
    --checkpoint prs-eth/marigold-lcm-v1-0 \
    --base_data_dir $BASE_DATA_DIR \
    --denoise_steps 4 \
    --dataset_config config/dataset/data_kitti_eigen_test.yaml \
    --output_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/${subfolder}/dev/unidepth_conditioning/udv1_3_timestep_align/kitti/prediction \
