from omegaconf import OmegaConf
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)
from torch.utils.data import DataLoader
from src.util.depth_transform import (
    DepthNormalizerBase,
    get_depth_normalizer,
)
from src.util.config_util import (
    find_value_in_omegaconf,
    recursive_load_config,
)
import torch
from diffusers import AutoencoderKL, UNet2DConditionModel, PNDMScheduler
from src.util.metric import *
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
from PIL import Image
import seaborn as sns


def colorize(
    value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "magma_r"
):
    # if already RGB, do nothing
    if value.ndim > 2:
        if value.shape[-1] > 1:
            return value
        value = value[..., 0]
    # invalid_mask = value < 0.0001
    # normalize
    vmin = value.min() if vmin is None else vmin
    vmax = value.max() if vmax is None else vmax
    value = (value - vmin) / (vmax - vmin)  # vmin..vmax

    # set color
    cmapper = matplotlib.cm.get_cmap(cmap)
    value = cmapper(value, bytes=True)  # (nxmx4)
    # value[invalid_mask] = 0
    img = value[..., :3]
    return img


if __name__ == "__main__":
    ## Load data ##

    dataset_configs = ["config/dataset/data_hypersim_val.yaml", "config/dataset/data_vkitti_val.yaml", "config/dataset/data_eth3d.yaml", "config/dataset/data_kitti_eigen_test.yaml", "config/dataset/data_nyu_test.yaml"]
    names = ["Hypersim", "VKITTI", "ETH3D", "KITTI", "NYUv2"]
    base_data_dir = "/home/ubuntu/Working/haipd13/diffusion/data"
    config = "config/train_marigold.yaml"


    for i in range(len(dataset_configs)):
        dataset_config = dataset_configs[i]
        name = names[i]
        cfg_data = OmegaConf.load(dataset_config)
        cfg = recursive_load_config(config)
        print(cfg.depth_normalization)

        depth_transform: DepthNormalizerBase = get_depth_normalizer(
            cfg_normalizer=cfg.depth_normalization
        )

        dataset_scaled = get_dataset(
            cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.TRAIN,
            depth_transform=depth_transform
        )

        depths = []
        for i in tqdm(range(len(dataset_scaled))):
            out_scaled = dataset_scaled.__getitem__(i)

            valid_mask = out_scaled['valid_mask_raw']
            depth_scaled = out_scaled['depth_raw_linear']
            depth_scaled = out_scaled['depth_raw_norm']
            depths.append(depth_scaled)
            if i > 300:
                break
            
        depths_np = torch.stack(depths)
        # mask = (depths_np > 0.0) & (depths_np < 100.0)
        mask = (depths_np > 0.0) & (depths_np < 1.0)
        plt.figure(figsize=(12,10))
        # plt.xlabel("Meters")
        plt.xlabel("Scaled Depth")
        # sns.histplot(depths_np[mask], stat="density")
        # plt.legend(labels=names[i])
        # plt.savefig(f'temp_histo_ssi_{names[i]}.jpg')

    # plt.savefig('temp_histo_metric.jpg')
    plt.savefig('temp_histo_ssi.jpg')