export BASE_DATA_DIR=/lustre/scratch/client/vinai/users/tungdt33/depth_estimation/data/depth
export HF_HOME=/lustre/scratch/client/vinai/users/tungdt33/depth_estimation/ckpt
export BASE_CKPT_DIR=/lustre/scratch/client/vinai/users/tungdt33/depth_estimation/ckpt/hub

export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

ckpt=exp_ssi_2_si/train_marigold/checkpoint/iter_006000/
subfolder=exp_infer_ssi_2_si

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

CUDA_VISIBLE_DEVICES=$GPU_STRING python dev/tung_dev/si_refiner/infer.py  \
                                        --seed 1234 \
                                        --weights $ckpt \
                                        --config dev/tung_dev/si_refiner/configs/train_marigold.yaml \
                                        --base_data_dir $BASE_DATA_DIR \
                                        --dataset_config config/dataset/data_nyu_test.yaml \
                                        --output_dir exp_infer_ssi_2_si_nyu_6k \
                                        --checkpoint prs-eth/marigold-v1-0 # use original marigold
