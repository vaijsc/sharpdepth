#!/usr/bin/env bash
set -e
set -x

export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 
subfolder=${1:-"eval"}

python dev/analyze_unidepth_align/eval.py \
    --base_data_dir $BASE_DATA_DIR \
    --dataset_config config/dataset/data_nyu_test.yaml \
    --prediction_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/dev/null_text/temp_x0_no_inversion_wunidepth/nyuv2/prediction \
    --output_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/dev/null_text/temp_x0_no_inversion_wunidepth/nyuv2/eval_metric \
    --alignment least_square_unidepth \

    # --prediction_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/dev/null_text/temp_x0_no_inversion_wunidepth/kitti/prediction \
    # --output_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/dev/null_text/temp_x0_no_inversion_wunidepth/kitti/eval_metric \
    # --prediction_dir /home/ubuntu/Working/haipd13/diffusion/unidepth_exp/${subfolder}/unidepthv1_with_intrinsics/kitti/prediction \
    # --output_dir /home/ubuntu/Working/haipd13/diffusion/unidepth_exp/${subfolder}/unidepthv1_with_intrinsics/kitti/eval_metric \
