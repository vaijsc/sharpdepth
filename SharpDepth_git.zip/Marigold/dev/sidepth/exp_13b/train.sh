export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
source activate mvsplat
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python train.py --config dev/sidepth/exp_13b/configs/train_marigold.yaml --output_dir ../marigold_exp/training/sidepth/13b --do_not_copy_data --no_wandb \
--base_ckpt_dir stabilityai