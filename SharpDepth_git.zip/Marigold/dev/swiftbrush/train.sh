export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
source activate mvsplat
pip install peft
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/swiftbrush/train.py --config dev/swiftbrush/configs/train_marigold.yaml --output_dir ../marigold_exp/training/swiftbrush/1f --do_not_copy_data --no_wandb \
--base_ckpt_dir stabilityai --init_run ../marigold_exp/training/vkitti_only/0e/train_marigold/checkpoint/latest/


# --resume_run ../marigold_exp/training/swiftbrush/1c/train_marigold/checkpoint/latest/

# --init_run ../marigold_exp/training/vkitti_only/0e/train_marigold/checkpoint/latest/
