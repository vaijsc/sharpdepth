export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
source activate mvsplat 
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/log_depth/exp_7a/train.py --config dev/log_depth/exp_7a/configs/train_marigold.yaml --output_dir ../marigold_exp/training/log_depth/7b --do_not_copy_data --no_wandb \
--base_ckpt_dir stabilityai 
# --resume_run ../marigold_exp/training/vkitti_only/0e/train_marigold/checkpoint/latest/