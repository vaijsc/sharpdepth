export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt

PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/real_data/train.py --config dev/real_data/configs/train_marigold.yaml --output_dir ../marigold_exp/training/real_data/0i --do_not_copy_data --no_wandb \
--base_ckpt_dir stabilityai
#  --resume_run ../marigold_exp/training/vkitti_only/0e/train_marigold/checkpoint/latest/