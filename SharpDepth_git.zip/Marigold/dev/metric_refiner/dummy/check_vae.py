# Last modified: 2024-05-24
# Copyright 2023 Bingxin Ke, ETH Zurich. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# --------------------------------------------------------------------------
# If you find this code useful, we kindly ask you to cite our paper in your work.
# Please find bibtex at: https://github.com/prs-eth/Marigold#-citation
# More information about the method can be found at https://marigoldmonodepth.github.io
# --------------------------------------------------------------------------


import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from dev.metric_refiner.dummy.marigold_pipeline import MarigoldPipeline
from src.util.seeding import seed_all
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

### Visualizing purpose ###
from marigold.util.image_util import (
    chw2hwc,
    colorize_depth_maps,
    get_tv_resample_method,
    resize_max_res,
)
import torchvision
import matplotlib.pyplot as plt
from src.util.config_util import (
    find_value_in_omegaconf,
    recursive_load_config,
)
from peft import LoraConfig, PeftModel
from dev.metric_refiner.dummy.models.vae_decoder import DepthAutoencoderKL


def colorize(
    value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "viridis"
):
    # if already RGB, do nothing
    if value.ndim > 2:
        if value.shape[-1] > 1:
            return value
        value = value[..., 0]
    invalid_mask = value < 0.0001
    # normalize
    vmin = value.min() if vmin is None else vmin
    vmax = value.max() if vmax is None else vmax
    value = (value - vmin) / (vmax - vmin)  # vmin..vmax

    # set color
    cmapper = plt.get_cmap(cmap)
    value = cmapper(value, bytes=True)  # (nxmx4)
    value[invalid_mask] = 0
    img = value[..., :3]
    return img

if "__main__" == __name__:
    logging.basicConfig(level=logging.INFO)

    # -------------------- Arguments --------------------
    parser = argparse.ArgumentParser(
        description="Run single-image depth estimation using Marigold."
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default="prs-eth/marigold-v1-0",
        help="Checkpoint path or hub name.",
    )

    parser.add_argument(
        "--weights",
        type=str,
    )

    parser.add_argument(
        "--config",
        type=str,
    )
    # dataset setting
    parser.add_argument(
        "--dataset_config",
        type=str,
        required=True,
        help="Path to config file of evaluation dataset.",
    )
    parser.add_argument(
        "--base_data_dir",
        type=str,
        required=True,
        help="Path to base data directory.",
    )


    # inference setting
    parser.add_argument(
        "--denoise_steps",
        type=int,
        default=50,  # quantitative evaluation uses 50 steps
        help="Diffusion denoising steps, more steps results in higher accuracy but slower inference speed.",
    )
    parser.add_argument(
        "--ensemble_size",
        type=int,
        default=10,
        help="Number of predictions to be ensembled, more inference gives better results but runs slower.",
    )
    parser.add_argument(
        "--half_precision",
        "--fp16",
        action="store_true",
        help="Run with half-precision (16-bit float), might lead to suboptimal result.",
    )

    # resolution setting
    parser.add_argument(
        "--processing_res",
        type=int,
        default=0,
        help="Maximum resolution of processing. 0 for using input image resolution. Default: 0.",
    )
    parser.add_argument(
        "--output_processing_res",
        action="store_true",
        help="When input is resized, out put depth at resized operating resolution. Default: False.",
    )
    parser.add_argument(
        "--resample_method",
        type=str,
        default="bilinear",
        help="Resampling method used to resize images. This can be one of 'bilinear' or 'nearest'.",
    )

    parser.add_argument("--seed", type=int, default=None, help="Random seed.")

    args = parser.parse_args()

    checkpoint_path = args.checkpoint
    weight_path = args.weights
    dataset_config = args.dataset_config
    base_data_dir = args.base_data_dir
    cfg = recursive_load_config(args.config)

    denoise_steps = args.denoise_steps
    ensemble_size = args.ensemble_size
    if ensemble_size > 15:
        logging.warning("Running with large ensemble size will be slow.")
    half_precision = args.half_precision

    processing_res = args.processing_res
    match_input_res = not args.output_processing_res
    if 0 == processing_res and match_input_res is False:
        logging.warning(
            "Processing at native resolution without resizing output might NOT lead to exactly the same resolution, due to the padding and pooling properties of conv layers."
        )
    resample_method = args.resample_method

    seed = args.seed

    print(f"arguments: {args}")

    # -------------------- Preparation --------------------
    # Print out config
    logging.info(
        f"Inference settings: checkpoint = `{checkpoint_path}`, "
        f"with denoise_steps = {denoise_steps}, ensemble_size = {ensemble_size}, "
        f"processing resolution = {processing_res}, seed = {seed}; "
        f"dataset config = `{dataset_config}`."
    )

    # Random seed
    if seed is None:
        import time

        seed = int(time.time())
    seed_all(seed)


    # -------------------- Device --------------------
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
        logging.warning("CUDA is not available. Running on CPU will be slow.")
    logging.info(f"device = {device}")

    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=0)

    # -------------------- Model --------------------
    if half_precision:
        dtype = torch.float16
        variant = "fp16"
        logging.warning(
            f"Running with half precision ({dtype}), might lead to suboptimal result."
        )
    else:
        dtype = torch.float32
        variant = None

    pipe = MarigoldPipeline.from_pretrained(
        checkpoint_path, variant=variant, torch_dtype=dtype
    )
    config = LoraConfig(
        r=cfg.trainer.lora.lora_rank,
        lora_alpha=cfg.trainer.lora.lora_alpha,
        target_modules=["to_q", "to_v"],
    )
    pipe.unet.add_adapter(config)
    pipe.unet.enable_adapters()
    pipe.to(device)

    depth_vae = DepthAutoencoderKL.from_pretrained(checkpoint_path, subfolder="vae", revision=None)

    ## Load weights ##
    _model_path = os.path.join(weight_path, "unet", "diffusion_pytorch_model.bin")
    pipe.unet.load_state_dict(torch.load(_model_path, map_location=device))
    pipe.unet.to(device)
    logging.info(f"UNet parameters are loaded from {_model_path}")
    _model_path = os.path.join(weight_path, "unet", "depth_vae.pth")
    depth_vae.load_state_dict(torch.load(_model_path, map_location=device)["depth_vae"])
    depth_vae.to(device)
    
    ## ##
    i = 0
    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):  

            
            if i == 0:
                # Read input image
                # rgb_int = batch["rgb_int"].squeeze().numpy().astype(np.uint8)  # [3, H, W]
                # rgb_int = np.moveaxis(rgb_int, 0, -1)  # [H, W, 3]
                # input_image = Image.fromarray(rgb_int)
                rgb = batch["rgb_norm"].to(device)

                gt = batch["depth_raw_linear"]
                # gt_scaled = batch['depth_raw_norm']
                rgb_filename = batch["rgb_relative_path"][0]
                rgb_basename = os.path.basename(rgb_filename)

                scene_dir = os.path.join("/home/ubuntu/Working/haipd13/diffusion/unidepth_exp/eval/unidepthv1_with_intrinsics/kitti/prediction", os.path.dirname(rgb_filename))
                pred_basename = get_pred_name(rgb_basename, dataset.name_mode, suffix=".npy")
                save_to = os.path.join(scene_dir, pred_basename)
                input_depth = np.load(save_to)
                input_depth = torch.from_numpy(input_depth).unsqueeze(0).unsqueeze(0)

                
                input_depth = input_depth.clamp(1e-4, 200).to(device)
                unidepth_latent = depth_vae(input_depth.repeat(1,3,1,1), encode=True)

                image_tensor = unidepth_latent.squeeze(0).detach().cpu()

                # Define figure size
                fig_size = (40, 5)  # Customize as needed

                # Create a figure with 4 subplots
                fig, axes = plt.subplots(1, 4, figsize=fig_size, dpi=400)

                # Plot each channel in a separate subplot with a colorbar
                for i in range(4):
                    ax = axes[i]
                    channel = image_tensor[i, :, :].numpy()
                    cax = ax.imshow(channel, cmap='viridis')
                    ax.set_title(f'Channel {i+1}')
                    ax.axis('off')
                    
                    # Add colorbar
                    cbar = fig.colorbar(cax, ax=ax, orientation='vertical')
                    cbar.ax.set_ylabel('Intensity')
                plt.subplots_adjust(wspace=0, hspace=0)

                # plt.show()
                plt.savefig('temp_lat_ud_dvae.jpg')

                unidepth_og_latent = pipe.encode_rgb(input_depth.repeat(1,3,1,1))
                image_tensor = unidepth_og_latent.squeeze(0).detach().cpu()
                # Create a figure with 4 subplots
                fig, axes = plt.subplots(1, 4, figsize=fig_size, dpi=400)

                # Plot each channel in a separate subplot with a colorbar
                for i in range(4):
                    ax = axes[i]
                    channel = image_tensor[i, :, :].numpy()
                    cax = ax.imshow(channel, cmap='viridis')
                    ax.set_title(f'Channel {i+1}')
                    ax.axis('off')
                    
                    # Add colorbar
                    cbar = fig.colorbar(cax, ax=ax, orientation='vertical')
                    cbar.ax.set_ylabel('Intensity')

                # plt.show()
                plt.subplots_adjust(wspace=0, hspace=0)

                plt.savefig('temp_lat_ud_vae.jpg')


                img_lat = pipe.encode_rgb(rgb)
                image_tensor = img_lat.squeeze(0).detach().cpu()
                # Create a figure with 4 subplots
                fig, axes = plt.subplots(1, 4, figsize=fig_size, dpi=400)

                # Plot each channel in a separate subplot with a colorbar
                for i in range(4):
                    ax = axes[i]
                    channel = image_tensor[i, :, :].numpy()
                    cax = ax.imshow(channel, cmap='viridis')
                    ax.set_title(f'Channel {i+1}')
                    ax.axis('off')
                    
                    # Add colorbar
                    cbar = fig.colorbar(cax, ax=ax, orientation='vertical')
                    cbar.ax.set_ylabel('Intensity')

                # plt.show()
                plt.subplots_adjust(wspace=0, hspace=0)

                plt.savefig('temp_lat_rgb.jpg')


                scene_dir = os.path.join("/home/ubuntu/Working/haipd13/diffusion/marigold_exp/eval/kitti_eigen_test_full_0e/prediction", os.path.dirname(rgb_filename))
                pred_basename = get_pred_name(rgb_basename, dataset.name_mode, suffix=".npy")
                save_to = os.path.join(scene_dir, pred_basename)
                input_depth = np.load(save_to)
                input_depth = torch.from_numpy(input_depth).unsqueeze(0).unsqueeze(0).to(device)
                input_depth = input_depth * 2.0 - 1.0
                mg_latent = pipe.encode_rgb(input_depth.repeat(1,3,1,1))
                image_tensor = mg_latent.squeeze(0).detach().cpu()
                # Create a figure with 4 subplots
                fig, axes = plt.subplots(1, 4, figsize=fig_size, dpi=400)

                # Plot each channel in a separate subplot with a colorbar
                for i in range(4):
                    ax = axes[i]
                    channel = image_tensor[i, :, :].numpy()
                    cax = ax.imshow(channel, cmap='viridis')
                    ax.set_title(f'Channel {i+1}')
                    ax.axis('off')
                    
                    # Add colorbar
                    cbar = fig.colorbar(cax, ax=ax, orientation='vertical')
                    cbar.ax.set_ylabel('Intensity')
                plt.subplots_adjust(wspace=0, hspace=0)

                plt.savefig('temp_lat_mg_vae.jpg')



                breakpoint()
            
            i += 1
