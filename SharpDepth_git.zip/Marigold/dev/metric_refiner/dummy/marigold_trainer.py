# An official reimplemented version of Marigold training script.
# Last modified: 2024-04-29
#
# Copyright 2023 Bingxin Ke, ETH Zurich. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# --------------------------------------------------------------------------
# If you find this code useful, we kindly ask you to cite our paper in your work.
# Please find bibtex at: https://github.com/prs-eth/Marigold#-citation
# If you use or adapt this code, please attribute to https://github.com/prs-eth/marigold.
# More information about the method can be found at https://marigoldmonodepth.github.io
# --------------------------------------------------------------------------


import logging
import os
import shutil
from datetime import datetime
from typing import List, Union
import itertools

import numpy as np
import torch
from diffusers import DDPMScheduler
from omegaconf import OmegaConf
from torch.nn import Conv2d
from torch.nn.parameter import Parameter
from torch.optim import Adam
from torch.optim.lr_scheduler import LambdaLR
from torch.utils.data import DataLoader
from tqdm import tqdm
from PIL import Image

from dev.metric_refiner.dummy.marigold_pipeline import MarigoldPipeline, MarigoldDepthOutput
from dev.metric_refiner.dummy.models.vae_decoder import DepthAutoencoderKL

from src.util import metric
from src.util.data_loader import skip_first_batches
from src.util.logging_util import tb_logger, eval_dic_to_text
from src.util.loss import get_loss
from src.util.lr_scheduler import IterExponential
from src.util.metric import MetricTracker
from src.util.multi_res_noise import multi_res_noise_like
from src.util.alignment import align_depth_least_square
from src.util.seeding import generate_seed_sequence
from accelerate import DistributedDataParallelKwargs
from accelerate import Accelerator
from diffusers import AutoencoderKL, DiffusionPipeline, UNet2DConditionModel
import time
from diffusers.training_utils import EMAModel


from dev.probe_3d.model.depth_loss import DepthLoss
from dev.probe_3d.model.ssi_loss import *
from dev.probe_3d.model.virtual_normal_loss import *
from peft import LoraConfig, PeftModel
from src.util.depth_transform import *
from marigold.util.image_util import (
    chw2hwc,
    colorize_depth_maps,
    get_tv_resample_method,
    resize_max_res,
)


def to_gpu(ob, device):
    if isinstance(ob, dict):
        return {k: to_gpu(v, device) for k, v in ob.items()}
    elif isinstance(ob, tuple):
        return tuple(to_gpu(k, device) for k in ob)
    elif isinstance(ob, list):
        return [to_gpu(k, device) for k in ob]
    else:
        try:
            return ob.to(device)
        except Exception:
            return ob

class MarigoldTrainer:
    def __init__(
        self,
        cfg: OmegaConf,
        model: MarigoldPipeline,
        train_dataloader: DataLoader,
        device,
        base_ckpt_dir,
        out_dir_ckpt,
        out_dir_eval,
        out_dir_vis,
        accumulation_steps: int,
        val_dataloaders: List[DataLoader] = None,
        vis_dataloaders: List[DataLoader] = None,
    ):
        self.cfg: OmegaConf = cfg
        self.model: MarigoldPipeline = model
        self.seed: Union[int, None] = (
            self.cfg.trainer.init_seed
        )  # used to generate seed sequence, set to `None` to train w/o seeding
        self.out_dir_ckpt = out_dir_ckpt
        self.out_dir_eval = out_dir_eval
        self.out_dir_vis = out_dir_vis
        self.train_loader: DataLoader = train_dataloader
        self.val_loaders: List[DataLoader] = val_dataloaders
        self.vis_loaders: List[DataLoader] = vis_dataloaders
        self.accumulation_steps: int = accumulation_steps

        # Adapt input layers
        if 8 != self.model.unet.config["in_channels"]:
            self._replace_unet_conv_in()

        ### init accelerator 
        ddp_kwargs = DistributedDataParallelKwargs(find_unused_parameters=False)
        self.accelerator = Accelerator(
            split_batches=False, gradient_accumulation_steps=accumulation_steps, \
            mixed_precision="no", kwargs_handlers=[ddp_kwargs])
        
        self.device = self.accelerator.device
        ##########################################

        # Encode empty text prompt
        self.model.encode_empty_text()
        self.empty_text_embed = self.model.empty_text_embed.detach().clone().to(device)
        
        self.unet_model = UNet2DConditionModel.from_pretrained(os.path.join(base_ckpt_dir, cfg.model.pretrained_path), subfolder="unet", revision=None)
        self.unet_model.enable_xformers_memory_efficient_attention()

        # Add LoRA #
        config = LoraConfig(
            r=cfg.trainer.lora.lora_rank,
            lora_alpha=cfg.trainer.lora.lora_alpha,
            target_modules=["to_q", "to_v"],
        )
        self.unet_model.add_adapter(config)
        self.unet_model.enable_adapters()

        self.depth_vae = DepthAutoencoderKL.from_pretrained(os.path.join(base_ckpt_dir, cfg.model.pretrained_path), subfolder="vae", revision=None)
        # hard code ema parameters
        self.use_ema = False

        # Trainability
        del self.model.unet

        self.model.vae.requires_grad_(False)
        self.model.text_encoder.requires_grad_(False)

        ########## Move to GPU ##########
        self.model.vae.to(self.accelerator.device)
        self.model.text_encoder.to(self.accelerator.device)
        self.model.to(self.accelerator.device)
        #################################

        # Optimizer !should be defined after input layer is adapted
        lora_layers = filter(lambda p: p.requires_grad, self.unet_model.parameters())

        total_batch_size = cfg.dataloader.max_train_batch_size * self.accelerator.num_processes * accumulation_steps
        self.optimizer = torch.optim.AdamW(
            [
             {"params": lora_layers, "lr": cfg.trainer.model_lr * total_batch_size},
             {"params": self.depth_vae.parameters(), "lr": cfg.trainer.model_lr * total_batch_size}])

        # LR scheduler
        # self.lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer=self.optimizer, T_max=cfg.max_iter)
        lr_func = IterExponential(
            total_iter_length=self.cfg.lr_scheduler.kwargs.total_iter,
            final_ratio=self.cfg.lr_scheduler.kwargs.final_ratio,
            warmup_steps=self.cfg.lr_scheduler.kwargs.warmup_steps,
        )
        self.lr_scheduler = LambdaLR(optimizer=self.optimizer, lr_lambda=lr_func)

        # Loss
        self.loss = DepthLoss(max_depth=cfg.trainer.max_depth)
        self.ssi_loss = SSILoss()
        self.vnl_loss = VNLoss()
        # add L1 loss
        self.l1_loss = torch.nn.L1Loss()
        self.l2_loss = torch.nn.MSELoss()
        self.depth_transform = ScaleShiftUniDepthNormalizer()


        # Training noise scheduler
        print(os.path.join(
                base_ckpt_dir,
                cfg.trainer.training_noise_scheduler.pretrained_path,
                "scheduler",
            ))


        self.training_noise_scheduler = self.model.scheduler
        self.training_noise_scheduler.set_timesteps(self.cfg.validation.denoising_steps, device=device)

        self.prediction_type = self.training_noise_scheduler.config.prediction_type
        assert (
            self.prediction_type == self.model.scheduler.config.prediction_type
        ), "Different prediction types"
        self.scheduler_timesteps = (
            self.training_noise_scheduler.config.num_train_timesteps
        )

        # Eval metrics
        self.metric_funcs = [getattr(metric, _met) for _met in cfg.eval.eval_metrics]
        self.train_metrics = MetricTracker(*["loss", "latent_loss", "ssi_loss", "vnl_loss", "l1_loss", "l2_loss"])
        self.val_metrics = MetricTracker(*[m.__name__ for m in self.metric_funcs])
        # main metric for best checkpoint saving
        self.main_val_metric = cfg.validation.main_val_metric
        self.main_val_metric_goal = cfg.validation.main_val_metric_goal
        assert (
            self.main_val_metric in cfg.eval.eval_metrics
        ), f"Main eval metric `{self.main_val_metric}` not found in evaluation metrics."
        self.best_metric = 1e8 if "minimize" == self.main_val_metric_goal else -1e8

        # Settings
        self.max_epoch = self.cfg.max_epoch
        self.max_iter = self.cfg.max_iter
        self.gt_depth_type = self.cfg.gt_depth_type
        self.gt_mask_type = self.cfg.gt_mask_type
        self.save_period = self.cfg.trainer.save_period
        self.backup_period = self.cfg.trainer.backup_period
        self.val_period = self.cfg.trainer.validation_period
        self.vis_period = self.cfg.trainer.visualization_period

        # Multi-resolution noise
        self.apply_multi_res_noise = self.cfg.multi_res_noise is not None
        if self.apply_multi_res_noise:
            self.mr_noise_strength = self.cfg.multi_res_noise.strength
            self.annealed_mr_noise = self.cfg.multi_res_noise.annealed
            self.mr_noise_downscale_strategy = (
                self.cfg.multi_res_noise.downscale_strategy
            )

        # Internal variables
        self.epoch = 1
        self.n_batch_in_epoch = 0  # batch index in the epoch, used when resume training
        self.effective_iter = 0  # how many times optimizer.step() is called
        self.in_evaluation = False
        self.global_seed_sequence: List = []  # consistent global seed sequence, used to seed random generator, to ensure consistency when resuming


        # set up accelerate 
        self.unet_model, self.depth_vae, self.optimizer, self.lr_scheduler = self.accelerator.prepare(
            self.unet_model, self.depth_vae, self.optimizer, self.lr_scheduler) 
        self.train_loader = self.accelerator.prepare(self.train_loader) 
        self.val_loaders = self.accelerator.prepare(self.val_loaders) 
        self.vis_loaders = self.accelerator.prepare(self.vis_loaders) 
        ######################################################
        


    def _replace_unet_conv_in(self):
        # replace the first layer to accept 8 in_channels
        _weight = self.model.unet.conv_in.weight.clone()  # [320, 4, 3, 3]
        _bias = self.model.unet.conv_in.bias.clone()  # [320]
        _weight = _weight.repeat((1, 2, 1, 1))  # Keep selected channel(s)
        # half the activation magnitude
        _weight *= 0.5
        # new conv_in channel
        _n_convin_out_channel = self.model.unet.conv_in.out_channels
        _new_conv_in = Conv2d(
            8, _n_convin_out_channel, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1)
        )
        _new_conv_in.weight = Parameter(_weight)
        _new_conv_in.bias = Parameter(_bias)
        self.model.unet.conv_in = _new_conv_in
        logging.info("Unet conv_in layer is replaced")
        # replace config
        self.model.unet.config["in_channels"] = 8
        logging.info("Unet config is updated")
        return

    def train(self, t_end=None):
        logging.info("Start training")

        device = self.accelerator.device
        if self.in_evaluation:
            logging.info(
                "Last evaluation was not finished, will do evaluation before continue training."
            )
            self.validate()

        self.train_metrics.reset()
        accumulated_step = 0

        self.optimizer.zero_grad()  
        for epoch in range(self.epoch, self.max_epoch + 1):
            self.epoch = epoch
            logging.debug(f"epoch: {self.epoch}")

            # Skip previous batches when resume
            start_time = time.time()
            for batch in skip_first_batches(self.train_loader, self.n_batch_in_epoch):

                # globally consistent random generators
                if self.seed is not None:
                    local_seed = self._get_next_seed()
                    rand_num_generator = torch.Generator(device=device)
                    rand_num_generator.manual_seed(local_seed)
                else:
                    rand_num_generator = None

                with self.accelerator.accumulate(self.unet_model, self.depth_vae):
                    batch = to_gpu(batch, device)
                    with self.accelerator.autocast():
                        rgb = batch["rgb_norm"]
                        depth_gt_for_latent = batch["depth_raw_linear"]
                        depth_gt_for_latent = torch.clamp(depth_gt_for_latent, self.cfg.trainer.min_depth, self.cfg.trainer.max_depth)
                        if self.gt_mask_type is not None:
                            valid_mask_for_latent = batch[self.gt_mask_type]


                        batch_size = rgb.shape[0]
                        
                        unidepth_pred = batch['depth_filled_linear']
                        unidepth_pred = unidepth_pred.clamp(1e-4, 200)
                        # Normalize depth map
                        # valid_mask = torch.logical_and((unidepth_pred > dataset.min_depth), (unidepth_pred < dataset.max_depth)).bool()

                        # unidepth_norm_pred, _max, _min = self.depth_transform(unidepth_pred)
                        unidepth_norm_pred = unidepth_pred
                        
                        # Encode image
                        with torch.no_grad():
                            rgb_latent = self.model.encode_rgb(rgb)  # [B, 4, h, w]

                        unidepth_latent = self.depth_vae(unidepth_norm_pred.repeat(1,3,1,1), encode=True)
                        # Encode GT depth
                        timesteps = torch.full((batch_size,), self.training_noise_scheduler.timesteps[-2], dtype=torch.int64, device=device)
                        # timesteps = torch.ones((batch_size,), dtype=torch.int64, device=device)
                        # timesteps = timesteps * (self.training_noise_scheduler.config.num_train_timesteps -1)

                        # Add noise to the latents (diffusion forward process)
                        noise = torch.randn(
                                unidepth_latent.shape,
                                device=device,
                                generator=rand_num_generator,
                            )  # [B, 4, h, w]

                        # Add noise to the latents (diffusion forward process)
                        noisy_latents = self.training_noise_scheduler.add_noise(unidepth_latent, noise, timesteps)
                        
                        # Text embedding
                        text_embed = self.empty_text_embed.to(device).repeat(
                            (batch_size, 1, 1)
                        )  # [B, 77, 1024]

                        # Concat rgb and depth latents
                        cat_latents = torch.cat(
                            [rgb_latent, noisy_latents], dim=1
                        )  # [B, 8, h, w]
                        cat_latents = cat_latents.float()

                        # Predict the noise residual
                        model_pred = self.unet_model(cat_latents, timesteps, text_embed).sample  # [B, 4, h, w]
                        if torch.isnan(model_pred).any():
                            logging.warning("model_pred contains NaN.")

                        # Get the target for loss depending on the prediction type
                        x0 = self.training_noise_scheduler.step(model_pred, timesteps[0], noisy_latents).pred_original_sample
                        pred_depth = self.depth_vae(x0, encode=False) 
                        
                        # depth_metric = pred_depth * (_max - _min)  + _min

                        mask = depth_gt_for_latent > 0.0
                        latent_loss = self.loss(pred_depth, depth_gt_for_latent)
                        ssi_loss = self.ssi_loss(pred_depth, depth_gt_for_latent, mask)
                        
                        intrinsics = batch['intrinsics'].to(device)
                        mask = depth_gt_for_latent > 0.0
                        vnl_loss = self.vnl_loss(pred_depth, depth_gt_for_latent, mask, intrinsics)

                        pred_inv_depth_all = 1/pred_depth
                        inv_depth_gt_all = 1/depth_gt_for_latent.clamp(self.cfg.trainer.min_depth, self.cfg.trainer.max_depth)
                        l1_loss = self.l1_loss(pred_inv_depth_all, inv_depth_gt_all)
                        l2_loss = self.l2_loss(pred_inv_depth_all, inv_depth_gt_all)

                        loss = latent_loss + vnl_loss + ssi_loss + l1_loss +  l2_loss * 0
                    
                    self.accelerator.backward(loss)
                    self.train_metrics.update("loss", loss.item())
                    self.train_metrics.update("latent_loss", latent_loss.item())
                    self.train_metrics.update("ssi_loss", ssi_loss.item())
                    self.train_metrics.update("vnl_loss", vnl_loss.item())
                    self.train_metrics.update("l1_loss", l1_loss.item())
                    self.train_metrics.update("l2_loss", l2_loss.item())

                    self.n_batch_in_epoch += 1
                    # autocast context end
                # accum grad end

                if self.accelerator.sync_gradients:
                    time_per_iter = time.time() - start_time
                    start_time = time.time()

                    params_to_clip = itertools.chain(self.unet_model.parameters(), self.depth_vae.parameters())
                    self.accelerator.clip_grad_norm_(params_to_clip, 1.0)
                    self.optimizer.step()
                    self.lr_scheduler.step()
                    self.optimizer.zero_grad()

                    if self.use_ema:
                        self.ema_unet.step(self.unet_model.parameters())


                    self.effective_iter += 1

                    if self.accelerator.is_main_process:
                        # Log to tensorboard
                        accumulated_loss = self.train_metrics.result()["loss"]
                        latent_loss = self.train_metrics.result()["latent_loss"]
                        vnl_loss = self.train_metrics.result()["vnl_loss"]
                        ssi_loss = self.train_metrics.result()["ssi_loss"]
                        l1_loss = self.train_metrics.result()["l1_loss"]
                        l2_loss = self.train_metrics.result()["l2_loss"]
                        tb_logger.log_dic(
                            {
                                f"train/{k}": v
                                for k, v in self.train_metrics.result().items()
                            },
                            global_step=self.effective_iter,
                        )
                        tb_logger.writer.add_scalar(
                            "lr",
                            self.lr_scheduler.get_last_lr()[0],
                            global_step=self.effective_iter,
                        )
                        tb_logger.writer.add_scalar(
                            "n_batch_in_epoch",
                            self.n_batch_in_epoch,
                            global_step=self.effective_iter,
                        )
                        logging.info(
                            f"iter {self.effective_iter:5d} (epoch {epoch:2d}): loss={accumulated_loss:.2f}, latent_loss={latent_loss:.2f}, vnl_loss={vnl_loss:.2f}, ssi_loss={ssi_loss:.2f}, l1_loss={l1_loss:.2f}, l2_loss={l2_loss:.2f}, time_per_iter={time_per_iter}"
                        )
                        self.train_metrics.reset()

                        # Per-step callback
                        self._train_step_callback()

                        # End of training
                        if self.max_iter > 0 and self.effective_iter >= self.max_iter:
                            self.save_checkpoint(
                                ckpt_name=self._get_backup_ckpt_name(),
                                save_train_state=False,
                            )
                            logging.info("Training ended.")
                            return
                        # Time's up
                        elif t_end is not None and datetime.now() >= t_end:
                            self.save_checkpoint(ckpt_name="latest", save_train_state=True)
                            logging.info("Time is up, training paused.")
                            return

                        torch.cuda.empty_cache()
                        # <<< Effective batch end <<<

            # Epoch end
            self.n_batch_in_epoch = 0

        # epoch end
    # training end

    def _train_step_callback(self):
        """Executed after every iteration"""
        # Save backup (with a larger interval, without training states)
        if self.backup_period > 0 and 0 == self.effective_iter % self.backup_period:
            self.save_checkpoint(
                ckpt_name=self._get_backup_ckpt_name(), save_train_state=False
            )

        _is_latest_saved = False
        # Validation
        if self.val_period > 0 and 0 == self.effective_iter % self.val_period:
            self.in_evaluation = True  # flag to do evaluation in resume run if validation is not finished
            self.save_checkpoint(ckpt_name="latest", save_train_state=True)
            _is_latest_saved = True

            if self.use_ema:
                # Store the UNet parameters temporarily and load the EMA parameters to perform inference.
                self.ema_unet.store(self.unet_model.parameters())
                self.ema_unet.copy_to(self.unet_model.parameters())
                
            self.validate()

            if self.use_ema:
                # Store the UNet parameters temporarily and load the EMA parameters to perform inference.
                self.ema_unet.restore(self.unet_model.parameters())

            self.in_evaluation = False
            self.save_checkpoint(ckpt_name="latest", save_train_state=True)

        # Save training checkpoint (can be resumed)
        if (
            self.save_period > 0
            and 0 == self.effective_iter % self.save_period
            and not _is_latest_saved
        ):
            self.save_checkpoint(ckpt_name="latest", save_train_state=True)

        # Visualization
        if self.vis_period > 0 and 1 == self.effective_iter % self.vis_period: # visualize at fist - testing purpose
            if self.use_ema:
                # Store the UNet parameters temporarily and load the EMA parameters to perform inference.
                self.ema_unet.store(self.unet_model.parameters())
                self.ema_unet.copy_to(self.unet_model.parameters())

            self.visualize()

            if self.use_ema:
                # Store the UNet parameters temporarily and load the EMA parameters to perform inference.
                self.ema_unet.restore(self.unet_model.parameters())

    def validate(self):
        for i, val_loader in enumerate(self.val_loaders):
            val_dataset_name = val_loader.dataset.disp_name
            val_metric_dic = self.validate_single_dataset(
                data_loader=val_loader, metric_tracker=self.val_metrics
            )
            logging.info(
                f"Iter {self.effective_iter}. Validation metrics on `{val_dataset_name}`: {val_metric_dic}"
            )
            tb_logger.log_dic(
                {f"val/{val_dataset_name}/{k}": v for k, v in val_metric_dic.items()},
                global_step=self.effective_iter,
            )
            # save to file
            eval_text = eval_dic_to_text(
                val_metrics=val_metric_dic,
                dataset_name=val_dataset_name,
                sample_list_path=val_loader.dataset.filename_ls_path,
            )
            _save_to = os.path.join(
                self.out_dir_eval,
                f"eval-{val_dataset_name}-iter{self.effective_iter:06d}.txt",
            )
            with open(_save_to, "w+") as f:
                f.write(eval_text)

            # Update main eval metric
            if 0 == i:
                main_eval_metric = val_metric_dic[self.main_val_metric]
                if (
                    "minimize" == self.main_val_metric_goal
                    and main_eval_metric < self.best_metric
                    or "maximize" == self.main_val_metric_goal
                    and main_eval_metric > self.best_metric
                ):
                    self.best_metric = main_eval_metric
                    logging.info(
                        f"Best metric: {self.main_val_metric} = {self.best_metric} at iteration {self.effective_iter}"
                    )
                    # Save a checkpoint
                    self.save_checkpoint(
                        ckpt_name=self._get_backup_ckpt_name(), save_train_state=False
                    )

    def visualize(self):
        for val_loader in self.vis_loaders:
            vis_dataset_name = val_loader.dataset.disp_name
            vis_out_dir = os.path.join(
                self.out_dir_vis, self._get_backup_ckpt_name(), vis_dataset_name
            )
            os.makedirs(vis_out_dir, exist_ok=True)
            _ = self.validate_single_dataset(
                data_loader=val_loader,
                metric_tracker=self.val_metrics,
                save_to_dir=vis_out_dir,
            )

    @torch.no_grad()
    def validate_single_dataset(
        self,
        data_loader: DataLoader,
        metric_tracker: MetricTracker,
        save_to_dir: str = None,
    ):
        metric_tracker.reset()

        # Generate seed sequence for consistent evaluation
        val_init_seed = self.cfg.validation.init_seed
        val_seed_ls = generate_seed_sequence(val_init_seed, len(data_loader))
        device = self.device

        for i, batch in enumerate(
            tqdm(data_loader, desc=f"evaluating on {data_loader.dataset.disp_name}"),
            start=1,
        ):
            assert 1 == data_loader.batch_size
            batch = to_gpu(batch, device)

            # GT depth
            depth_raw_ts = batch["depth_raw_linear"]
            depth_raw_ts = depth_raw_ts.to(self.device)
            valid_mask_ts = batch["valid_mask_raw"]
            valid_mask_ts = valid_mask_ts.to(self.device)

            # Read input image
            rgb = batch["rgb_norm"]
            batch_size = rgb.shape[0]
            
            unidepth_pred = batch['depth_filled_linear']
            unidepth_pred = unidepth_pred.clamp(1e-4, 200)
            # Normalize depth map

            # valid_mask = torch.logical_and((unidepth_pred > dataset.min_depth), (unidepth_pred < dataset.max_depth)).bool()
            # unidepth_norm_pred, _max, _min = self.depth_transform(unidepth_pred)
            
            unidepth_norm_pred = unidepth_pred
            
            # Encode image
            rgb_latent = self.model.encode_rgb(rgb)  # [B, 4, h, w]

            unidepth_latent = self.depth_vae(unidepth_norm_pred.repeat(1,3,1,1), encode=True)
            # Encode GT depth
            timesteps = torch.full((batch_size,), self.training_noise_scheduler.timesteps[-2], dtype=torch.int64, device=device)
            # timesteps = torch.ones((batch_size,), dtype=torch.int64, device=device)
            # timesteps = timesteps * (self.training_noise_scheduler.config.num_train_timesteps -1)

            seed = val_seed_ls.pop()
            if seed is None:
                generator = None
            else:
                generator = torch.Generator(device=self.device)
                generator.manual_seed(seed)

            # Add noise to the latents (diffusion forward process)
            noise = torch.randn(
                    unidepth_latent.shape,
                    device=device,
                    generator=generator,
                )  # [B, 4, h, w]

            # Add noise to the latents (diffusion forward process)
            noisy_latents = self.training_noise_scheduler.add_noise(unidepth_latent, noise, timesteps)
            
            # Text embedding
            text_embed = self.empty_text_embed.to(device).repeat(
                (batch_size, 1, 1)
            )  # [B, 77, 1024]

            # Concat rgb and depth latents
            cat_latents = torch.cat(
                [rgb_latent, noisy_latents], dim=1
            )  # [B, 8, h, w]
            cat_latents = cat_latents.float()

            # Predict the noise residual
            model_pred = self.unet_model(cat_latents, timesteps, text_embed).sample  # [B, 4, h, w]
            if torch.isnan(model_pred).any():
                logging.warning("model_pred contains NaN.")

            # Get the target for loss depending on the prediction type
            v0 = self.training_noise_scheduler.step(model_pred, timesteps[0], noisy_latents).pred_original_sample
            pred_depth = self.depth_vae(v0, encode=False)            
            depth_pred = pred_depth.squeeze().cpu().numpy()

            depth_colored = colorize_depth_maps(depth_pred, depth_pred.min(), depth_pred.max(), cmap="Spectral").squeeze()  # [3, H, W], value in (0, 1)
            depth_colored = (depth_colored * 255).astype(np.uint8)
            depth_colored_hwc = chw2hwc(depth_colored)
            depth_colored_img = Image.fromarray(depth_colored_hwc)

            # if "least_square" == self.cfg.eval.alignment:
            #     depth_pred, scale, shift = align_depth_least_square(
            #         gt_arr=depth_raw,
            #         pred_arr=depth_pred,
            #         valid_mask_arr=valid_mask,
            #         return_scale_shift=True,
            #         max_resolution=self.cfg.eval.align_max_res,
            #     )
            # else:
            #     raise RuntimeError(f"Unknown alignment type: {self.cfg.eval.alignment}")
            # Clip to dataset min max
            depth_pred = np.clip(
                depth_pred,
                a_min=data_loader.dataset.min_depth,
                a_max=data_loader.dataset.max_depth,
            )

            # Evaluate
            sample_metric = []
            depth_pred_ts = torch.from_numpy(depth_pred).to(self.device)

            for met_func in self.metric_funcs:
                _metric_name = met_func.__name__
                _metric = met_func(depth_pred_ts, depth_raw_ts.squeeze(0).squeeze(0), valid_mask_ts.squeeze(0).squeeze(0)).item()
                sample_metric.append(_metric.__str__())
                metric_tracker.update(_metric_name, _metric)

            # Save as 16-bit uint png
            if save_to_dir is not None:
                img_name = batch["rgb_relative_path"][0].replace("/", "_")
                png_save_path = os.path.join(save_to_dir, f"{img_name}")
                depth_colored_img.save(png_save_path)

        return metric_tracker.result()

    def _get_next_seed(self):
        if 0 == len(self.global_seed_sequence):
            self.global_seed_sequence = generate_seed_sequence(
                initial_seed=self.seed,
                length=self.max_iter * self.accumulation_steps,
            )
            logging.info(
                f"Global seed sequence is generated, length={len(self.global_seed_sequence)}"
            )
        return self.global_seed_sequence.pop()

    def save_checkpoint(self, ckpt_name, save_train_state):
        ckpt_dir = os.path.join(self.out_dir_ckpt, ckpt_name)
        logging.info(f"Saving checkpoint to: {ckpt_dir}")
        # Backup previous checkpoint
        temp_ckpt_dir = None
        if os.path.exists(ckpt_dir) and os.path.isdir(ckpt_dir):
            temp_ckpt_dir = os.path.join(
                os.path.dirname(ckpt_dir), f"_old_{os.path.basename(ckpt_dir)}"
            )
            if os.path.exists(temp_ckpt_dir):
                shutil.rmtree(temp_ckpt_dir, ignore_errors=True)
            os.rename(ckpt_dir, temp_ckpt_dir)
            logging.debug(f"Old checkpoint is backed up at: {temp_ckpt_dir}")

        # Save UNet
        unet_path = os.path.join(ckpt_dir, "unet")
        self.accelerator.unwrap_model(self.unet_model).save_pretrained(unet_path, safe_serialization=False)
        if self.use_ema:
            self.ema_unet.save_pretrained(os.path.join(ckpt_dir, "ema_unet"))

        depth_vae_path = os.path.join(ckpt_dir, "unet", "depth_vae.pth")
        checkpoint = {"depth_vae": self.accelerator.unwrap_model(self.depth_vae).state_dict(),}
        torch.save(checkpoint, depth_vae_path)

        logging.info(f"UNet is saved to: {unet_path}")

        if save_train_state:
            state = {
                "optimizer": self.optimizer.state_dict(),
                "lr_scheduler": self.lr_scheduler.state_dict(),
                "config": self.cfg,
                "effective_iter": self.effective_iter,
                "epoch": self.epoch,
                "n_batch_in_epoch": self.n_batch_in_epoch,
                "best_metric": self.best_metric,
                "in_evaluation": self.in_evaluation,
                "global_seed_sequence": self.global_seed_sequence,
            }
            train_state_path = os.path.join(ckpt_dir, "trainer.ckpt")
            torch.save(state, train_state_path)
            # iteration indicator
            f = open(os.path.join(ckpt_dir, self._get_backup_ckpt_name()), "w")
            f.close()

            logging.info(f"Trainer state is saved to: {train_state_path}")

        # Remove temp ckpt
        if temp_ckpt_dir is not None and os.path.exists(temp_ckpt_dir):
            shutil.rmtree(temp_ckpt_dir, ignore_errors=True)
            logging.debug("Old checkpoint backup is removed.")

    def load_checkpoint(
        self, ckpt_path, load_trainer_state=True, resume_lr_scheduler=True
    ):
        logging.info(f"Loading checkpoint from: {ckpt_path}")
        # Load UNet
        _model_path = os.path.join(ckpt_path, "unet", "diffusion_pytorch_model.bin")

        
        self.unet_model.load_state_dict(
            torch.load(_model_path, map_location=self.device)
        )
        self.unet_model.to(self.device)
        logging.info(f"UNet parameters are loaded from {_model_path}")

        _model_path = os.path.join(ckpt_path, "ema_unet", "diffusion_pytorch_model.bin")
        self.ema_unet.load_state_dict(
            torch.load(_model_path, map_location=self.device)
        )
        self.ema_unet.to(self.device)
        logging.info(f"Ema UNet parameters are loaded from {_model_path}")


        _model_path = os.path.join(ckpt_path, "metric_vae", "diffusion_pytorch_model.bin")
        self.model.vae.load_state_dict(
            torch.load(_model_path, map_location=self.device)
        )
        self.model.vae.to(self.device)

        # metricvae_path = os.path.join(ckpt_dir, "metric_vae")
        # self.accelerator.unwrap_model(self.model.metricvae).save_pretrained(metricvae_path, safe_serialization=False)


        # Load training states
        if load_trainer_state:
            checkpoint = torch.load(os.path.join(ckpt_path, "trainer.ckpt"))
            self.effective_iter = checkpoint["effective_iter"]
            self.epoch = checkpoint["epoch"]
            self.n_batch_in_epoch = checkpoint["n_batch_in_epoch"]
            self.in_evaluation = checkpoint["in_evaluation"]
            self.global_seed_sequence = checkpoint["global_seed_sequence"]

            self.best_metric = checkpoint["best_metric"]

            self.optimizer.load_state_dict(checkpoint["optimizer"])
            logging.info(f"optimizer state is loaded from {ckpt_path}")

            if resume_lr_scheduler:
                self.lr_scheduler.load_state_dict(checkpoint["lr_scheduler"])
                logging.info(f"LR scheduler state is loaded from {ckpt_path}")

        logging.info(
            f"Checkpoint loaded from: {ckpt_path}. Resume from iteration {self.effective_iter} (epoch {self.epoch})"
        )
        return

    def _get_backup_ckpt_name(self):
        return f"iter_{self.effective_iter:06d}"