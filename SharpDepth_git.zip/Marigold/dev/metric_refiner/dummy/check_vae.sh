export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
ckpt=${1:-"../marigold_exp/training/metric_refiner/dummy/train_marigold/checkpoint/latest/"}
subfolder=${2:-"eval"}

PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/metric_refiner/dummy/check_vae.py  \
    --weights $ckpt \
    --seed 1234 \
    --config dev/metric_refiner/dummy/configs/train_marigold.yaml \
    --base_data_dir $BASE_DATA_DIR \
    --dataset_config config/dataset/data_kitti_eigen_test.yaml \
