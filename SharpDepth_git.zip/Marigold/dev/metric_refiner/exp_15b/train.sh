export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt


export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

GPU_STRING=$1
GPU_COUNT=$(echo $GPU_STRING | tr ',' '\n' | wc -l)
FIRST_GPU=$(echo $GPU_STRING | cut -d ',' -f 1)
echo "Number of GPUs: $GPU_COUNT - First GPU: $FIRST_GPU - Available GPU: $GPU_STRING"

source activate mvsplat
pip install peft
CUDA_VISIBLE_DEVICES=$GPU_STRING torchrun --nnodes 1 --nproc_per_node $GPU_COUNT \
                                        --rdzv-backend=c10d --rdzv-endpoint=localhost:0 dev/metric_refiner/exp_15b/train.py \
                                        --config dev/metric_refiner/dummy/configs/train_marigold.yaml \
                                        --output_dir ../marigold_exp/training/metric_refiner/exp_15b --do_not_copy_data --no_wandb \
                                        --base_ckpt_dir prs-eth 

# CUDA_VISIBLE_DEVICES=$GPU_STRING torchrun --nnodes 1 --nproc_per_node $GPU_COUNT \
#                                         --rdzv-backend=c10d --rdzv-endpoint=localhost:0 dev/e2eft_vae_decoder/exp_14a/train.py \
#                                         --config dev/e2eft_vae_decoder/exp_14a/configs/train_marigold.yaml \
#                                         --output_dir ../marigold_exp/training/e2eft_vae_decoder/14a --do_not_copy_data --no_wandb \
#                                         --base_ckpt_dir prs-eth 

# --init_run ../marigold_exp/training/vkitti_only/0e/train_marigold/checkpoint/latest/
# --resume_run ../marigold_exp/training/swiftbrush/1c/train_marigold/checkpoint/latest/
# --init_run ../marigold_exp/training/vkitti_only/0e/train_marigold/checkpoint/latest/