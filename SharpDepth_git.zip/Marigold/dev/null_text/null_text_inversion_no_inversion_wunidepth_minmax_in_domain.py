from typing import Optional, Union, Tuple, List, Callable, Dict
from tqdm.notebook import tqdm
import torch
from diffusers import StableDiffusionPipeline, DDIMScheduler
import torch.nn.functional as nnf
import numpy as np
import abc
import shutil
from torch.optim.adam import Adam
from PIL import Image
from marigold import MarigoldPipeline
from src.util.depth_transform import *

class NullInversion:
    
    def original_step(self, model_output: Union[torch.FloatTensor, np.ndarray], timestep: int, sample: Union[torch.FloatTensor, np.ndarray]):
        # this is the denoise process
        prev_timestep = timestep - self.scheduler.config.num_train_timesteps // self.scheduler.num_inference_steps
        alpha_prod_t = self.scheduler.alphas_cumprod[timestep]
        alpha_prod_t_prev = self.scheduler.alphas_cumprod[prev_timestep] if prev_timestep >= 0 else self.scheduler.final_alpha_cumprod
        beta_prod_t = 1 - alpha_prod_t

        ######## with pred mode start #######
        pred_type = self.scheduler.config.prediction_type
        if pred_type == "epsilon":
            pred_original_sample = (sample - beta_prod_t ** (0.5) * model_output) / alpha_prod_t ** (0.5)
            pred_epsilon = model_output
        elif pred_type == "v_prediction":
            pred_original_sample = (alpha_prod_t**0.5) * sample - (beta_prod_t**0.5) * model_output
            pred_epsilon = (alpha_prod_t**0.5) * model_output + (beta_prod_t**0.5) * sample
        else:
            raise ValueError(f"Unknown prediction type {pred_type}")

        return pred_original_sample

    def prev_step(self, model_output: Union[torch.FloatTensor, np.ndarray], timestep: int, sample: Union[torch.FloatTensor, np.ndarray]):
        # this is the denoise process
        prev_timestep = timestep - self.scheduler.config.num_train_timesteps // self.scheduler.num_inference_steps
        alpha_prod_t = self.scheduler.alphas_cumprod[timestep]
        alpha_prod_t_prev = self.scheduler.alphas_cumprod[prev_timestep] if prev_timestep >= 0 else self.scheduler.final_alpha_cumprod
        beta_prod_t = 1 - alpha_prod_t

        ######## with pred mode start #######
        pred_type = self.scheduler.config.prediction_type
        if pred_type == "epsilon":
            pred_original_sample = (sample - beta_prod_t ** (0.5) * model_output) / alpha_prod_t ** (0.5)
            pred_epsilon = model_output
        elif pred_type == "v_prediction":
            pred_original_sample = (alpha_prod_t**0.5) * sample - (beta_prod_t**0.5) * model_output
            pred_epsilon = (alpha_prod_t**0.5) * model_output + (beta_prod_t**0.5) * sample
        else:
            raise ValueError(f"Unknown prediction type {pred_type}")

        ######## with pred mode end #######

        # pred_original_sample = (sample - beta_prod_t ** 0.5 * model_output) / alpha_prod_t ** 0.5

        # pred_sample_direction = (1 - alpha_prod_t_prev) ** 0.5 * model_output

        pred_sample_direction = (1 - alpha_prod_t_prev) ** 0.5 * pred_epsilon

        prev_sample = alpha_prod_t_prev ** 0.5 * pred_original_sample + pred_sample_direction

        return prev_sample
    
    def next_step(self, model_output: Union[torch.FloatTensor, np.ndarray], timestep: int, sample: Union[torch.FloatTensor, np.ndarray]):
        # this is the inverse process
        timestep, next_timestep = min(timestep - self.scheduler.config.num_train_timesteps // self.scheduler.num_inference_steps, 999), timestep
        alpha_prod_t = self.scheduler.alphas_cumprod[timestep] if timestep >= 0 else self.scheduler.final_alpha_cumprod
        alpha_prod_t_next = self.scheduler.alphas_cumprod[next_timestep]
        beta_prod_t = 1 - alpha_prod_t

        ########### daal with pred mode start ###########
        pred_type = self.scheduler.config.prediction_type

        # print(pred_type)
        # breakpoint()

        if pred_type == "epsilon":
            next_original_sample = (sample - beta_prod_t ** (0.5) * model_output) / alpha_prod_t ** (0.5)
            pred_epsilon = model_output
        elif pred_type == "v_prediction":
            next_original_sample = (alpha_prod_t**0.5) * sample - (beta_prod_t**0.5) * model_output
            pred_epsilon = (alpha_prod_t**0.5) * model_output + (beta_prod_t**0.5) * sample
        else:
            raise ValueError(f"Unknown prediction type {pred_type}")
        ########### daal with pred mode end ###########
        # next_original_sample = (sample - beta_prod_t ** 0.5 * model_output) / alpha_prod_t ** 0.5

        next_sample_direction = (1 - alpha_prod_t_next) ** 0.5 * pred_epsilon
        next_sample = alpha_prod_t_next ** 0.5 * next_original_sample + next_sample_direction
        return next_sample
    
    def get_noise_pred_single(self, latents, t, context):
        noise_pred = self.model.unet(latents, t, encoder_hidden_states=context)["sample"]
        return noise_pred

    def get_noise_pred(self, latents, t, is_forward=True, context=None):
        latents_input = torch.cat([latents] * 2)
        if context is None:
            context = self.context
        guidance_scale = 1 if is_forward else GUIDANCE_SCALE
        noise_pred = self.model.unet(latents_input, t, encoder_hidden_states=context)["sample"]
        noise_pred_uncond, noise_prediction_text = noise_pred.chunk(2)
        noise_pred = noise_pred_uncond + guidance_scale * (noise_prediction_text - noise_pred_uncond)
        if is_forward:
            latents = self.next_step(noise_pred, t, latents)
        else:
            latents = self.prev_step(noise_pred, t, latents)
        return latents

    @torch.no_grad()
    def latent2image(self, latents, return_type='np'):
        latents = 1 / 0.18215 * latents.detach()
        image = self.model.vae.decode(latents)['sample']
        if return_type == 'np':
            image = (image / 2 + 0.5).clamp(0, 1)
            image = image.cpu().permute(0, 2, 3, 1).numpy()[0]
            image = (image * 255).astype(np.uint8)
        return image

    @torch.no_grad()
    def image2latent(self, image):
        with torch.no_grad():
            if type(image) is Image:
                image = np.array(image)
            if type(image) is torch.Tensor and image.dim() == 4:
                latents = image
            else:
                image = torch.from_numpy(image).float() / 127.5 - 1
                image = image.permute(2, 0, 1).unsqueeze(0).to(device)
                latents = self.model.vae.encode(image)['latent_dist'].mean
                latents = latents * 0.18215
        return latents

    @torch.no_grad()
    def init_prompt(self, prompt: str):
        uncond_input = self.model.tokenizer(
            [""], padding="max_length", max_length=self.model.tokenizer.model_max_length,
            return_tensors="pt"
        )
        uncond_embeddings = self.model.text_encoder(uncond_input.input_ids.to(self.model.device))[0]
        text_input = self.model.tokenizer(
            [prompt],
            padding="max_length",
            max_length=self.model.tokenizer.model_max_length,
            truncation=True,
            return_tensors="pt",
        )
        text_embeddings = self.model.text_encoder(text_input.input_ids.to(self.model.device))[0]
        self.context = torch.cat([uncond_embeddings, text_embeddings])
        self.prompt = prompt

    @torch.no_grad()
    def ddim_loop(self, latent):
        uncond_embeddings, cond_embeddings = self.context.chunk(2)
        all_latent = [latent]
        # from clear img to noise
        latent = latent.clone().detach()
        for i in range(NUM_DDIM_STEPS):
            t = self.model.scheduler.timesteps[len(self.model.scheduler.timesteps) - i - 1]
            noise_pred = self.get_noise_pred_single(latent, t, cond_embeddings)

            latent = self.next_step(noise_pred, t, latent)
            all_latent.append(latent)
        return all_latent

    @property
    def scheduler(self):
        return self.model.scheduler

    @torch.no_grad()
    def ddim_inversion(self, image):
        latent = self.image2latent(image)
        image_rec = self.latent2image(latent)
        ddim_latents = self.ddim_loop(latent)
        return image_rec, ddim_latents

    def null_optimization(self, latents, num_inner_steps, epsilon):
        uncond_embeddings, cond_embeddings = self.context.chunk(2)
        uncond_embeddings_list = []
        latent_cur = latents[-1]
        bar = tqdm(total=num_inner_steps * NUM_DDIM_STEPS)
        for i in range(NUM_DDIM_STEPS):
            uncond_embeddings = uncond_embeddings.clone().detach()
            uncond_embeddings.requires_grad = True
            optimizer = Adam([uncond_embeddings], lr=1e-2 * (1. - i / 100.))
            latent_prev = latents[len(latents) - i - 2]
            t = self.model.scheduler.timesteps[i]
            with torch.no_grad():
                noise_pred_cond = self.get_noise_pred_single(latent_cur, t, cond_embeddings)
            for j in range(num_inner_steps):
                noise_pred_uncond = self.get_noise_pred_single(latent_cur, t, uncond_embeddings)
                noise_pred = noise_pred_uncond + GUIDANCE_SCALE * (noise_pred_cond - noise_pred_uncond)
                latents_prev_rec = self.prev_step(noise_pred, t, latent_cur)
                loss = nnf.mse_loss(latents_prev_rec, latent_prev)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                loss_item = loss.item()
                bar.update()
                if loss_item < epsilon + i * 2e-5:
                    break
            for j in range(j + 1, num_inner_steps):
                bar.update()
            uncond_embeddings_list.append(uncond_embeddings[:1].detach())
            with torch.no_grad():
                context = torch.cat([uncond_embeddings, cond_embeddings])
                latent_cur = self.get_noise_pred(latent_cur, t, False, context)
        bar.close()
        return uncond_embeddings_list
    
    def invert(self, image_path: str, prompt: str, offsets=(0,0,0,0), num_inner_steps=10, early_stop_epsilon=1e-5, verbose=False):
        self.init_prompt(prompt)
        image_gt = load_512(image_path, *offsets)
        if verbose:
            print("DDIM inversion...")
        image_rec, ddim_latents = self.ddim_inversion(image_gt)
        if verbose:
            print("Null-text optimization...")
        uncond_embeddings = self.null_optimization(ddim_latents, num_inner_steps, early_stop_epsilon)
        return (image_gt, image_rec), ddim_latents[-1], uncond_embeddings
        
    
    def __init__(self, model):
        # scheduler = DDIMScheduler(beta_start=0.00085, beta_end=0.012, beta_schedule="scaled_linear", clip_sample=False,
        #                           set_alpha_to_one=False)
        self.model = model
        self.tokenizer = self.model.tokenizer
        self.model.scheduler.set_timesteps(NUM_DDIM_STEPS)
        self.prompt = None
        self.context = None


def sig_loss(depth_pr, depth_gt, mask, sigma=0.85, eps=0.001, only_mean=False):
    """
    SigLoss
        This follows `AdaBins <https://arxiv.org/abs/2011.14141>`_.
        adapated from DINOv2 code

    Args:
        depth_pr (FloatTensor): predicted depth
        depth_gt (FloatTensor): groundtruth depth
        eps (float): to avoid exploding gradient
    """
    # ignore invalid depth pixels
    valid = mask
    depth_pr = depth_pr[valid]
    depth_gt = depth_gt[valid]

    g = torch.log(depth_pr + eps) - torch.log(depth_gt + eps)

    loss = g.pow(2).mean() - sigma * g.mean().pow(2)
    loss = loss.sqrt()
    return loss


class MarigoldNullInversion(NullInversion):
    def __init__(self, model):
        super().__init__(model)
        self.depth_transform =  ScaleShiftDepthNormalizer()

    def get_noise_pred_single(self, image_latent, depth_latent, t, context):
        unet_input = torch.cat(
                [image_latent, depth_latent], dim=1
            )  # this order is important
        noise_pred = self.model.unet(unet_input, t, encoder_hidden_states=context)["sample"]
        return noise_pred

    def get_noise_pred(self, image_latent, latents, t, is_forward=True, context=None):
        unet_input = torch.cat(
                [image_latent, latents], dim=1
            )  # this order is important

        noise_pred = self.model.unet(unet_input, t, encoder_hidden_states=context)["sample"]

        if is_forward:
            latents = self.next_step(noise_pred, t, latents)
        else:
            latents = self.prev_step(noise_pred, t, latents)
        return latents


    @torch.no_grad()
    def latent2image(self, latents, return_type='np'):
        latents = latents.detach() / self.model.depth_latent_scale_factor
        image = self.model.vae.decode(latents)['sample']
        if return_type == 'np':
            image = (image / 2 + 0.5).clamp(0, 1)
            image = image.cpu().permute(0, 2, 3, 1).numpy()[0]
        return image

    @torch.no_grad()
    def depth2latent(self, image):
        with torch.no_grad():
            latents = self.model.vae.encode(image.unsqueeze(0).unsqueeze(0).repeat(1,3,1,1).to(device))['latent_dist'].mean
            latents = latents * self.model.depth_latent_scale_factor

        return latents

    @torch.no_grad()
    def ddim_inversion(self, image, depth):
        image_latent = self.image2latent(image)
        depth_latent = self.depth2latent(depth)
        image_rec = self.latent2image(depth_latent)
        ddim_latents = self.ddim_loop(image_latent, depth_latent)
        return image_rec, ddim_latents, image_latent

    def invert(self, image_path: str, depth_gt_path, marigold_pred, valid_mask_gt, prompt: str, num_inner_steps=10, early_stop_epsilon=1e-5, verbose=False):
        self.init_prompt(prompt)
        image_gt = image_path
        depth_gt = depth_gt_path

        if verbose:
            print("DDIM inversion...")
        # image_rec, ddim_latents, image_latent = self.ddim_inversion(image_gt, depth_start)
        # Get xT and image latent
        image_latent = self.image2latent(image_gt)
        depth_latent = torch.randn(
            image_latent.shape,
            device=device,)

        if verbose:
            print("Null-text optimization...")
        uncond_embeddings = None
        depth_z0 = self.null_x0_optimization(depth_latent, image_latent, num_inner_steps, early_stop_epsilon, depth_gt, marigold_pred, valid_mask_gt)
        
        return depth_z0

    @torch.no_grad()
    def ddim_loop(self, image_latent, depth_latent):
        uncond_embeddings, cond_embeddings = self.context.chunk(2)
        all_latent = [depth_latent]
        # from clear img to noise
        depth_latent = depth_latent.clone().detach()
        for i in range(NUM_DDIM_STEPS):
            t = self.model.scheduler.timesteps[len(self.model.scheduler.timesteps) - i - 1]
            noise_pred = self.get_noise_pred_single(image_latent, depth_latent, t, uncond_embeddings)
            depth_latent = self.next_step(noise_pred, t, depth_latent)
            all_latent.append(depth_latent)
        return all_latent

    def null_x0_optimization(self, latents, image_latent, num_inner_steps, epsilon, depth_gt, marigold_pred, valid_mask_gt):
        uncond_embeddings, cond_embeddings = self.context.chunk(2)
        uncond_embeddings_list = []

        latent_cur = latents
        image_latent_curr = image_latent
        
        depth_gt = (depth_gt.unsqueeze(0).unsqueeze(0).to(device) + 1.0) / 2.0
        valid_mask_gt = valid_mask_gt.to(device).unsqueeze(0).unsqueeze(0)
        marigold_pred = torch.from_numpy(marigold_pred).to(device).unsqueeze(0).unsqueeze(0)

        bar = tqdm(total=num_inner_steps * NUM_DDIM_STEPS)

        for i in range(NUM_DDIM_STEPS): #iterate DDIM timesteps 

            image_latent_curr = image_latent_curr.clone().detach()
            image_latent_curr.requires_grad = True
            optimizer = Adam([image_latent_curr], lr=1e-2 * (1. - i / 100.))
            t = self.model.scheduler.timesteps[i]

            

            for j in range(num_inner_steps):
                noise_pred_uncond = self.get_noise_pred_single(image_latent_curr, latent_cur, t, uncond_embeddings) #z_t-1 given uncond embedding
                noise_pred = noise_pred_uncond 
                                
                ## What if we instead optimize the latent to be as close as x0 as possible ##
                latents_z0 = self.original_step(noise_pred, t, latent_cur)
                depth_z0 = self.model.decode_depth(latents_z0)
                # shift to [0, 1]
                depth_z0 = torch.clip(depth_z0, -1.0, 1.0)
                depth_z0 = (depth_z0 + 1.0) / 2.0
                
                l1_loss = nnf.l1_loss(depth_z0[valid_mask_gt], depth_gt[valid_mask_gt])
                si_loss = sig_loss(depth_z0, depth_gt, valid_mask_gt).mean()
                grad_loss = gradient_loss(depth_z0[0,0], marigold_pred[0,0])
                
                loss = si_loss + grad_loss*0.75 + l1_loss


                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                loss_item = loss.item()

                bar.update()
                if loss_item < epsilon + i * 2e-5:
                    break
            for j in range(j + 1, num_inner_steps):
                bar.update()

            # Update current latent with optimized embedding - stupid Hai #
            with torch.no_grad():
                latent_cur = self.get_noise_pred(image_latent_curr, latent_cur, t, False, uncond_embeddings)

            # uncond_embeddings_list.append(uncond_embeddings[:1].detach())
            uncond_embeddings_list.append(image_latent_curr.detach())

        bar.close()

        latents_z0 = self.original_step(noise_pred, t, latent_cur)
        # depth_z0 = self.model.decode_depth(latents_z0)
        # depth_z0 = (depth_z0 + 1.0) / 2.0
        return latents_z0




def align_depth_least_square(
    gt_arr: np.ndarray,
    pred_arr: np.ndarray,
    valid_mask_arr: np.ndarray,
    return_scale_shift=True,
    max_resolution=None,
):
    ori_shape = pred_arr.shape  # input shape

    gt = gt_arr.squeeze()  # [H, W]
    pred = pred_arr.squeeze()
    valid_mask = valid_mask_arr.squeeze()

    # Downsample
    if max_resolution is not None:
        scale_factor = np.min(max_resolution / np.array(ori_shape[-2:]))
        if scale_factor < 1:
            downscaler = torch.nn.Upsample(scale_factor=scale_factor, mode="nearest")
            gt = downscaler(torch.as_tensor(gt).unsqueeze(0)).numpy()
            pred = downscaler(torch.as_tensor(pred).unsqueeze(0)).numpy()
            valid_mask = (
                downscaler(torch.as_tensor(valid_mask).unsqueeze(0).float())
                .bool()
                .numpy()
            )

    assert (
        gt.shape == pred.shape == valid_mask.shape
    ), f"{gt.shape}, {pred.shape}, {valid_mask.shape}"

    gt_masked = gt[valid_mask].reshape((-1, 1))
    pred_masked = pred[valid_mask].reshape((-1, 1))

    # numpy solver
    _ones = np.ones_like(pred_masked)
    A = np.concatenate([pred_masked, _ones], axis=-1)
    X = np.linalg.lstsq(A, gt_masked, rcond=None)[0]
    scale, shift = X

    aligned_pred = pred_arr * scale + shift

    # restore dimensions
    aligned_pred = aligned_pred.reshape(ori_shape)

    if return_scale_shift:
        return aligned_pred, scale, shift
    else:
        return aligned_pred
    
def abs_relative_difference_full(output, target, valid_mask=None):
    actual_output = output
    actual_target = target
    abs_relative_diff = torch.abs(actual_output - actual_target) / actual_target
    if valid_mask is not None:
        abs_relative_diff[~valid_mask] = 0
        n = valid_mask.sum((-1, -2))
    else:
        n = output.shape[-1] * output.shape[-2]
    return abs_relative_diff



import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from marigold import MarigoldPipeline
from src.util.seeding import seed_all
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from src.util.depth_transform import *
from dev.probe_3d.model.depth_loss import *

if __name__ == "__main__":
    MY_TOKEN = ''
    LOW_RESOURCE = False 
    NUM_DDIM_STEPS = 50
    GUIDANCE_SCALE = 7.5
    MAX_NUM_WORDS = 77
    device = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')
    # ldm_stable = StableDiffusionPipeline.from_pretrained("stabilityai/stable-diffusion-2").to(device)
    ldm_stable = MarigoldPipeline.from_pretrained("prs-eth/marigold-v1-0").to(device)

    try:
        ldm_stable.disable_xformers_memory_efficient_attention()
    except AttributeError:
        print("Attribute disable_xformers_memory_efficient_attention() is missing")
    tokenizer = ldm_stable.tokenizer
    
    # depth_path = "../data/hypersim_processed/test/ai_001_010/depth_plane_cam_00_fr0000.png"
    # image_path = "../data/hypersim_processed/test/ai_001_010/rgb_cam_00_fr0000.png"
    prompt = ""
    
    null_inversion = MarigoldNullInversion(ldm_stable)

    logging.basicConfig(level=logging.INFO)
    # -------------------- Arguments --------------------
    parser = argparse.ArgumentParser(
        description="Run single-image depth estimation using Marigold."
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default="prs-eth/marigold-v1-0",
        help="Checkpoint path or hub name.",
    )

    # dataset setting
    parser.add_argument(
        "--dataset_config",
        type=str,
        required=True,
        help="Path to config file of evaluation dataset.",
    )
    parser.add_argument(
        "--base_data_dir",
        type=str,
        required=True,
        help="Path to base data directory.",
    )

    parser.add_argument(
        "--output_dir", type=str, required=True, help="Output directory."
    )

    # inference setting
    parser.add_argument(
        "--denoise_steps",
        type=int,
        default=50,  # quantitative evaluation uses 50 steps
        help="Diffusion denoising steps, more steps results in higher accuracy but slower inference speed.",
    )
    parser.add_argument(
        "--ensemble_size",
        type=int,
        default=10,
        help="Number of predictions to be ensembled, more inference gives better results but runs slower.",
    )
    parser.add_argument(
        "--half_precision",
        "--fp16",
        action="store_true",
        help="Run with half-precision (16-bit float), might lead to suboptimal result.",
    )

    # resolution setting
    parser.add_argument(
        "--processing_res",
        type=int,
        default=0,
        help="Maximum resolution of processing. 0 for using input image resolution. Default: 0.",
    )
    parser.add_argument(
        "--output_processing_res",
        action="store_true",
        help="When input is resized, out put depth at resized operating resolution. Default: False.",
    )
    parser.add_argument(
        "--resample_method",
        type=str,
        default="bilinear",
        help="Resampling method used to resize images. This can be one of 'bilinear' or 'nearest'.",
    )

    parser.add_argument("--seed", type=int, default=None, help="Random seed.")

    args = parser.parse_args()

    checkpoint_path = args.checkpoint
    dataset_config = args.dataset_config
    base_data_dir = args.base_data_dir
    output_dir = args.output_dir

    denoise_steps = args.denoise_steps
    ensemble_size = args.ensemble_size
    if ensemble_size > 15:
        logging.warning("Running with large ensemble size will be slow.")
    half_precision = args.half_precision

    processing_res = args.processing_res
    match_input_res = not args.output_processing_res
    if 0 == processing_res and match_input_res is False:
        logging.warning(
            "Processing at native resolution without resizing output might NOT lead to exactly the same resolution, due to the padding and pooling properties of conv layers."
        )
    resample_method = args.resample_method

    seed = args.seed

    print(f"arguments: {args}")

    # -------------------- Preparation --------------------
    # Print out config
    logging.info(
        f"Inference settings: checkpoint = `{checkpoint_path}`, "
        f"with denoise_steps = {denoise_steps}, ensemble_size = {ensemble_size}, "
        f"processing resolution = {processing_res}, seed = {seed}; "
        f"dataset config = `{dataset_config}`."
    )

    # Random seed
    if seed is None:
        import time

        seed = int(time.time())
    seed_all(seed)

    def check_directory(directory):
        if os.path.exists(directory):
            response = (
                input(
                    f"The directory '{directory}' already exists. Are you sure to continue? (y/n): "
                )
                .strip()
                .lower()
            )
            if "y" == response:
                pass
            elif "n" == response:
                print("Exiting...")
                exit()
            else:
                print("Invalid input. Please enter 'y' (for Yes) or 'n' (for No).")
                check_directory(directory)  # Recursive call to ask again

    check_directory(output_dir)
    os.makedirs(output_dir, exist_ok=True)
    logging.info(f"output dir = {output_dir}")

    # -------------------- Device --------------------
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
        logging.warning("CUDA is not available. Running on CPU will be slow.")
    logging.info(f"device = {device}")

    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.TRAIN,
        depth_transform=ScaleShiftDepthNormalizer()
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=0, shuffle=True)

    # -------------------- Model --------------------
    if half_precision:
        dtype = torch.float16
        variant = "fp16"
        logging.warning(
            f"Running with half precision ({dtype}), might lead to suboptimal result."
        )
    else:
        dtype = torch.float32
        variant = None
    

    depth_transform = ScaleShiftUniDepthNormalizer()

    pipe: MarigoldPipeline = MarigoldPipeline.from_pretrained("prs-eth/marigold-lcm-v1-0").to(device)


    # -------------------- Inference and saving --------------------
    for batch in tqdm(
        dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
    ):
        # Read input image
        image_path = batch['rgb_int'].squeeze(0).permute(1,2,0).cpu().numpy()
        depth_path_gt = batch['depth_raw_linear'].squeeze(0).squeeze(0).to(device)
        valid_mask_gt = batch['valid_mask_raw'].squeeze(0).squeeze(0) #[1 = valid]

        # _min, _max =  depth_path_gt[valid_mask_gt].min(),  depth_path_gt[valid_mask_gt].max()
        # depth_path_gt = (depth_path_gt - _min) / (_max - _min) * 2 - 1

        rgb_filename = batch["rgb_relative_path"][0]
        rgb_basename = os.path.basename(rgb_filename)
        scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
        if not os.path.exists(scene_dir):
            os.makedirs(scene_dir)
        pred_basename = get_pred_name(
            rgb_basename, dataset.name_mode, suffix=".npy"
        )
        save_to = os.path.join(scene_dir, pred_basename)

        # unidepth_path = os.path.join("../unidepth_exp/eval/unidepthv1_with_intrinsics/kitti/prediction", os.path.dirname(rgb_filename), pred_basename)
        # unidepth_pred = np.load(unidepth_path)
        
        # pred_sky_basename = get_pred_name(rgb_basename, dataset.name_mode, suffix="_sky.npy")
        # sky_scene_dir = os.path.join("../data/kitti_unidepth/test", os.path.dirname(rgb_filename))

        # unidepth_sky_path = os.path.join(sky_scene_dir, pred_sky_basename)
        # unidepth_pred_sky = np.load(unidepth_sky_path)
        # valid_mask_ = (torch.tensor(unidepth_pred_sky).to(device) != 10).bool()

        # valid_mask_ = torch.logical_and((torch.from_numpy(unidepth_pred) > 0), (torch.from_numpy(unidepth_pred) < 200)).bool()
        # unidepth_norm_pred, _max, _min = depth_transform(torch.from_numpy(unidepth_pred).clamp(0, 200), valid_mask_)
        # depth_path_gt = unidepth_norm_pred

        # unidepth_pred = torch.tensor(unidepth_pred).to(device)

        unidepth_pred = batch['depth_filled_linear'].squeeze(0).squeeze(0).to(device)
        valid_mask_ = batch['valid_mask_filled'].squeeze(0).squeeze(0).to(device)
        _min, _max =  unidepth_pred[valid_mask_].min(),  unidepth_pred[valid_mask_].max()
        depth_path_gt = (depth_path_gt - _min) / (_max - _min) * 2 - 1

        ## If marigold prediction is not available, use LCM to generate ##
        try:
            marigold_path = os.path.join("../marigold_exp/eval/kitti_eigen_test_full_0e/prediction", os.path.dirname(rgb_filename), pred_basename)
            marigold_pred = np.load(marigold_path)
        except:
            input_image = Image.fromarray(image_path.astype(np.uint8))
            pipe_out = pipe(input_image,         
                        denoising_steps = 4,
                        ensemble_size = 5,)
            marigold_pred: np.ndarray = pipe_out.depth_np

        depth_z0 = null_inversion.invert(image_path, depth_path_gt, marigold_pred, valid_mask_gt, prompt, verbose=True)

        depth_pred = depth_z0.squeeze(0).squeeze(0).detach().cpu().numpy()

        if os.path.exists(save_to):
            logging.warning(f"Existing file: '{save_to}' will be overwritten")
        np.save(save_to, depth_pred)

