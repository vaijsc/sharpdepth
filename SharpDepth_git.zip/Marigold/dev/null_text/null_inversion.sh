export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/null_text/null_text_inversion.py  \
    --seed 1234 \
    --base_data_dir $BASE_DATA_DIR \
    --denoise_steps 50 \
    --dataset_config config/dataset/data_vkitti_val_10.yaml \
    --output_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/${subfolder}/dev/null_text/temp_x0/vkitti/prediction \
