export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
ckpt=${1:-"../marigold_exp/training/e2eft_vae_decoder/14p/train_marigold/checkpoint/latest/"}
subfolder=${2:-"eval"}

source activate mvsplat
PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python dev/consistency_vae/infer.py  \
    --seed 1234 \
    --base_data_dir $BASE_DATA_DIR \
    --dataset_config config/dataset/data_nyu_test.yaml \
    --output_dir /home/ubuntu/Working/haipd13/diffusion/marigold_exp/${subfolder}/consistency_vae/nyuv2/prediction \
