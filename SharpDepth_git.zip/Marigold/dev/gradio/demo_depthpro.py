from __future__ import annotations

import gradio as gr
from gradio_imageslider import ImageSlider
from huggingface_hub import login
from tqdm import tqdm

from gradio import Examples

import functools
import os
import tempfile
import warnings
import zipfile
from io import BytesIO

#### #####
import argparse
import logging
import os
import shutil
from datetime import datetime, timedelta
from typing import List
from pathlib import Path
from packaging import version
import math
import itertools
import numpy as np
from PIL import Image

from tqdm import tqdm
from omegaconf import OmegaConf


import torch
import torch.nn.functional as F
import torchvision
from torch.utils.data import ConcatDataset, DataLoader

from src.dataset import BaseDepthDataset, DatasetMode, get_dataset
from src.dataset.mixed_sampler import MixedBatchSampler
from src.trainer import get_trainer_cls
from src.util.logging_util import config_logging
from src.util.config_util import (
                                    find_value_in_omegaconf,
                                    recursive_load_config,
                                )
from src.util.depth_transform import (
                                        DepthNormalizerBase,
                                        get_depth_normalizer,
                                    )
from src.util.slurm_util import get_local_scratch_dir, is_on_slurm


import transformers
from transformers import AutoTokenizer, PretrainedConfig


import diffusers
from diffusers import UNet2DConditionModel, DDPMScheduler, AutoencoderKL
from diffusers.utils.import_utils import is_xformers_available
from diffusers.utils.torch_utils import is_compiled_module
from diffusers.optimization import get_scheduler
from diffusers.training_utils import EMAModel
from ema_pytorch import EMA

from accelerate.logging import get_logger
from accelerate import Accelerator, DataLoaderConfiguration
from accelerate.utils import ProjectConfiguration, set_seed

# for visualization
from src.util.metric import *
from src.util.alignment import *
import matplotlib.pyplot as plt
import matplotlib
from marigold.util.image_util import (
                                            chw2hwc,
                                            colorize_depth_maps,
                                            get_tv_resample_method,
                                            resize_max_res,
                                        )
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from unidepth.models import UniDepthV1, UniDepthV2
from unidepth.utils import colorize, image_grid
import open3d

from mmseg.apis import inference_model, init_model, show_result_pyplot
import mmcv
import depth_pro



def get_pcd_base(H, W, u0, v0, fx, fy):
    x_row = np.arange(0, W)
    x = np.tile(x_row, (H, 1))
    x = x.astype(np.float32)
    u_m_u0 = x - u0

    y_col = np.arange(0, H)  # y_col = np.arange(0, height)
    y = np.tile(y_col, (W, 1)).T
    y = y.astype(np.float32)
    v_m_v0 = y - v0

    x = u_m_u0 / fx
    y = v_m_v0 / fy
    z = np.ones_like(x)
    pw = np.stack([x, y, z], axis=2)  # [h, w, c]
    return pw

def reconstruct_pcd(depth, fx, fy, u0, v0, pcd_base=None, mask=None):
    if type(depth) == torch.__name__:
        depth = depth.cpu().numpy().squeeze()
    if pcd_base is None:
        H, W = depth.shape
        pcd_base = get_pcd_base(H, W, u0, v0, fx, fy)
    pcd = depth[:, :, None] * pcd_base
    if mask:
        pcd[mask] = 0
    return pcd

@torch.no_grad()
def encode_image(vae, rgb):
    rgb_latent = vae.encode(rgb).latent_dist.sample()
    rgb_latent = rgb_latent * vae.config.scaling_factor
    return rgb_latent

@torch.no_grad()
def encode_depth(vae, depth):
    depth_latent = vae.encode(depth.repeat(1, 3, 1, 1)).latent_dist.sample()
    depth_latent = depth_latent * vae.config.scaling_factor
    return depth_latent

@torch.no_grad()
def decode_image(vae, latent):
    # scale latent
    latent = latent / vae.config.scaling_factor
    # decode
    z = vae.post_quant_conv(latent)
    rgb = vae.decoder(z)
    return rgb


def to_gpu(ob, device):
    if isinstance(ob, dict):
        return {k: to_gpu(v, device) for k, v in ob.items()}
    elif isinstance(ob, tuple):
        return tuple(to_gpu(k, device) for k in ob)
    elif isinstance(ob, list):
        return [to_gpu(k, device) for k in ob]
    else:
        try:
            return ob.to(device)
        except Exception:
            return ob

def encode_empty_text(tokenizer, text_encoder):
    """
    Encode text embedding for empty prompt
    """
    prompt = ""
    text_inputs = tokenizer(
        prompt,
        padding="do_not_pad",
        max_length=tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
    text_input_ids = text_inputs.input_ids.to(text_encoder.device)
    empty_text_embed = text_encoder(text_input_ids)[0]

    return empty_text_embed


def import_model_class_from_model_name_or_path(pretrained_model_name_or_path: str, revision: str):
    text_encoder_config = PretrainedConfig.from_pretrained(
        pretrained_model_name_or_path, subfolder="text_encoder", revision=revision
    )
    model_class = text_encoder_config.architectures[0]

    if model_class == "CLIPTextModel":
        from transformers import CLIPTextModel

        return CLIPTextModel
    elif model_class == "CLIPTextModelWithProjection":
        from transformers import CLIPTextModelWithProjection

        return CLIPTextModelWithProjection
    else:
        raise ValueError(f"{model_class} is not supported.")


def colorize(
    value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "magma_r"
):
    # if already RGB, do nothing
    if value.ndim > 2:
        if value.shape[-1] > 1:
            return value
        value = value[..., 0]
    invalid_mask = value < 0.0001
    # normalize
    vmin = value.min() if vmin is None else vmin
    vmax = value.max() if vmax is None else vmax
    value = (value - vmin) / (vmax - vmin)  # vmin..vmax

    # set color
    cmapper = matplotlib.cm.get_cmap(cmap)
    value = cmapper(value, bytes=True)  # (nxmx4)
    value[invalid_mask] = 0
    img = value[..., :3]
    return img


def process_image(
    path_input,
):
    with torch.no_grad():
        pil_image = Image.open(path_input)
        np_image = np.array(pil_image)

        if np_image.shape[2] == 4:
            mask = np_image[..., 3:] / 255.0
            np_image = np_image[..., :3] * mask + 255 * (1 - mask)

        rgb_torch = torch.from_numpy(np_image).permute(2, 0, 1).float()
        rgb_torch = center_crop_to_divisible_by_8(rgb_torch)

        # if rgb_torch.size(1) * rgb_torch.size(2) > 2073600:
        #     rgb_torch = torch.nn.functional.interpolate(rgb_torch[None], scale_factor=0.5, mode="bilinear")[0]

        rgb = (rgb_torch / 255.0) * 2 - 1
        rgb = rgb.unsqueeze(0).to(device)
        predictions = unidepth_model.infer(rgb_torch)
        depth_unidepth = predictions["depth"]

        
        image = transform(np_image)
        # Run inference.
        prediction = depthpro_model.infer(image.to(device))
        depthpro_depth = prediction["depth"].cpu().numpy()  # Depth in [m].
 
        # rgb_int = np.moveaxis(np_image, 0, -1)  # [H, W, 3]
        seg_results = inference_model(sky_model, mmcv.imread(rgb_torch.squeeze().permute(1,2,0).cpu().numpy().astype(np.uint8)))
        sky_mask = seg_results.pred_sem_seg.data
        sky_mask = (sky_mask != 10).bool().unsqueeze(0)
        # sky_mask        = torch.ones_like(depth_unidepth).bool()
        
        disp_unidepth = 1/depth_unidepth.clamp(min=1e-6)
        transformed_output  = unidepth_transform(disp_unidepth, sky_mask=sky_mask)
        norm_depth_unidepth = transformed_output["norm_depth"]
        norm_depth_unidepth[~sky_mask] = -1.0 # mask out sky

        # Encode image
        rgb_latent = encode_image(vae, rgb).to(dtype=weight_dtype)
        lotus_timesteps = torch.ones((rgb_latent.shape[0],), device=device) * (noise_scheduler.config.num_train_timesteps - 1)
        lotus_timesteps = lotus_timesteps.long()

        unidepth_latent = encode_depth(vae, norm_depth_unidepth).to(dtype=weight_dtype)

        batch_empty_text_embed = empty_text_emb.repeat((rgb_latent.shape[0], 1, 1)).to(device, dtype=weight_dtype)
        batch_task_emb = task_emb.repeat((rgb_latent.shape[0], 1)).to(device, dtype=weight_dtype)

        lotus_input = torch.cat([rgb_latent.detach(), torch.randn_like(rgb_latent)], dim=1)  # this order is important

        if args.use_ema:
            lotus_pred = ema_model(lotus_input, lotus_timesteps, batch_empty_text_embed, class_labels=batch_task_emb).sample
        else:
            lotus_pred  = student_unet(lotus_input, lotus_timesteps, batch_empty_text_embed, class_labels=batch_task_emb).sample
        
        # --------------------------------- 
        # decode pred_latent to depth
        latent = lotus_pred / vae.config.scaling_factor
        z = vae.post_quant_conv(latent)
        lotus_depth = vae.decoder(z).mean(dim=1, keepdim=True)
        # ---------------------------------

        # --------------------------------- 
        # calculate difference
        l1_error            = torch.abs(lotus_depth -  norm_depth_unidepth)
        l1_error            = l1_error/l1_error.max()
        l1_error            = l1_error.clip(0, 1)
        l1_error[~sky_mask] = 0.0
        latent_mask = torch.nn.functional.interpolate(l1_error, scale_factor=1/8)
        # ---------------------------------

        noise                   = torch.randn_like(unidepth_latent)
        noisy_lotus_latent      = noise_scheduler.add_noise(lotus_pred, noise, lotus_timesteps)
        noisy_latent            = noisy_lotus_latent * latent_mask + unidepth_latent * (1 - latent_mask)
        student_input           = torch.cat([rgb_latent, noisy_latent], dim=1)

        # ---------------------------------

        pred_latent     = student_unet(student_input, lotus_timesteps, encoder_hidden_states=batch_empty_text_embed, class_labels=batch_task_emb).sample
        
        # --------------------------------- 
        # decode pred_latent to depth
        latent = pred_latent / vae.config.scaling_factor
        z = vae.post_quant_conv(latent)
        pred_depth = vae.decoder(z).mean(dim=1, keepdim=True)
        # ---------------------------------
        
        depth_pred = (pred_depth.detach().squeeze().clip(-1,1).cpu().numpy() + 1.0) / 2.0
        depth_scale = disp_unidepth.squeeze().cpu().numpy()

        valid_mask = 1 - l1_error
        valid_mask[~sky_mask] = 0.0

        depth, scale, shift = align_depth_least_square(
                                                        gt_arr=depth_scale,
                                                        pred_arr=depth_pred,
                                                        valid_mask_arr=valid_mask.cpu().numpy() > 0.5,
                                                        return_scale_shift=True,
                                                        max_resolution=None,
                                                )
        depth = 1/depth
        color_depth = colorize(depth, vmin=depth.min(), vmax=depth.max(), cmap='Spectral')
        color_unidepth = colorize(depth_unidepth.squeeze().cpu().numpy(), vmin=depth.min(), vmax=depth.max(), cmap='Spectral')
        color_depthpro = colorize(depthpro_depth, vmin=depthpro_depth.min(), vmax=depth.max(), cmap='Spectral')

        name_base, name_ext = os.path.splitext(os.path.basename(path_input))

        path_output_dir = tempfile.mkdtemp()
        path_out_vis = os.path.join(path_output_dir, f"{name_base}_depth_colored.png")
        Image.fromarray(color_depth).save(path_out_vis)

        path_out_vis_uni = os.path.join(path_output_dir, f"{name_base}_depth_colored_uni.png")
        # Image.fromarray(color_unidepth).save(path_out_vis_uni)

        Image.fromarray(color_depthpro).save(path_out_vis_uni)


        path_out_vis_rgb = os.path.join(path_output_dir, f"{name_base}_rgb.png")
        pil_image.save(path_out_vis_rgb)


        intrinsics = predictions['intrinsics'][0].cpu().numpy()
        lidar = reconstruct_pcd(depth, intrinsics[0,0], intrinsics[1,1], intrinsics[0,2], intrinsics[1,2])
        pcd = open3d.geometry.PointCloud()
        
        np_image = rgb_torch.permute(1,2,0).cpu().numpy()
        pcd.points = open3d.utility.Vector3dVector(lidar.reshape(-1,3)[:, :3])
        pcd.colors = open3d.utility.Vector3dVector(np_image.reshape(-1,3)[..., :3]/255.0)
        pcd.rotate(pcd.get_rotation_matrix_from_xyz((0,np.pi,np.pi)))

        path_out_vis_pcd = os.path.join(path_output_dir, f"{name_base}_point_cloud_colored.ply")
        cl, ind = pcd.remove_statistical_outlier(nb_neighbors=20,
                                                    std_ratio=2.0)
        pcd = pcd.select_by_index(ind)
        open3d.io.write_point_cloud(path_out_vis_pcd, pcd)

        # pcd.estimate_normals(
        #     search_param=open3d.geometry.KDTreeSearchParamHybrid(radius=0.01, max_nn=30)
        # )

        # path_out_vis_pcd = os.path.join(path_output_dir, f"{name_base}_depth_colored.gltf")
        # print("run Poisson surface reconstruction")
        # with open3d.utility.VerbosityContextManager(open3d.utility.VerbosityLevel.Debug) as cm:
        #     mesh_raw, densities = open3d.geometry.TriangleMesh.create_from_point_cloud_poisson(
        #         pcd, width=0, scale=1.1, linear_fit=True
        #     )

        # voxel_size = max(mesh_raw.get_max_bound() - mesh_raw.get_min_bound()) / 256
        # print(f"voxel_size = {voxel_size:e}")
        # mesh = mesh_raw.simplify_vertex_clustering(
        #     voxel_size=voxel_size,
        #     contraction=open3d.geometry.SimplificationContraction.Average,
        # )

        # # vertices_to_remove = densities < np.quantile(densities, 0.001)
        # # mesh.remove_vertices_by_mask(vertices_to_remove)
        # bbox = pcd.get_axis_aligned_bounding_box()
        # mesh_crop = mesh.crop(bbox)
        # open3d.io.write_triangle_mesh(path_out_vis_pcd, mesh_crop, write_triangle_uvs=True)


        # lidar = reconstruct_pcd(depth_scale, intrinsics[0,0], intrinsics[1,1], intrinsics[0,2], intrinsics[1,2])
        # pcd = open3d.geometry.PointCloud()
        
        # pcd.points = open3d.utility.Vector3dVector(lidar.reshape(-1,3)[:, :3])
        # pcd.colors = open3d.utility.Vector3dVector(np_image.reshape(-1,3)[..., :3]/255.0)
        # path_out_vis_pcd_uni = os.path.join(path_output_dir, f"{name_base}_depth_colored_uni.ply")

        # open3d.io.write_point_cloud(path_out_vis_pcd_uni, pcd)


        # depth_colored.save(path_out_vis)
    return (
        [path_out_vis_uni, path_out_vis],
        [path_out_vis_uni, path_out_vis, path_out_vis_rgb, path_out_vis_pcd],
    )


def process_image_check(path_input):
    if path_input is None:
        raise gr.Error(
            "Missing image in the first pane: upload a file or use one from the gallery below."
        )


def center_crop_to_divisible_by_8(rgb_torch):
    _, height, width = rgb_torch.shape
    
    # Calculate new dimensions that are divisible by 8
    new_height = (height // 8) * 8
    new_width = (width // 8) * 8
    
    # Calculate the amount to crop from each side for center crop
    crop_top = (height - new_height) // 2
    crop_bottom = crop_top + new_height
    crop_left = (width - new_width) // 2
    crop_right = crop_left + new_width
    
    # Perform the center crop
    cropped_image = rgb_torch[:, crop_top:crop_bottom, crop_left:crop_right]
    
    return cropped_image


### ###


warnings.filterwarnings(
    "ignore", message=".*LoginButton created outside of a Blocks context.*"
)

def greet(name, intensity):
    return "Hello, " + name + "!" * int(intensity)

def run_demo_server(hf_writer=None):
    process_pipe_image = process_image
    gradio_theme = gr.themes.Default()

    with gr.Blocks(
        theme=gradio_theme,
        title="SharpDepth Demo",
        css="""
            #download {
                height: 118px;
            }
            .slider .inner {
                width: 5px;
                background: #FFF;
            }
            .viewport {
                aspect-ratio: 4/3;
            }
            .tabs button.selected {
                font-size: 20px !important;
                color: crimson !important;
            }
            h1 {
                text-align: center;
                display: block;
            }
            h2 {
                text-align: center;
                display: block;
            }
            h3 {
                text-align: center;
                display: block;
            }
            .md_feedback li {
                margin-bottom: 0px !important;
            }
        """,
        head="""
            <script async src="https://www.googletagmanager.com/gtag/js?id=G-1FWSVCGZTG"></script>
            <script>
                window.dataLayer = window.dataLayer || [];
                function gtag() {dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', 'G-1FWSVCGZTG');
            </script>
        """,
    ) as demo:
        if hf_writer is not None:
            print("Creating login button")
            share_login_btn = gr.LoginButton(size="sm", scale=1, render=False)
            print("Created login button")
            share_login_btn.activate()
            print("Activated login button")

        gr.Markdown(
            """
            # SharpDepth Depth Estimation
            <p align="center">
            <a title="Website" href="https://haiphamcse.github.io/sharpdepth/" target="_blank" rel="noopener noreferrer" 
                    style="display: inline-block;">
                <img src="https://www.obukhov.ai/img/badges/badge-website.svg">
            </a>
            <a title="arXiv" href="https://arxiv.org/abs/2411.18229" target="_blank" rel="noopener noreferrer" 
                    style="display: inline-block;">
                <img src="https://www.obukhov.ai/img/badges/badge-pdf.svg">
            </a>
            </p>
            <p align="justify">
                SharpDepth bridges metric accuracy with detailed boundary preservation, resulting in depth predictions that are both metrically precise and visually sharp. Upload your image into the first pane, or click any of the examples below. The result will be computed and appear in the second pane.

            </p>
        """
        )

        def get_share_instructions(is_full):
            out = (
                "### Help us improve Marigold! If the output is not what you expected, "
                "you can help us by sharing it with us privately.\n"
            )
            if is_full:
                out += (
                    "1. Sign into your Hugging Face account using the button below.\n"
                    "1. Signing in may reset the demo and results; in that case, process the image again.\n"
                )
            out += "1. Review and agree to the terms of usage and enter an optional message to us.\n"
            out += "1. Click the 'Share' button to submit the image to us privately.\n"
            return out

        def get_share_conditioned_on_login(profile: gr.OAuthProfile | None):
            state_logged_out = profile is None
            return get_share_instructions(is_full=state_logged_out), gr.Button(
                visible=(state_logged_out or default_share_always_show_hf_logout_btn)
            )

        with gr.Tabs(elem_classes=["tabs"]):
            with gr.Tab("Image"):
                with gr.Row():
                    with gr.Column():
                        image_input = gr.Image(
                            label="Input Image",
                            type="filepath",
                        )
                        with gr.Row():
                            image_submit_btn = gr.Button(
                                value="Compute Depth", variant="primary"
                            )
                            image_reset_btn = gr.Button(value="Reset")
                    with gr.Column():
                        image_output_slider = ImageSlider(
                            label="Predicted depth (DepthPro, Ours)",
                            type="filepath",
                            show_download_button=True,
                            show_share_button=True,
                            interactive=False,
                            elem_classes="slider",
                            position=0.25,
                        )
                        image_output_files = gr.Files(
                            label="Output Files",
                            elem_id="download",
                            interactive=False,
                        )

                        if hf_writer is not None:
                            with gr.Accordion(
                                "Feedback",
                                open=False,
                                visible=default_share_always_show_accordion,
                            ) as share_box:
                                share_instructions = gr.Markdown(
                                    get_share_instructions(is_full=True),
                                    elem_classes="md_feedback",
                                )
                                share_transfer_of_rights = gr.Checkbox(
                                    label="(Optional) I own or hold necessary rights to the submitted image. By "
                                    "checking this box, I grant an irrevocable, non-exclusive, transferable, "
                                    "royalty-free, worldwide license to use the uploaded image, including for "
                                    "publishing, reproducing, and model training. [transfer_of_rights]",
                                    scale=1,
                                )
                                share_content_is_legal = gr.Checkbox(
                                    label="By checking this box, I acknowledge that my uploaded content is legal and "
                                    "safe, and that I am solely responsible for ensuring it complies with all "
                                    "applicable laws and regulations. Additionally, I am aware that my Hugging Face "
                                    "username is collected. [content_is_legal]",
                                    scale=1,
                                )
                                share_reason = gr.Textbox(
                                    label="(Optional) Reason for feedback",
                                    max_lines=1,
                                    interactive=True,
                                )
                                with gr.Row():
                                    share_login_btn.render()
                                    share_share_btn = gr.Button(
                                        "Share", variant="stop", scale=1
                                    )
                # with gr.Row():
                #     with gr.Column():
                #         image_3d_unidepth = gr.Model3D(label="3d mesh reconstruction (unidepth)", display_mode='point_cloud', clear_color=[1.0, 1.0, 1.0, 1.0])
                #     with gr.Column():
                #         image_3d = gr.Model3D(label="3d mesh reconstruction (ours)", display_mode='point_cloud', clear_color=[1.0, 1.0, 1.0, 1.0])

                # Examples(
                #     fn=process_pipe_image,
                #     examples=[
                #         os.path.join("files", "image", name)
                #         for name in [
                #             "arc.jpeg",
                #         ]
                #     ],
                #     inputs=[image_input],
                #     outputs=[image_output_slider, image_output_files],
                #     cache_examples=True,
                #     directory_name="examples_image",
                # )


        ### Image tab

        if hf_writer is not None:
            image_submit_btn.click(
                fn=process_image_check,
                inputs=image_input,
                outputs=None,
                preprocess=False,
                queue=False,
            ).success(
                get_share_conditioned_on_login,
                None,
                [share_instructions, share_login_btn],
                queue=False,
            ).then(
                lambda: (
                    gr.Button(value="Share", interactive=True),
                    gr.Accordion(visible=True),
                    False,
                    False,
                    "",
                ),
                None,
                [
                    share_share_btn,
                    share_box,
                    share_transfer_of_rights,
                    share_content_is_legal,
                    share_reason,
                ],
                queue=False,
            ).then(
                fn=process_pipe_image,
                inputs=[
                    image_input,
                ],
                outputs=[image_output_slider, image_output_files],
                concurrency_limit=1,
            )
        else:
            image_submit_btn.click(
                fn=process_image_check,
                inputs=image_input,
                outputs=None,
                preprocess=False,
                queue=False,
            ).success(
                fn=process_pipe_image,
                inputs=[
                    image_input,
                ],
                outputs=[image_output_slider, 
                image_output_files],
                concurrency_limit=1,
            )

        image_reset_btn.click(
            fn=lambda: (
                None,
                None,
                None,
            ),
            inputs=[],
            outputs=[
                image_input,
                image_output_slider,
                image_output_files,
            ],
            queue=False,
        )

        if hf_writer is not None:
            image_reset_btn.click(
                fn=lambda: (
                    gr.Button(value="Share", interactive=True),
                    gr.Accordion(visible=default_share_always_show_accordion),
                ),
                inputs=[],
                outputs=[
                    share_share_btn,
                    share_box,
                ],
                queue=False,
            )

        ### Share functionality

        demo.queue(
            api_open=False,
        ).launch(
            server_name="0.0.0.0",
            server_port=7860,
        )


# export no_proxy="localhost, 127.0.0.1"
if __name__ == "__main__":

    # -------------------- Arguments --------------------
    parser = argparse.ArgumentParser(description="Run single-image depth estimation using Marigold")
    
    parser.add_argument(
        "--checkpoint",
        type=str,
        default="prs-eth/marigold-v1-0",
        help="Checkpoint path or hub name.",
    )

    parser.add_argument(
        "--config",
        type=str,
        default="prs-eth/marigold-v1-0",
        help="sth.",
    )
    parser.add_argument(
        "--base_ckpt_dir",
        type=str,
        default=None,
        help="directory of pretrained checkpoint",
    )

    parser.add_argument("--use_ema", action="store_true", help="Whether to use EMA model.")
    parser.add_argument("--n_iter", type=int, default=1, help="Random seed.")
    parser.add_argument("--seed", type=int, default=None, help="Random seed.")
    args = parser.parse_args()
    checkpoint_path = args.checkpoint
    base_ckpt_dir = (
        args.base_ckpt_dir
        if args.base_ckpt_dir is not None
        else os.environ["BASE_CKPT_DIR"]
    )


    # -------------------- Initialization --------------------
    cfg = recursive_load_config(args.config)


    # -------------------- set seed --------------------
    if args.seed is not None:
        set_seed(args.seed)
    # ---------------------------------------------------------------------

    # -------------------- Device --------------------
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
        logging.warning("CUDA is not available. Running on CPU will be slow.")
    logging.info(f"device = {device}")


    # -------------------- Model --------------------
    tokenizer = AutoTokenizer.from_pretrained(base_ckpt_dir, subfolder="tokenizer")
    text_encoder_cls = import_model_class_from_model_name_or_path(base_ckpt_dir, revision=None)
    text_encoder = text_encoder_cls.from_pretrained(base_ckpt_dir, subfolder="text_encoder", revision=None)
    vae = AutoencoderKL.from_pretrained(base_ckpt_dir, subfolder="vae", revision=None)
    unidepth_transform = get_depth_normalizer(cfg_normalizer=cfg.unidepth_normalization)
    student_unet = UNet2DConditionModel.from_pretrained(os.path.join(checkpoint_path, "unet"), revision=None)
    noise_scheduler = DDPMScheduler.from_pretrained(base_ckpt_dir, subfolder="scheduler")

    unidepth_model = UniDepthV1.from_pretrained("lpiccinelli/unidepth-v1-vitl14")
    depthpro_model, transform = depth_pro.create_model_and_transforms()
    depthpro_model.eval().to(device)

    # Load checkpoint
    if args.use_ema:
        # ema_unet = EMAModel.from_pretrained(os.path.join(checkpoint_path, "unet_ema"), UNet2DConditionModel)
        # ema_unet.copy_to(student_unet.parameters())
        # del ema_unet
        ema_model = EMA(
                            student_unet,
                            beta = 0.9999,              # exponential moving average factor
                            update_after_step = 100,    # only after this number of .update() calls will it start updating
                            update_every = 10,          # how often to actually update, to save on compute (updates every 10th .update() call)
                        )
        data = torch.load(os.path.join(checkpoint_path, "unet_ema.pt"))
        ema_model.load_state_dict(data["ema"], strict=False)
        del data

        ema_model.to(device)

    student_unet.to(device)
    vae.to(device)
    text_encoder.to(device)
    unidepth_model = unidepth_model.to(device)
    weight_dtype = torch.float32

    # -------------------- Precompute null & task embedding --------------------
    empty_text_emb = encode_empty_text(tokenizer, text_encoder).to(device, dtype=weight_dtype)
    del tokenizer
    del text_encoder
    task_emb = torch.tensor([1, 0]).float().unsqueeze(0).repeat(1, 1)
    task_emb = torch.cat([torch.sin(task_emb), torch.cos(task_emb)], dim=-1)

    ## Sky Segmenter ##
    config_file = '../mmsegmentation/configs/segformer/segformer_mit-b4_8xb1-160k_cityscapes-1024x1024.py'
    checkpoint_file = '../data/segformer_mit-b4_8x1_1024x1024_160k_cityscapes_20211207_080709-07f6c333.pth'
    # build the model from a config file and a checkpoint file
    sky_model = init_model(config_file, checkpoint_file, device='cuda')

    run_demo_server()
    # demo = gr.Interface(
    #     fn=greet,
    #     inputs=["text", "slider"],
    #     outputs=["text"],
    # )

    # demo.launch(server_name="0.0.0.0", server_port=7860)
