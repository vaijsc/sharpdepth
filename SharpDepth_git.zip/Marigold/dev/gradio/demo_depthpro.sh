export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 
export CHECKPOINT_PATH=../marigold_exp/training/refiner/main_tung_05_disp_200k_data/checkpoint-24000
# export GRADIO_TEMP_DIR="home/ubuntu/Working/haipd13/diffusion/Marigold/dev/gradio/"
export no_proxy="localhost, 127.0.0.1"


python dev/gradio/demo_depthpro.py \
    --config dev/refine_plus/main_tung/configs/main.yaml \
    --base_ckpt_dir jingheya/lotus-depth-g-v2-0-disparity \
    --checkpoint $CHECKPOINT_PATH \
