import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from marigold import MarigoldPipeline
from src.util.seeding import seed_all
from src.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)
from torch.utils.data import ConcatDataset, DataLoader
from src.dataset.mixed_sampler import MixedBatchSampler
from src.util.depth_transform import *
from src.util.config_util import (
    find_value_in_omegaconf,
    recursive_load_config,
)
from typing import List

if "__main__" == __name__:
    logging.basicConfig(level=logging.INFO)

    # -------------------- Arguments --------------------
    parser = argparse.ArgumentParser(
        description="Run single-image depth estimation using Marigold."
    )

    parser.add_argument(
        "--config",
        type=str,
        default="config/train_marigold.yaml",
        help="Path to config file.",
    )
    # dataset setting
    parser.add_argument(
        "--base_data_dir",
        type=str,
        required=True,
        help="Path to base data directory.",
    )


    args = parser.parse_args()
    base_data_dir = args.base_data_dir

    print(f"arguments: {args}")

    # -------------------- Device --------------------
    if torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
        logging.warning("CUDA is not available. Running on CPU will be slow.")
    logging.info(f"device = {device}")


    cfg = recursive_load_config(args.config)
    cfg_data = cfg.dataset

    # -------------------- Data --------------------
    loader_seed = cfg.dataloader.seed
    if loader_seed is None:
        loader_generator = None
    else:
        loader_generator = torch.Generator().manual_seed(loader_seed)

    # Training dataset
    depth_transform: DepthNormalizerBase = get_depth_normalizer(
        cfg_normalizer=cfg.depth_normalization
    )

    train_dataset: BaseDepthDataset = get_dataset(
        cfg_data.train,
        base_data_dir=base_data_dir,
        mode=DatasetMode.TRAIN,
        augmentation_args=cfg.augmentation,
        depth_transform=depth_transform,
    )

    logging.debug("Augmentation: ", cfg.augmentation)
    if "mixed" == cfg_data.train.name:
        dataset_ls = train_dataset
        assert len(cfg_data.train.prob_ls) == len(
            dataset_ls
        ), "Lengths don't match: `prob_ls` and `dataset_list`"
        concat_dataset = ConcatDataset(dataset_ls)
        mixed_sampler = MixedBatchSampler(
            src_dataset_ls=dataset_ls,
            batch_size=cfg.dataloader.max_train_batch_size,
            drop_last=True,
            prob=cfg_data.train.prob_ls,
            shuffle=True,
            generator=loader_generator,
        )
        train_loader = DataLoader(
            concat_dataset,
            batch_sampler=mixed_sampler,
            num_workers=cfg.dataloader.num_workers,
        )

    # Validation dataset
    val_loaders: List[DataLoader] = []
    for _val_dic in cfg_data.val:
        _val_dataset = get_dataset(
            _val_dic,
            base_data_dir=base_data_dir,
            mode=DatasetMode.EVAL,
        )
        _val_loader = DataLoader(
            dataset=_val_dataset,
            batch_size=1,
            shuffle=False,
            num_workers=cfg.dataloader.num_workers,
        )
        val_loaders.append(_val_loader)

    # Visualization dataset
    vis_loaders: List[DataLoader] = []
    for _vis_dic in cfg_data.vis:
        _vis_dataset = get_dataset(
            _vis_dic,
            base_data_dir=base_data_dir,
            mode=DatasetMode.EVAL,
        )
        _vis_loader = DataLoader(
            dataset=_vis_dataset,
            batch_size=1,
            shuffle=False,
            num_workers=cfg.dataloader.num_workers,
        )
        vis_loaders.append(_vis_loader)

    for i, val_loader in enumerate(val_loaders):
        for j, batch in enumerate(
            tqdm(val_loader, desc=f"evaluating on {val_loader.dataset.disp_name}"),
            start=1,
        ):
            rgb_int = batch["rgb_int"].squeeze().numpy().astype(np.uint8)  # [

    for i, vis_loader in enumerate(vis_loaders):
        for j, batch in enumerate(
            tqdm(vis_loader, desc=f"visualizing on {vis_loader.dataset.disp_name}"),
            start=1,
        ):
            rgb_int = batch["rgb_int"].squeeze().numpy().astype(np.uint8)  # [

    # with torch.no_grad():
    #     for batch in tqdm(
    #         train_loader, desc=f"Inferencing on", leave=True
    #     ):
    #         # Read input image
    #         rgb_int = batch["rgb_int"].squeeze().numpy().astype(np.uint8)  # [3, H, W]
    #         # Read GT (Meters and Normalized)
    #         depth_gt = batch['depth_raw_linear']
    #         depth_gt = batch['depth_raw_norm']
    #         # Read UniDepth
    #         depth_unidepth = batch['depth_filled_linear']
    #         sky_mask = batch['valid_mask_filled'] #ones = good, zeros = bad

    #         # print(batch['disp_name'])
    #         if 'kitti' in batch['disp_name'][0]:
    #             print(torch.unique(sky_mask, return_counts=True))
