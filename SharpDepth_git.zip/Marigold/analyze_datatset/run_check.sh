#!/usr/bin/env bash
set -e
set -x

# Use specified checkpoint path, otherwise, default value
ckpt=${1:-"stabilityai/stable-diffusion-2-1-base"}
subfolder=${2:-"eval"}

export BASE_DATA_DIR=/lustre/scratch/client/scratch/research/group/khoigroup/haipd13/diffusion/data
export HF_HOME=/lustre/scratch/client/vinai/users/tungdt33/depth_estimation/ckpt

PYTHONPATH="$(dirname $0)/..":$PYTHONPATH python analyze_datatset/dataset_with_sky_test.py  \
    --base_data_dir $BASE_DATA_DIR \
    --config analyze_datatset/train_marigold.yaml \
