export BASE_DATA_DIR=/home/ubuntu/Working/haipd13/diffusion/data
export HF_HOME=/home/ubuntu/Working/haipd13/diffusion/
export BASE_CKPT_DIR=/home/ubuntu/Working/haipd13/diffusion/ckpt
source activate mvsplat
pip install -U timm
export TORCH_HOME=/home/ubuntu/Working/haipd13/diffusion/

export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH
python scripts/demo_pandaset_depthpro.py
python scripts/demo_scannet_depthpro.py
