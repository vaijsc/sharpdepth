export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH
export TORCH_HOME=/home/ubuntu/Working/diffusion/
export TORCH_HUB=/home/ubuntu/Working/diffusion

python scripts/demo_nyuv2_metric3d_large.py
python scripts/demo_kitti_metric3d_large.py

