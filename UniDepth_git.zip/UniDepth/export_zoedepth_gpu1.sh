export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH
export TORCH_HOME=/root/data_hai/diffusion/
export TORCH_HUB=/root/data_hai/diffusion


# python scripts/demo_waymo_zoedepth.py
# python scripts/demo_pandaset_zoedepth.py
python scripts/demo_argoverse2_zoedepth.py