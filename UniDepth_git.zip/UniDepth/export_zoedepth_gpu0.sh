export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH
export TORCH_HOME=/root/data_hai/diffusion/
export TORCH_HUB=/root/data_hai/diffusion


python scripts/demo_taskonomy_zoedepth.py
python scripts/demo_arkit_zoedepth.py
python scripts/demo_scannet_zoedepth.py