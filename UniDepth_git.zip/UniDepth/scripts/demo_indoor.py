"""Fuse 1000 RGB-D images from the 7-scenes dataset into a TSDF voxel volume with 2cm resolution.
"""

import time

import cv2
import numpy as np

from numpy.linalg import inv
import os
from tqdm.contrib.concurrent import process_map
import torch
import numpy as np
from PIL import Image

from unidepth.utils import colorize, image_grid
from unidepth.models import UniDepthV1
from tqdm import tqdm

def parse_calibration(filename):
  """ read calibration file with given filename

      Returns
      -------
      dict
          Calibration matrices as 4x4 numpy arrays.
  """
  calib = {}

  calib_file = open(filename)
  for line in calib_file:
    key, content = line.strip().split(":")
    values = [float(v) for v in content.strip().split()]

    pose = np.zeros((4, 4))
    pose[0, 0:4] = values[0:4]
    pose[1, 0:4] = values[4:8]
    pose[2, 0:4] = values[8:12]
    pose[3, 3] = 1.0

    calib[key] = pose

  calib_file.close()

  return calib

def parse_poses(filename, calibration):
  """ read poses file with per-scan poses from given filename

      Returns
      -------
      list
          list of poses as 4x4 numpy arrays.
  """
  file = open(filename)

  poses = []

  Tr = calibration["Tr"]
  Tr_inv = inv(Tr)

  for line in file:
    values = [float(v) for v in line.strip().split()]

    pose = np.zeros((4, 4))
    pose[0, 0:4] = values[0:4]
    pose[1, 0:4] = values[4:8]
    pose[2, 0:4] = values[8:12]
    pose[3, 3] = 1.0

    # poses.append(np.matmul(Tr_inv, np.matmul(pose, Tr)))
    poses.append(pose)
    
  return poses

if __name__ == "__main__":
    model = UniDepthV1.from_pretrained("lpiccinelli/unidepth-v1-vitl14")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    val_img_dir = os.listdir(f"../tsdf-fusion-python/data/")
    val_img_dir = sorted([file for file in val_img_dir if ('color' in file)])
    os.makedirs(f'../unidepth_exp/eval/unidepthv1_with_intrinsics/indoor/', exist_ok=True)
    for i in tqdm(val_img_dir):
        img_p = os.path.join(f"../tsdf-fusion-python/data/", i)
        rgb = np.array(Image.open(img_p))
        rgb_torch = torch.from_numpy(rgb).permute(2, 0, 1).to(device)
        predictions = model.infer(rgb_torch[:3, :, :])
        # get GT and pred
        depth_pred = predictions["depth"].squeeze().cpu().numpy()
        np.save(os.path.join(f'../unidepth_exp/eval/unidepthv1_with_intrinsics/indoor/', i[:-4]+'.npy'), depth_pred)
    
    # ids = ["08"]
    # for scene_id in ids:
    #     # print(f"Current Split: {scene_id}")
    #     calibration = parse_calibration(f"../data/SemanticKITTI/dataset/sequences/{scene_id}/calib.txt")
    #     poses = parse_poses(f"../data/SemanticKITTI/dataset/sequences/{scene_id}/poses.txt", calibration)
    #     # print(len(poses))/home/haipd13/khoigroup/haipd13/diffusion/
    #     val_img_dir = os.listdir(f"../data/SemanticKITTI/dataset/sequences/{scene_id}/image_2")
    #     # val_img_dir = sorted([file for file in val_img_dir if ((len(file) == 10) and ('png' in file))])
    #     val_img_dir = sorted([file for file in val_img_dir if ('png' in file)])
    #     print(len(val_img_dir))
    #     # /home/haipd13/khoigroup/haipd13/diffusion/
    #     os.makedirs(f'../unidepth_exp/eval/unidepthv1_with_intrinsics/{scene_id}/depth', exist_ok=True)
    #     tar_img_dir = val_img_dir[800:1000]
    #     for i in tqdm(tar_img_dir):
    #         img_p = os.path.join(f"../data/SemanticKITTI/dataset/sequences/{scene_id}/image_2", i)
    #         rgb = np.array(Image.open(img_p))
    #         rgb_torch = torch.from_numpy(rgb).permute(2, 0, 1).to(device)
    #         intrinsic = torch.from_numpy(calibration['P2'][:3, :3]).to(device).float()
    #         # data = {"image": rgb, "K": calibration['P2'][:3, :3]}
    #         # predictions = model(data, {})

    #         predictions = model.infer(rgb_torch[:3, :, :], intrinsic)

    #         # get GT and pred
    #         depth_pred = predictions["depth"].squeeze().cpu().numpy()


    #         np.save(os.path.join(f'../unidepth_exp/eval/unidepthv1_with_intrinsics/{scene_id}/depth', i[:-4]+'.npy'), depth_pred)
            
    #         # depth_gt = np.load(os.path.join("../tsdf-fusion-python/raw_depth/unidepth/sequences", scene_id, "depth", i[:-4]+'.npy'))
    #         # compute error, you have zero divison where depth_gt == 0.0
    #         # depth_arel = np.abs(depth_gt - depth_pred) / depth_gt
    #         # depth_arel[depth_gt == 0.0] = 0.0
    #         # print(f"ARel: {depth_arel[depth_gt > 0].mean() * 100:.2f}%")
