# Last modified: 2024-02-08
#
# Copyright 2023 Bingxin Ke, ETH Zurich. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# --------------------------------------------------------------------------
# If you find this code useful, we kindly ask you to cite our paper in your work.
# Please find bibtex at: https://github.com/prs-eth/Marigold#-citation
# If you use or adapt this code, please attribute to https://github.com/prs-eth/marigold.
# More information about the method can be found at https://marigoldmonodepth.github.io
# --------------------------------------------------------------------------

import torch

from scripts.dataset.base_depth_dataset import BaseDepthDataset, DepthFileNameMode, get_pred_name
from scripts.dataset import (
        DatasetMode,
    )
import numpy as np 
import os
from PIL import Image

class nuScenesDataset(BaseDepthDataset):
    def __init__(
        self,
        **kwargs,
    ) -> None:
        super().__init__(
            # KITTI data parameter
            min_depth=1e-5,
            max_depth=100,
            has_filled_depth=False,
            name_mode=DepthFileNameMode.id,
            **kwargs,
        )

        # Filter out empty depth
        self.filenames = [f for f in self.filenames if "None" != f[1]]
        self.dataset_dir_depth = "../unidepth_exp/eval/unidepthv1_with_intrinsics/waymo/prediction"
    
    def _get_data_path(self, index):
        filename_line = self.filenames[index]

        # Get data path
        rgb_rel_path = filename_line[0]

        # breakpoint()
        depth_rel_path, filled_rel_path = None, None
        if DatasetMode.RGB_ONLY != self.mode:
            depth_rel_path = filename_line[1]
            # if self.has_filled_depth:
            try:
                filled_rel_path = filename_line[2]
            except:
                filled_rel_path = None

        return rgb_rel_path, depth_rel_path, float(filename_line[2]), float(filename_line[3]), float(filename_line[4]), float(filename_line[5])

    def _load_rgb_data(self, rgb_rel_path):
        # Read RGB data
        rgb = self._read_rgb_file(rgb_rel_path)
        rgb_norm = rgb / 255.0 * 2.0 - 1.0  #  [0, 255] -> [-1, 1]

        outputs = {
            "rgb_int": torch.from_numpy(rgb).int(),
            "rgb_norm": torch.from_numpy(rgb_norm).float(),
        }
        return outputs

    def _read_depth_file(self, rel_path):
        depth_in = np.load(os.path.join(self.dataset_dir, rel_path))
        return depth_in

    def _get_data_item(self, index):
        filled_rel_path = None
        rgb_rel_path, depth_rel_path, fx, fy, cx, cy = self._get_data_path(index=index)

        rasters = {}
        # RGB data
        rasters.update(self._load_rgb_data(rgb_rel_path=rgb_rel_path))

        # Depth data
        if DatasetMode.RGB_ONLY != self.mode:
            # load data
            depth_data = self._load_depth_data(
                depth_rel_path=depth_rel_path, filled_rel_path=filled_rel_path
            )
            rasters.update(depth_data)

            # valid mask
            rasters["valid_mask_raw"] = self._get_valid_mask(
                rasters["depth_raw_linear"]
            ).clone()
            rasters["valid_mask_filled"] = self._get_valid_mask(
                rasters["depth_filled_linear"]
            ).clone()

        intrinsics = torch.tensor([[fx, 0, cx],
                                    [0, fy, cy],
                                    [0, 0, 1]]).float()

        other = {"index": index, "rgb_relative_path": rgb_rel_path, 'disp_name': self.disp_name, 'intrinsics': intrinsics}

        return rasters, other



if __name__ == "__main__":
    from omegaconf import OmegaConf
    from src.dataset import (
        BaseDepthDataset,
        DatasetMode,
        get_dataset,
        get_pred_name,
    )
    from torch.utils.data import DataLoader
    from src.util.depth_transform import (
        DepthNormalizerBase,
        get_depth_normalizer,
    )
    from src.util.config_util import (
        find_value_in_omegaconf,
        recursive_load_config,
    )
    from tqdm import tqdm
    import numpy as np
    
    dataset_config = "config/dataset/data_nuscenes_val.yaml"
    base_data_dir = "/home/ubuntu/Working/haipd13/diffusion/data"
    config = "/home/ubuntu/Working/haipd13/diffusion/Marigold/dev/real_data/configs/train_marigold.yaml"
    
    cfg_data = OmegaConf.load(dataset_config)
    cfg = recursive_load_config(config)
    # depth_normalization:
    # type: scale_shift_depth
    # clip: true
    # norm_min: -1.0
    # norm_max: 1.0
    # min_max_quantile: 0.02

    depth_transform: DepthNormalizerBase = get_depth_normalizer(
        cfg_normalizer=cfg.depth_normalization
    )

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.TRAIN,
        depth_transform=depth_transform
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=2)
    for batch in tqdm(
        dataloader, desc=f"Inferencing on", leave=True
    ):
        # Read input image
        rgb_int = batch["rgb_int"].squeeze().numpy().astype(np.uint8)  # [3, H, W]

    out = dataset.__getitem__(9)
    breakpoint()