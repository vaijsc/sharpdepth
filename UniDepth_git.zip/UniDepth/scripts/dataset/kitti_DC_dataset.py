# Last modified: 2024-02-08
#
# Copyright 2023 Bingxin Ke, ETH Zurich. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# --------------------------------------------------------------------------
# If you find this code useful, we kindly ask you to cite our paper in your work.
# Please find bibtex at: https://github.com/prs-eth/Marigold#-citation
# If you use or adapt this code, please attribute to https://github.com/prs-eth/marigold.
# More information about the method can be found at https://marigoldmonodepth.github.io
# --------------------------------------------------------------------------

import torch

from scripts.dataset.base_depth_dataset import BaseDepthDataset, DepthFileNameMode
import numpy as np
from scipy.interpolate import griddata
import cv2
from enum import Enum

class DatasetMode(Enum):
    RGB_ONLY = "rgb_only"
    EVAL = "evaluate"
    TRAIN = "train"


def infilling(depth):
    h, w = depth.shape
    row, col = np.meshgrid(np.linspace(0, w-1, num=w), np.linspace(0, h-1, num=h))  
    vv = np.stack([row,col,depth], axis=-1)
    mask = vv[..., 2] > 0
    dmd = griddata(vv[mask][..., :2].reshape(-1,2), vv[mask][..., 2].reshape(-1), (row, col), method='nearest')    #try 'nearest','linear'

    dmd = np.where(dmd < 0, 0, dmd)

    # mask the result to the ROI
    mask = np.zeros((h, w))                                # initialize mask 
    ind = (depth != 0).argmax(axis=0)
    for i in range(w):
        mask[ind[i]:, i] = 1

    kernel = np.ones((2, 10), np.uint8)
    mask   = cv2.dilate(mask,kernel,iterations = 1)                         # by Dilation

    # ## mask the depth map
    # dm  = dmd
    bool_mask = mask == 1
    # dm[bool_mask] = 100

    return dmd, bool_mask

    
class KITTIDCDataset(BaseDepthDataset):
    def __init__(
        self,
        kitti_bm_crop,  # Crop to KITTI benchmark size
        valid_mask_crop,  # Evaluation mask. [None, garg or eigen]
        **kwargs,
    ) -> None:
        super().__init__(
            # KITTI data parameter
            min_depth=1e-5,
            max_depth=80,
            has_filled_depth=True,
            name_mode=DepthFileNameMode.id,
            **kwargs,
        )
        self.kitti_bm_crop = kitti_bm_crop
        self.valid_mask_crop = valid_mask_crop
        assert self.valid_mask_crop in [
            None,
            "garg",  # set evaluation mask according to Garg  ECCV16
            "eigen",  # set evaluation mask according to Eigen NIPS14
        ], f"Unknown crop type: {self.valid_mask_crop}"

        # Filter out empty depth
        self.filenames = [f for f in self.filenames if "None" != f[1]]

    def _read_depth_file(self, rel_path):
        depth_in = self._read_image(rel_path)
        # Decode KITTI depth
        depth_decoded = depth_in / 256.0
        return depth_decoded

    def _load_rgb_data(self, rgb_rel_path):
        rgb_data = super()._load_rgb_data(rgb_rel_path)
        if self.kitti_bm_crop:
            rgb_data = {k: self.kitti_benchmark_crop(v) for k, v in rgb_data.items()}
        return rgb_data

    def _load_depth_data(self, depth_rel_path, filled_rel_path):
        # depth_data = super()._load_depth_data(depth_rel_path, filled_rel_path)
        depth_data = {}
        depth_raw = self._read_depth_file(depth_rel_path).squeeze()
        depth_raw_linear = torch.from_numpy(depth_raw).float().unsqueeze(0)  # [1, H, W]
        depth_data["depth_raw_linear"] = depth_raw_linear.clone()
        # print(depth_rel_path, filled_rel_path)
        
        if self.has_filled_depth:
            depth_filled = self._read_depth_file(filled_rel_path).squeeze()
            depth_filled_linear = torch.from_numpy(depth_filled).float().unsqueeze(0)
            depth_data["depth_filled_linear"] = depth_filled_linear
        else:
            depth_data["depth_filled_linear"] = depth_raw_linear.clone()


        if self.kitti_bm_crop:
            depth_data = {
                k: self.kitti_benchmark_crop(v) for k, v in depth_data.items()
            }
        

        return depth_data

    @staticmethod
    def kitti_benchmark_crop(input_img):
        """
        Crop images to KITTI benchmark size
        Args:
            `input_img` (torch.Tensor): Input image to be cropped.

        Returns:
            torch.Tensor:Cropped image.
        """
        KB_CROP_HEIGHT = 352
        KB_CROP_WIDTH = 1216

        height, width = input_img.shape[-2:]
        top_margin = int(height - KB_CROP_HEIGHT)
        left_margin = int((width - KB_CROP_WIDTH) / 2)
        if 2 == len(input_img.shape):
            out = input_img[
                top_margin : top_margin + KB_CROP_HEIGHT,
                left_margin : left_margin + KB_CROP_WIDTH,
            ]
        elif 3 == len(input_img.shape):
            out = input_img[
                :,
                top_margin : top_margin + KB_CROP_HEIGHT,
                left_margin : left_margin + KB_CROP_WIDTH,
            ]
        return out

    def _get_valid_mask(self, depth: torch.Tensor):
        # reference: https://github.com/cleinc/bts/blob/master/pytorch/bts_eval.py
        # valid_mask = super()._get_valid_mask(depth)  # [1, H, W]

        valid_mask = torch.logical_and((depth > self.min_depth), (depth < self.max_depth)).bool()

        if self.valid_mask_crop is not None:
            eval_mask = torch.zeros_like(valid_mask.squeeze()).bool()
            gt_height, gt_width = eval_mask.shape

            if "garg" == self.valid_mask_crop:
                eval_mask[
                    int(0.40810811 * gt_height) : int(0.99189189 * gt_height),
                    int(0.03594771 * gt_width) : int(0.96405229 * gt_width),
                ] = 1
            elif "eigen" == self.valid_mask_crop:
                eval_mask[
                    int(0.3324324 * gt_height) : int(0.91351351 * gt_height),
                    int(0.0359477 * gt_width) : int(0.96405229 * gt_width),
                ] = 1

            eval_mask.reshape(valid_mask.shape)
            valid_mask = torch.logical_and(valid_mask, eval_mask)
        return valid_mask


    def _get_data_item(self, index):
        rgb_rel_path, depth_rel_path, filled_rel_path = self._get_data_path(index=index)

        rasters = {}
        # print(rgb_rel_path)
        # RGB data
        rasters.update(self._load_rgb_data(rgb_rel_path=rgb_rel_path))

        # Depth data
        if DatasetMode.RGB_ONLY != self.mode:
            # load data
            depth_data = self._load_depth_data(
                depth_rel_path=depth_rel_path, filled_rel_path=filled_rel_path
            )
            rasters.update(depth_data)
            # valid mask
            rasters["valid_mask_raw"] = self._get_valid_mask(
                rasters["depth_raw_linear"]
            ).clone()
            rasters["valid_mask_filled"] = self._get_valid_mask(
                rasters["depth_filled_linear"]
            ).clone()

        other = {"index": index, "rgb_relative_path": rgb_rel_path}

        return rasters, other



if __name__ == "__main__":
    from omegaconf import OmegaConf
    from src.dataset import (
        BaseDepthDataset,
        DatasetMode,
        get_dataset,
        get_pred_name,
    )
    from torch.utils.data import DataLoader
    from src.util.depth_transform import (
        DepthNormalizerBase,
        get_depth_normalizer,
    )
    from src.util.config_util import (
        find_value_in_omegaconf,
        recursive_load_config,
    )
    import matplotlib
    import matplotlib.pyplot as plt
    from PIL import Image
    from tqdm import tqdm
    
    dataset_config = "config/dataset/data_kitti_eigen_test_dc.yaml"
    base_data_dir = "/home/ubuntu/Working/haipd13/diffusion/data"
    config = "/home/ubuntu/Working/haipd13/diffusion/Marigold/dev/real_data/configs/train_marigold.yaml"

    cfg_data = OmegaConf.load(dataset_config)
    cfg = recursive_load_config(config)
    # depth_normalization:
    # type: scale_shift_depth
    # clip: true
    # norm_min: -1.0
    # norm_max: 1.0
    # min_max_quantile: 0.02

    depth_transform: DepthNormalizerBase = get_depth_normalizer(
        cfg_normalizer=cfg.depth_normalization
    )

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.TRAIN,
        depth_transform=depth_transform
    )

    # dataloader = DataLoader(dataset, batch_size=1, num_workers=0)


    def colorize(
        value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "magma_r"
    ):
        # if already RGB, do nothing
        if value.ndim > 2:
            if value.shape[-1] > 1:
                return value
            value = value[..., 0]
        invalid_mask = value < 0.0001
        # normalize
        vmin = value.min() if vmin is None else vmin
        vmax = value.max() if vmax is None else vmax
        value = (value - vmin) / (vmax - vmin)  # vmin..vmax

        # set color
        cmapper = matplotlib.cm.get_cmap(cmap)
        value = cmapper(value, bytes=True)  # (nxmx4)
        value[invalid_mask] = 0
        img = value[..., :3]
        return img
    
    dataloader = DataLoader(dataset, batch_size=1, num_workers=4)
    for batch in tqdm(
        dataloader, desc=f"Inferencing on", leave=True
    ):
        # Read input image
        rgb_int = batch["rgb_int"].squeeze().permute(1,2,0).numpy().astype(np.uint8)  # [3, H, W]
        depth_complete = batch['depth_raw_linear'].squeeze().numpy()
        depth_sparse = batch['depth_filled_linear'].squeeze().numpy()
        color_complete = colorize(depth_complete)
        color_sparse = colorize(depth_sparse)
        Image.fromarray(color_complete).save('temp.jpg')
        Image.fromarray(color_sparse).save('temp_sparse.jpg')
        Image.fromarray(rgb_int).save('temp_col.jpg')
    # out = dataset.__getitem__(9)
    # depth_complete = out['depth_raw_linear']
    # depth_sparse = out['depth_filled_linear']
    # color_complete = colorize(depth_complete[0])
    # Image.fromarray(color_complete).save('temp.jpg')
    # color_sparse = colorize(depth_sparse[0])
    # Image.fromarray(color_sparse).save('temp_sparse.jpg')

    # breakpoint()

    