import os
from glob import glob
from typing import Callable, Optional

import cv2
import numpy as np
import pandas as pd
from torch.utils.data import Dataset
import torch


def expand_channel_dim(img):
    """
        expand image dimension to add a channel dimension
    """
    return np.expand_dims(img, 0)


def image_hwc_to_chw(img):
    """
        transpose the image from height, width, channel -> channel, height, width
        (pytorch format)
    """
    return img.transpose((2, 0, 1))


def image_chw_to_hwc(img):
    """
        revert image_hwc_to_chw function
    """
    return img.transpose((1, 2, 0))


def batch_to_cuda(batch):
    if torch.cuda.is_available():
        for k in batch:
            if k != 'identifier':
                batch[k] = batch[k].cuda(non_blocking=True)
    return batch


IDENTIFIER = 'identifier'
COLOR_IMG = 'color_img'
HIGH_RES_DEPTH_IMG = 'high_res_depth_img'
LOW_RES_DEPTH_IMG = 'low_res_depth_img'
PREDICTION_DEPTH_IMG = 'prediction_img'
VALID_MASK_IMG = 'valid_mask_img'


META_DATA_CSV_FILE = 'metadata.csv'
WIDE = 'wide'
LOW_RES = (192, 256)
HIGH_RES = (1440, 1920)
MILLIMETER_TO_METER = 1000


from scripts.util.depth_transform import DepthNormalizerBase
from scripts.dataset.base_depth_dataset import BaseDepthDataset, DepthFileNameMode

def st2_camera_intrinsics(filename):
    w, h, fx, fy, hw, hh = np.loadtxt(filename)
    return np.asarray([[fx, 0, hw], [0, fy, hh], [0, 0, 1]])


class ARKitScenesDataset(Dataset):
    """`ARKitScenes Dataset class.

    Args:
        root (string): Root directory of dataset where directory
            exists or will be saved to if download is set to True.
        transform (callable, optional): A function that takes in a sample (dict)
            and returns a transformed version.
        download (bool, optional): If true, downloads the dataset from the internet and
            puts on the root directory. If dataset is already downloaded, it is not
            downloaded again.
    """

    def __init__(
            self,
            mode,
            dataset_dir: str,
            disp_name,
            depth_transform=None,
            split: str = 'train',
            transform: Optional[Callable] = None,
            upsample_factor: Optional[int] = None,
            rgb_transform=lambda x: x / 255.0 * 2 - 1,  #  [0, 255] -> [-1, 1],
            **kwargs,
    ) -> None:

        super(ARKitScenesDataset, self).__init__()
        self.root = dataset_dir
        self.split = split
        self.transform = transform
        self.upsample_factor = upsample_factor
        self.disp_name = disp_name
        self.name_mode=DepthFileNameMode.id
        flag = 0
        if self.upsample_factor is not None and self.upsample_factor not in (2, 4, 8):
            raise ValueError(f'rgb_factor must to be one of (2,4,8) but got {self.upsample_factor}')
        if split == 'train':
            self.split_folder = 'Training'
        elif split == 'val':
            self.split_folder = 'Validation'
        elif split == 'train_20k':
            flag = 1
            split = 'train'
            self.split_folder = 'Training'
        else:
            raise Exception(f'split must to be one of (train, val), got ={split}')
        self.dataset_folder = os.path.join(self.root, self.split_folder)
        if self.upsample_factor is None:
            self.low_res = LOW_RES
            self.high_res = HIGH_RES
        else:
            if self.upsample_factor in (2, 4):
                self.low_res = LOW_RES
                self.high_res = [i * self.upsample_factor for i in LOW_RES]
            elif self.upsample_factor == 8:
                self.high_res = HIGH_RES
                self.low_res = [int(i / self.upsample_factor) for i in HIGH_RES]
            else:
                raise Exception(f'Can\'t load dataset with upsample_factor = {self.upsample_factor}')

        self.samples = []  # videos_id, sample_id, sky_direction
        if split == 'val':
            self.meta_data = pd.read_csv(os.path.join(os.path.dirname(self.dataset_folder), 'metadata.csv'))

        else:
            if flag == 1:
                # META_DATA_CSV_FILE = 'metadata_20k.csv'
                self.meta_data = pd.read_csv(os.path.join(os.path.dirname(self.dataset_folder), 'metadata_20k.csv'))

            else:
                self.meta_data = pd.read_csv(os.path.join(os.path.dirname(self.dataset_folder), META_DATA_CSV_FILE))
        self.meta_data = self.meta_data[self.meta_data['fold'] == self.split_folder]
        for video_id, sky_direction in zip(self.meta_data['video_id'], self.meta_data['sky_direction']):
            video_folder = os.path.join(self.dataset_folder, str(video_id))
            color_files = glob(os.path.join(video_folder, WIDE, '*.png'))
            self.samples.extend([[str(video_id), str(os.path.basename(file)), sky_direction]
                                 for file in color_files])

        # training arguments
        self.depth_transform: DepthNormalizerBase = depth_transform
        self.rgb_transform = rgb_transform

        if split == 'train':
            self.dataset_folder_depth = self.dataset_folder.replace("data/arkit/upsampling/Training", "unidepth_exp/eval/unidepthv1_with_intrinsics/arkit/train")
        else:
            self.dataset_folder_depth = self.dataset_folder.replace("data/arkit/upsampling/Validation", "unidepth_exp/eval/unidepthv1_with_intrinsics/arkit/val")


    @staticmethod
    def rotate_image(img, direction):
        if direction == 'Up':
            pass
        elif direction == 'Left':
            img = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
        elif direction == 'Right':
            img = cv2.rotate(img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        elif direction == 'Down':
            img = cv2.rotate(img, cv2.ROTATE_180)
        else:
            raise Exception(f'No such direction (={direction}) rotation')
        return img

    @staticmethod
    def load_image(path, shape, is_depth, sky_direction):
        img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img.shape[:2] != shape:
            img = cv2.resize(img, shape[::-1], interpolation=cv2.INTER_NEAREST if is_depth else cv2.INTER_LINEAR)
        img = ARKitScenesDataset.rotate_image(img, sky_direction)
        if is_depth:
            img = expand_channel_dim(np.asarray(img / MILLIMETER_TO_METER, np.float32))
        else:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = image_hwc_to_chw(np.asarray(img, np.float32))
        return img

    def __getitem__(self, index: int):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (identifier, color, highres_depth, lowres_depth).
        """
        video_id, sample_id, direction = self.samples[index]
        sample = dict()
        sample[IDENTIFIER] = str(sample_id)

        rgb_file = os.path.join(self.dataset_folder, video_id, WIDE, sample_id)
        depth_file = os.path.join(self.dataset_folder, video_id, 'highres_depth', sample_id)
        apple_depth_file = os.path.join(self.dataset_folder, video_id, 'lowres_depth', sample_id)
        intrinsic_file = os.path.join(self.dataset_folder, video_id, 'wide_intrinsics', sample_id.replace('png', 'pincam'))

        sample[COLOR_IMG] = self.load_image(rgb_file, self.high_res, False, direction)
        sample[HIGH_RES_DEPTH_IMG] = self.load_image(depth_file, self.high_res, True, direction)
        sample[LOW_RES_DEPTH_IMG] = self.load_image(apple_depth_file, self.low_res, True, direction)

        intrinsic = st2_camera_intrinsics(intrinsic_file)

        ## Map to Marigold's dataloader output format##
        rasters = {}
        rasters['rgb_int'] = torch.from_numpy(sample[COLOR_IMG]).int()
        rasters['rgb_norm'] = torch.from_numpy(self.rgb_transform(sample[COLOR_IMG])).float()

        rasters['depth_raw_linear'] = torch.from_numpy(sample[HIGH_RES_DEPTH_IMG]).float()
        rasters["depth_filled_linear"] = rasters['depth_raw_linear'].clone()

        rasters['valid_mask_raw'] = (rasters['depth_raw_linear'] > 0.0).bool()
        rasters["valid_mask_filled"] = rasters["valid_mask_raw"].clone()

        # Normalization
        if self.depth_transform != None:
            rasters["depth_raw_norm"] = self.depth_transform(rasters["depth_raw_linear"], rasters["valid_mask_raw"].clone())
            rasters["depth_filled_norm"] = self.depth_transform(rasters["depth_filled_linear"], rasters["valid_mask_filled"]).clone()

        other = {"index": index, "rgb_relative_path": os.path.join(video_id, WIDE, sample_id), 'disp_name': self.disp_name, 'intrinsics': intrinsic}
        rasters.update(other)
        return rasters

    def __len__(self) -> int:
        return len(self.samples)

if __name__ == "__main__":
    import matplotlib.pyplot as plt
    from src.dataset import BaseDepthDataset, DatasetMode, get_dataset
    from src.util.depth_transform import *
    mode=DatasetMode.TRAIN
    transform = ScaleShiftDepthNormalizer()
    dataset_path = "../data/arkit/upsampling"
    split = 'val'
    max_depth = 5
    dataset = ARKitScenesDataset(mode=mode, depth_transform=transform, root=dataset_path, split=split)
    print(len(dataset))

    sample = dataset[99]
    breakpoint()
    rgb_int = sample['rgb_int']
    max_depth = np.min([max_depth,
                        sample[HIGH_RES_DEPTH_IMG].max(),
                        sample[LOW_RES_DEPTH_IMG].max()])
    fig, axes = plt.subplots(2, 2, dpi=400)
    axes[0, 0].set_title('Color img')
    axes[0, 0].axis(False)
    axes[0, 0].imshow(image_chw_to_hwc(sample[COLOR_IMG]/255))
    axes[0, 1].set_title('High Res img (0=no depth)')
    axes[0, 1].axis(False)
    img = axes[0, 1].imshow(sample[HIGH_RES_DEPTH_IMG][0], vmin=0, vmax=max_depth, cmap=plt.get_cmap('magma_r'))
    fig.colorbar(img, ax=axes[0, 1])
    axes[1, 1].set_title('Low Res img')
    axes[1, 1].axis(False)
    img = axes[1, 1].imshow(sample[LOW_RES_DEPTH_IMG][0], vmin=0, vmax=max_depth, cmap=plt.get_cmap('magma_r'))
    fig.colorbar(img, ax=axes[1, 1])
    axes[1, 0].set_title('Color and low res overlay')
    axes[1, 0].axis(False)
    axes[1, 0].imshow(image_chw_to_hwc(sample[COLOR_IMG]/255))
    axes[1, 0].imshow(sample[LOW_RES_DEPTH_IMG][0], vmin=0, vmax=max_depth, cmap=plt.get_cmap('magma_r'), alpha=0.5)
    # plt.show()
    # plt.waitforbuttonpress()
    plt.savefig('temp.jpg')