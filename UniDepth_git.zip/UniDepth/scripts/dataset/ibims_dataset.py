import torch

from scripts.dataset.base_depth_dataset import BaseDepthDataset, DepthFileNameMode, get_pred_name
from scripts.dataset import (
        DatasetMode,
    )
import numpy as np
import os
from scipy import io

class iBimsDataset(BaseDepthDataset):
    def __init__(
        self,
        **kwargs,
    ) -> None:
        super().__init__(
            # NYUv2 dataset parameter
            min_depth=1e-3,
            max_depth=200.0,
            has_filled_depth=False,
            name_mode=DepthFileNameMode.id,
            **kwargs,
        )

        self.dataset_dir_depth = self.dataset_dir.replace("nyuv2", "nyuv2_unidepth")
    

    def _get_data_item(self, index):
        rgb_rel_path, depth_rel_path, filled_rel_path = self._get_data_path(index=index)

        rasters = {}
        # RGB data
        image_data = io.loadmat(os.path.join(self.dataset_dir, rgb_rel_path))  
        data = image_data['data']
        #  extract neccessary data
        rgb   = data['rgb'][0][0]   # RGB image
        depth = data['depth'][0][0] # Raw depth map
        edges = data['edges'][0][0] # Ground truth edges
        calib = data['calib'][0][0] # Calibration parameters
        mask_invalid = data['mask_invalid'][0][0]  # Mask for invalid pixels
        mask_transp = data['mask_transp'][0][0]    # Mask for transparent pixels
        

        rgb = np.transpose(rgb, (2, 0, 1)).astype(int)  # [rgb, H, W]
        rgb_norm = rgb / 255.0 * 2.0 - 1.0  #  [0, 255] -> [-1, 1]

        outputs = {
            "rgb_int": torch.from_numpy(rgb).int(),
            "rgb_norm": torch.from_numpy(rgb_norm).float(),
        }
        rasters.update(outputs)
        
        # Depth data
        if DatasetMode.RGB_ONLY != self.mode:
            # load data
            rasters["depth_raw_linear"] = torch.from_numpy(depth).float().unsqueeze(0)
            # valid mask
            rasters["valid_mask_raw"] = torch.from_numpy(mask_invalid).bool().unsqueeze(0)
        
        ## Evaluation Stuff ##

        other = {"index": index, "rgb_relative_path": rgb_rel_path, 'disp_name': self.disp_name, 'intrinsics': torch.tensor(calib.T).float()}
        other["edges"] = torch.from_numpy(edges).unsqueeze(0)
        other["mask_transp"] = torch.from_numpy(mask_transp).unsqueeze(0)
        other["mask_invalid"] = torch.from_numpy(mask_invalid).unsqueeze(0)
        other["mask_wall"] = torch.from_numpy(data["mask_wall"][0][0] ).unsqueeze(0)
        other["mask_wall_paras"] = torch.from_numpy(data["mask_wall_paras"][0][0] ).unsqueeze(0)
        other["mask_table"] = torch.from_numpy(data["mask_table"][0][0] ).unsqueeze(0)
        other["mask_table_paras"] = torch.from_numpy(data["mask_table_paras"][0][0] ).unsqueeze(0)
        other["mask_floor"] = torch.from_numpy(data["mask_floor"][0][0] ).unsqueeze(0)
        other["mask_floor_paras"] = torch.from_numpy(data["mask_floor_paras"][0][0] ).unsqueeze(0)

        return rasters, other

if __name__ == "__main__":
    from omegaconf import OmegaConf
    from src.dataset import (
        BaseDepthDataset,
        DatasetMode,
        get_dataset,
        get_pred_name,
    )
    from torch.utils.data import DataLoader
    from src.util.depth_transform import (
        DepthNormalizerBase,
        get_depth_normalizer,
    )
    from src.util.config_util import (
        find_value_in_omegaconf,
        recursive_load_config,
    )
    import matplotlib.pyplot as plt

    dataset_config = "config/dataset/data_ibims_test.yaml"
    base_data_dir = "/home/ubuntu/Working/haipd13/diffusion/data"
    config = "/home/ubuntu/Working/haipd13/diffusion/Marigold/dev/real_data/configs/train_marigold.yaml"

    cfg_data = OmegaConf.load(dataset_config)
    cfg = recursive_load_config(config)
    
    depth_transform: DepthNormalizerBase = get_depth_normalizer(
        cfg_normalizer=cfg.depth_normalization
    )

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL,
        depth_transform=depth_transform
    )
    out = dataset.__getitem__(0)

    breakpoint()