# Last modified: 2024-02-08
#
# Copyright 2023 Bingxin Ke, ETH Zurich. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# --------------------------------------------------------------------------
# If you find this code useful, we kindly ask you to cite our paper in your work.
# Please find bibtex at: https://github.com/prs-eth/Marigold#-citation
# If you use or adapt this code, please attribute to https://github.com/prs-eth/marigold.
# More information about the method can be found at https://marigoldmonodepth.github.io
# --------------------------------------------------------------------------

import torch

from scripts.dataset.base_depth_dataset import BaseDepthDataset, DepthFileNameMode
from scripts.dataset.base_depth_dataset import (
        DatasetMode,
    )
import numpy as np
import os
import glob 


TAG_FLOAT = 202021.25
TAG_CHAR = 'PIEH'

def depth_read(filename):
    """ Read depth data from file, return as numpy array. """
    f = open(filename,'rb')
    check = np.fromfile(f,dtype=np.float32,count=1)[0]
    assert check == TAG_FLOAT, ' depth_read:: Wrong tag in flow file (should be: {0}, is: {1}). Big-endian machine? '.format(TAG_FLOAT,check)
    width = np.fromfile(f,dtype=np.int32,count=1)[0]
    height = np.fromfile(f,dtype=np.int32,count=1)[0]
    size = width*height
    assert width > 0 and height > 0 and size > 1 and size < 100000000, ' depth_read:: Wrong input size (width = {0}, height = {1}).'.format(width,height)
    depth = np.fromfile(f,dtype=np.float32,count=-1).reshape((height,width))
    return depth


class SintelDataset(BaseDepthDataset):
    def __init__(
        self,
        **kwargs,
    ) -> None:
        super().__init__(
            min_depth=1e-3,
            max_depth=200.0,
            has_filled_depth=False,
            name_mode=DepthFileNameMode.rgb_id,
            **kwargs,
        )

        self.intrinsics = torch.tensor([[518.8579, 0, 325.58245],
                                        [0, 519.46961, 253.73617],
                                        [0, 0, 1]]).float()
        
         
        self.scenes = sorted(os.listdir(os.path.join(self.dataset_dir, "training", "final")))
        self.img_path = []
        self.depth_path = []
        self.intrinsic_path = []
        for s in self.scenes:
            files = os.listdir(os.path.join(self.dataset_dir, "training", "final", s))
            for f in files:
                self.img_path.append(os.path.join("training", "final", s, f))
                self.depth_path.append(os.path.join(self.dataset_dir, "training", "depth", s, f.replace('png', 'dpt')))
                self.intrinsic_path.append(os.path.join(self.dataset_dir, "training", "camdata_left", s, f.replace('png', 'cam')))

    # The code for cam_read() is taken from the MPI Sintel Depth dataset SDK
    def cam_read(self, filename):
        """ Read camera data, return (M,N) tuple.
        M is the intrinsic matrix, N is the extrinsic matrix, so that
        x = M*N*X,
        with x being a point in homogeneous image pixel coordinates, X being a
        point in homogeneous world coordinates.
        """
        TAG_FLOAT = 202021.25
        f = open(filename,'rb')
        check = np.fromfile(f,dtype=np.float32,count=1)[0]
        assert check == TAG_FLOAT, ' cam_read:: Wrong tag in flow file (should be: {0}, is: {1}). Big-endian machine? '.format(TAG_FLOAT,check)
        M = np.fromfile(f,dtype='float64',count=9).reshape((3,3))
        N = np.fromfile(f,dtype='float64',count=12).reshape((3,4))
        return M,N

    def _read_depth_file(self, rel_path):
        depth_in = depth_read(rel_path)
        return depth_in

    def _get_valid_mask(self, depth: torch.Tensor):
        valid_mask = super()._get_valid_mask(depth)
        return valid_mask

    def _get_data_path(self, index):
        # Get data path
        rgb_rel_path = self.img_path[index]

        depth_rel_path, filled_rel_path = None, None
        if DatasetMode.RGB_ONLY != self.mode:
            depth_rel_path = self.depth_path[index]
            filled_rel_path = None
            
        return rgb_rel_path, depth_rel_path, filled_rel_path

    def __len__(self):
        return len(self.img_path)

    def _get_data_item(self, index):
        rgb_rel_path, depth_rel_path, filled_rel_path = self._get_data_path(index=index)
        
        rasters = {}
        # RGB data
        rasters.update(self._load_rgb_data(rgb_rel_path=rgb_rel_path))

        # Depth data
        if DatasetMode.RGB_ONLY != self.mode:
            # load data
            depth_data = self._load_depth_data(
                depth_rel_path=depth_rel_path, filled_rel_path=filled_rel_path
            )
            rasters.update(depth_data)
            # valid mask
            rasters["valid_mask_raw"] = self._get_valid_mask(
                rasters["depth_raw_linear"]
            ).clone()
            rasters["valid_mask_filled"] = self._get_valid_mask(
                rasters["depth_filled_linear"]
            ).clone()

        intrinsic, _ = self.cam_read(self.intrinsic_path[index])
        other = {"index": index, "rgb_relative_path": rgb_rel_path, 'disp_name': self.disp_name, 'intrinsics': torch.from_numpy(intrinsic).float()}

        return rasters, other

if __name__ == "__main__":
    from omegaconf import OmegaConf
    from src.dataset import (
        BaseDepthDataset,
        DatasetMode,
        get_dataset,
        get_pred_name,
    )
    from torch.utils.data import DataLoader
    from src.util.depth_transform import (
        DepthNormalizerBase,
        get_depth_normalizer,
    )
    from src.util.config_util import (
        find_value_in_omegaconf,
        recursive_load_config,
    )

    dataset_config = "config/dataset/data_sintel_test.yaml"
    base_data_dir = "/home/ubuntu/Working/haipd13/diffusion/data"
    config = "/home/ubuntu/Working/haipd13/diffusion/Marigold/dev/real_data/configs/train_marigold.yaml"

    cfg_data = OmegaConf.load(dataset_config)
    cfg = recursive_load_config(config)

    depth_transform: DepthNormalizerBase = get_depth_normalizer(
        cfg_normalizer=cfg.depth_normalization
    )

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL,
        depth_transform=depth_transform
    )
    out = dataset.__getitem__(9)
    img = out['rgb_int']
    depth = out['depth_raw_linear']
    breakpoint()


