import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from PIL import Image
import cv2
from scripts.colmap_loaders import *

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = torch.hub.load('yvanyin/metric3d', 'metric3d_vit_large', pretrain=True)
    model.to(device)
    input_size = (616, 1064) # for vit model
    
    dataset_config = '/home/ubuntu/Working/haipd13/diffusion/Marigold/config/dataset/data_eth3d.yaml'
    base_data_dir = '/home/ubuntu/Working/haipd13/diffusion/data'
    output_dir = '/home/ubuntu/Working/haipd13/diffusion/unidepth_exp/eval/metric3dv2/eth3d/prediction'
    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=0)

    # dataset._get_data_item(0)

    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            # Read input image
            rgb_origin = batch["rgb_int"].squeeze().permute(1,2,0).numpy().astype(np.uint8)
            depth_gt = batch['depth_raw_linear'].to(device).squeeze(0).squeeze(0)
            # intrinsics = batch["intrinsics"]

            h, w = rgb_origin.shape[:2]
            scale = min(input_size[0] / h, input_size[1] / w)
            rgb = cv2.resize(rgb_origin, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_LINEAR)

            # intrinsic = [intrinsics[0][0,0], intrinsics[0][1,1], intrinsics[0][0,2], intrinsics[0][1,2], ]
            # intrinsics = torch.tensor([[518.8579, 0, 325.58245],
            #                 [0, 519.46961, 253.73617],
            #                 [0, 0, 1]]).float()

            # intrinsic = [518.8579, 519.46961, 325.58245, 253.73617]
            # remember to scale intrinsic, hold depth
            # intrinsic = [intrinsic[0] * scale, intrinsic[1] * scale, intrinsic[2] * scale, intrinsic[3] * scale]

            data_path = batch['rgb_relative_path'][0]
            parts = data_path.split('/')

            intrinsics_path = os.path.join(dataset.dataset_dir, parts[0], parts[1], 'dslr_calibration_jpg', 'cameras.txt')
            intrinsics = read_intrinsics_text(intrinsics_path)
            params = intrinsics[0].params

            intrinsic = [params[0] * scale, params[1] * scale, params[2] * scale, params[3] * scale]
            
            # padding to input_size
            padding = [123.675, 116.28, 103.53]
            h, w = rgb.shape[:2]
            pad_h = input_size[0] - h
            pad_w = input_size[1] - w
            pad_h_half = pad_h // 2
            pad_w_half = pad_w // 2
            rgb = cv2.copyMakeBorder(rgb, pad_h_half, pad_h - pad_h_half, pad_w_half, pad_w - pad_w_half, cv2.BORDER_CONSTANT, value=padding)
            pad_info = [pad_h_half, pad_h - pad_h_half, pad_w_half, pad_w - pad_w_half]

            #### normalize
            mean = torch.tensor([123.675, 116.28, 103.53]).float()[:, None, None]
            std = torch.tensor([58.395, 57.12, 57.375]).float()[:, None, None]
            rgb = torch.from_numpy(rgb.transpose((2, 0, 1))).float()
            rgb = torch.div((rgb - mean), std)
            rgb = rgb[None, :, :, :].cuda()

            with torch.no_grad():
                pred_depth, confidence, output_dict = model.inference({'input': rgb})
            
            # un pad
            pred_depth = pred_depth.squeeze()
            pred_depth = pred_depth[pad_info[0] : pred_depth.shape[0] - pad_info[1], pad_info[2] : pred_depth.shape[1] - pad_info[3]]
            
            # upsample to original size
            pred_depth = torch.nn.functional.interpolate(pred_depth[None, None, :, :], rgb_origin.shape[:2], mode='bilinear').squeeze()
            ###################### canonical camera space ######################

            #### de-canonical transform
            canonical_to_real_scale = intrinsic[0] / 1000.0 # 1000.0 is the focal length of canonical camera
            pred_depth = pred_depth * canonical_to_real_scale # now the depth is metric
            pred_depth = torch.clamp(pred_depth, 0, 300)

            mask = (depth_gt > 1e-8)
            abs_rel_err = (torch.abs(pred_depth[mask] - depth_gt[mask]) / depth_gt[mask]).mean()
            print(abs_rel_err)
            depth_pred = pred_depth.cpu().numpy()

            # Save predictions
            rgb_filename = batch["rgb_relative_path"][0]
            rgb_basename = os.path.basename(rgb_filename)
            scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
            if not os.path.exists(scene_dir):
                os.makedirs(scene_dir)
            pred_basename = get_pred_name(
                rgb_basename, dataset.name_mode, suffix=".npy"
            )
            save_to = os.path.join(scene_dir, pred_basename)
            if os.path.exists(save_to):
                logging.warning(f"Existing file: '{save_to}' will be overwritten")

            np.save(save_to, depth_pred)