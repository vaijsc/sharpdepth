from promptda.promptda import PromptDA
from promptda.utils.io_wrapper import load_image, load_depth, save_depth
import torch
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import matplotlib

def colorize(
    value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "magma_r"
):
    # if already RGB, do nothing
    if value.ndim > 2:
        if value.shape[-1] > 1:
            return value
        value = value[..., 0]
    invalid_mask = value < 0.0001
    # normalize
    vmin = value.min() if vmin is None else vmin
    vmax = value.max() if vmax is None else vmax
    value = (value - vmin) / (vmax - vmin)  # vmin..vmax

    # set color
    cmapper = matplotlib.cm.get_cmap(cmap)
    value = cmapper(value, bytes=True)  # (nxmx4)
    value[invalid_mask] = 0
    img = value[..., :3]
    return img


if __name__ == "__main__":
    DEVICE = 'cuda'
    image_path = "../PromptDA-main/assets/example_images/47204575_4847.103.png"
    prompt_depth_path = "../PromptDA-main/assets/example_images/47204575_4847.103_low.png"
    image = load_image(image_path).to(DEVICE)
    prompt_depth = load_depth(prompt_depth_path).to(DEVICE) # 192x256, ARKit LiDAR depth in meters

    ## Randomly Mask Prompt Depth ##
    _, channel, height, width = prompt_depth.shape

    idx_nnz = torch.nonzero(prompt_depth.view(-1) > 0.0001, as_tuple=False)

    num_idx = len(idx_nnz)
    idx_sample = torch.randperm(num_idx)[:5000]

    idx_nnz = idx_nnz[idx_sample[:]]

    mask = torch.zeros((channel*height*width))
    mask[idx_nnz] = 1.0
    mask = mask.view((channel, height, width))

    dep_sp = prompt_depth * mask.type_as(prompt_depth)

    model = PromptDA.from_pretrained("depth-anything/promptda_vitl").to(DEVICE).eval()
    depth = model.predict(image, prompt_depth) # HxW, depth in meters

    color_depth = colorize(depth.squeeze().cpu().numpy())
    Image.fromarray(color_depth).save('temp_promptda_depth_dense_1.jpg')

    color_depth = colorize(prompt_depth.squeeze().cpu().numpy())
    Image.fromarray(color_depth).save('temp_promptda_prompt_dense_1.jpg')


    depth = model.predict(image, dep_sp) 
    color_depth = colorize(depth.squeeze().cpu().numpy())
    Image.fromarray(color_depth).save('temp_promptda_depth_sparse_5k_1.jpg')

    color_depth = colorize(dep_sp.squeeze().cpu().numpy())
    Image.fromarray(color_depth).save('temp_promptda_prompt_sparse_5k_1.jpg')

    # plt.figure(figsize=(15,15))
    # plt.imshow(prompt_depth.squeeze().cpu())
    # plt.axis('off')
    # plt.savefig('temp_prompt_da.jpg')
    
    # plt.figure(figsize=(15,15))
    # plt.imshow(depth.squeeze().cpu())
    # plt.axis('off')
    # plt.savefig('temp_depth_dense.jpg')

    # plt.figure(figsize=(15,15))
    # plt.imshow(dep_sp.squeeze().cpu())
    # plt.axis('off')
    # plt.savefig('temp_prompt_da_sparse_25000.jpg')

    # plt.figure(figsize=(15,15))
    # plt.imshow(depth.squeeze().cpu())
    # plt.axis('off')
    # plt.savefig('temp_depth_sparse_25000.jpg')

    breakpoint()