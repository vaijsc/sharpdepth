import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from PIL import Image

from unidepth.models import UniDepthV1, UniDepthV2
from unidepth.utils import colorize, image_grid

from promptda.promptda import PromptDA
from promptda.utils.io_wrapper import *

from scipy.interpolate import griddata
import matplotlib

def infilling(depth):
    h, w = depth.shape
    row, col = np.meshgrid(np.linspace(0, w-1, num=w), np.linspace(0, h-1, num=h))  
    vv = np.stack([row,col,depth], axis=-1)
    mask = vv[..., 2] > 0
    dmd = griddata(vv[mask][..., :2].reshape(-1,2), vv[mask][..., 2].reshape(-1), (row, col), method='nearest')    #try 'nearest','linear'

    dmd = np.where(dmd < 0, 0, dmd)

    # mask the result to the ROI
    mask = np.zeros((h, w))                                # initialize mask 
    ind = (depth != 0).argmax(axis=0)
    for i in range(w):
        mask[ind[i]:, i] = 1

    kernel = np.ones((2, 10), np.uint8)
    mask   = cv2.dilate(mask,kernel,iterations = 1)                         # by Dilation

    # ## mask the depth map
    # dm  = dmd
    bool_mask = mask == 1
    # dm[bool_mask] = 100

    return dmd, bool_mask


def load_image(image, to_tensor=True, max_size=1008, multiple_of=14):
    '''
    Load image from path and convert to tensor
    max_size // 14 = 0
    '''
    image = image / 255.

    max_size = max_size // multiple_of * multiple_of
    if max(image.shape) > max_size:
        h, w = image.shape[:2]
        scale = max_size / max(h, w)
        tar_h = ensure_multiple_of(h * scale)
        tar_w = ensure_multiple_of(w * scale)
        image = cv2.resize(image, (tar_w, tar_h), interpolation=cv2.INTER_AREA)
    if to_tensor:
        return to_tensor_func(image)
    return image

def colorize(
    value: np.ndarray, vmin: float = None, vmax: float = None, cmap: str = "magma_r"
):
    # if already RGB, do nothing
    if value.ndim > 2:
        if value.shape[-1] > 1:
            return value
        value = value[..., 0]
    invalid_mask = value < 0.0001
    # normalize
    vmin = value.min() if vmin is None else vmin
    vmax = value.max() if vmax is None else vmax
    value = (value - vmin) / (vmax - vmin)  # vmin..vmax

    # set color
    cmapper = matplotlib.cm.get_cmap(cmap)
    value = cmapper(value, bytes=True)  # (nxmx4)
    value[invalid_mask] = 0
    img = value[..., :3]
    return img


if __name__ == "__main__":
    print("Torch version:", torch.__version__)
    name = "unidepth-v2-vitl14"
    # model = UniDepthV2.from_pretrained(f"lpiccinelli/{name}")

    # set resolution level (only V2)
    # model.resolution_level = 0

    # set interpolation mode (only V2)
    # model.interpolation_mode = "bilinear"

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = PromptDA.from_pretrained("depth-anything/promptda_vitl").to(device).eval()


    dataset_config = '/home/ubuntu/Working/haipd13/diffusion/Marigold/config/dataset/data_kitti_eigen_test_dc.yaml'
    base_data_dir = '/home/ubuntu/Working/haipd13/diffusion/data'
    output_dir = '../unidepth_exp/eval/unidepthv1_with_intrinsics/kitti_dc'
    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=2, shuffle=True)

    # dataset._get_data_item(0)

    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            # Read input image
            rgb = batch["rgb_int"].squeeze().permute(1,2,0).numpy()

            Image.fromarray(rgb.astype(np.uint8)).save('temp_kitti_color.jpg')

            image = load_image(rgb.astype(np.float32)).to(device)
            prompt_depth = batch['depth_filled_linear'].to(device)
            depth = model.predict(image, prompt_depth) 

            color_sparse = colorize(prompt_depth.squeeze().cpu().numpy())
            Image.fromarray(color_sparse).save('temp_kitti_sparse.jpg')
            
            color_sparse = colorize(depth.squeeze().cpu().numpy())
            Image.fromarray(color_sparse).save('temp_kitti_sparse_pred.jpg')

            filled_depth, _ = infilling(prompt_depth.squeeze().cpu().numpy())
            depth = model.predict(image, torch.from_numpy(filled_depth)[None, None].to(device).float()) 
            
            color_sparse = colorize(filled_depth)
            Image.fromarray(color_sparse).save('temp_kitti_dense.jpg')


            color_sparse = colorize(depth.squeeze().cpu().numpy())
            Image.fromarray(color_sparse).save('temp_kitti_dense_pred.jpg')

            breakpoint()
            # # Save predictions
            # rgb_filename = batch["rgb_relative_path"][0]
            # rgb_basename = os.path.basename(rgb_filename)
            # scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
            # if not os.path.exists(scene_dir):
            #     os.makedirs(scene_dir)
            # pred_basename = get_pred_name(
            #     rgb_basename, dataset.name_mode, suffix=".npy"
            # )

            # save_to = os.path.join(scene_dir, pred_basename)
            # if os.path.exists(save_to):
            #     logging.warning(f"Existing file: '{save_to}' will be overwritten")

            # np.save(save_to, depth_pred)
