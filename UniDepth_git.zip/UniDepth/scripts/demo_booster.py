import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from PIL import Image

from unidepth.models import UniDepthV1, UniDepthV2
from unidepth.utils import colorize, image_grid
from scripts.colmap_loaders import *

if __name__ == "__main__":
    print("Torch version:", torch.__version__)
    name = "unidepth-v2-vitl14"
    model = UniDepthV1.from_pretrained("lpiccinelli/unidepth-v1-vitl14")
    # model = UniDepthV2.from_pretrained(f"lpiccinelli/{name}")

    # set resolution level (only V2)
    # model.resolution_level = 0

    # set interpolation mode (only V2)
    # model.interpolation_mode = "bilinear"

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    dataset_config = '/home/ubuntu/Working/haipd13/diffusion/Marigold/config/dataset/data_booster_test.yaml'
    base_data_dir = '/home/ubuntu/Working/haipd13/diffusion/data'
    output_dir = '/home/ubuntu/Working/haipd13/diffusion/unidepth_exp/eval/unidepthv1_with_intrinsics/booster/prediction'
    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=2)

    # dataset._get_data_item(0)

    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            # Read input image
            rgb = batch["rgb_int"].squeeze().numpy().astype(np.uint8)
            rgb_torch = torch.from_numpy(rgb)
            
            data_path = batch['rgb_relative_path'][0]
            parts = data_path.split('/')

            # intrinsics_path = os.path.join(dataset.dataset_dir, parts[0], parts[1], 'dslr_calibration_jpg', 'cameras.txt')
            # intrinsics = read_intrinsics_text(intrinsics_path)
            # params = intrinsics[0].params
            # 
            intrinsics = batch["intrinsics"]
            # params = [886.81, 927.06, 512, 384]
            # intrinsics = torch.tensor([[params[0], 0, params[2]],
            #                            [0, params[1], params[3]],
            #                            [0,0,1]]).float()

            predictions = model.infer(rgb_torch, intrinsics)
            
            depth_pred = predictions["depth"].squeeze().cpu().numpy()

            # Save predictions
            rgb_filename = batch["rgb_relative_path"][0]
            rgb_basename = os.path.basename(rgb_filename)
            scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
            if not os.path.exists(scene_dir):
                os.makedirs(scene_dir)
            pred_basename = get_pred_name(
                rgb_basename, dataset.name_mode, suffix=".npy"
            )
            save_to = os.path.join(scene_dir, pred_basename)
            if os.path.exists(save_to):
                logging.warning(f"Existing file: '{save_to}' will be overwritten")

            np.save(save_to, depth_pred)

