import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from PIL import Image
import depth_pro

import matplotlib.pyplot as plt

if __name__ == "__main__":
    print("Torch version:", torch.__version__)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # model = model.to(device)
    model, transform = depth_pro.create_model_and_transforms()
    model.eval().to(device)


    dataset_config = '/root/data_hai/diffusion/Marigold/config/dataset/data_taskonomy_train.yaml'
    base_data_dir = '/root/data_hai/diffusion/data'
    output_dir = '/root/data_hai/diffusion/unidepth_exp/eval/depthpro/taskonomy/prediction'
    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=0)

    # dataset._get_data_item(0)

    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            # Save predictions
            rgb_filename = batch["rgb_relative_path"][0]
            rgb_basename = os.path.basename(rgb_filename)
            scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
            if not os.path.exists(scene_dir):
                os.makedirs(scene_dir)
            pred_basename = get_pred_name(
                rgb_basename, dataset.name_mode, suffix=".npy"
            )
            save_to = os.path.join(scene_dir, pred_basename)
            if os.path.exists(save_to):
                logging.warning(f"Existing file: '{save_to}' will be overwritten")
                continue
                
            # Read input image
            rgb = batch["rgb_int"].squeeze().permute(1,2,0).numpy().astype(np.uint8)
            # rgb_torch = torch.from_numpy(rgb)
            
            # intrinsics = batch["intrinsics"]
            # intrinsics = torch.tensor([[intrinsics[0], 0, intrinsics[2]],
            #                            [0, intrinsics[1], intrinsics[3]],
            #                            [0,0,1]]).float()
            # Load and preprocess an image.
            # image, _, f_px = depth_pro.load_rgb(image_path)
            image = transform(rgb)

            # Run inference.
            prediction = model.infer(image.to(device))
            depth = prediction["depth"].cpu().numpy()  # Depth in [m].
            focallength_px = prediction["focallength_px"]  # Focal length in pixels.
            # predictions = model.infer(rgb_torch, intrinsics)
            # depth_pred = predictions["depth"].squeeze().cpu().numpy()


            plt.figure(figsize=(5,5))
            plt.imshow(1/depth)
            plt.axis('off')
            plt.savefig('temp_ts_dp.jpg')
            np.save(save_to, depth)

