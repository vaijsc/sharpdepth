

import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from PIL import Image

from unidepth.models import UniDepthV1, UniDepthV2
from unidepth.utils import colorize, image_grid
from scripts.colmap_loaders import *
import glob
import cv2

import matplotlib.pyplot as plt
from torchvision.transforms import Resize

if __name__ == "__main__":
    print("Torch version:", torch.__version__)
    name = "unidepth-v2-vitl14"
    model = UniDepthV1.from_pretrained("lpiccinelli/unidepth-v1-vitl14")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    # Create predictor instance
    predictor = torch.hub.load("Stable-X/StableNormal", "StableNormal", trust_repo=True)
    predictor.to(device)

    root_path="/home/ubuntu/Working/haipd13/diffusion/data/monosdf/DTU/scan24/image/*.png"
    dataset_id = "scan24"
    # root_path = root_path+dataset_id+'/images_8/*png'
    image_paths = sorted(glob.glob(root_path))
    # /home/haipd13/khoigroup/haipd13/diffusion/data/monosdf/DTU/scan65/image
    output_dir = '/home/ubuntu/Working/haipd13/diffusion/unidepth_exp/eval/unidepthv1_no_intrinsics/DTU_large/'

    os.makedirs(os.path.join(output_dir, dataset_id), exist_ok=True)
    with torch.no_grad():
        for k in range(len(image_paths)):
            filename = image_paths[k]
            img = cv2.imread(filename)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            print('k, img.shape:', k, img.shape) #(1213, 1546, 3)
            h, w = img.shape[:2]

            rgb_torch = torch.from_numpy(img).permute(2,0,1)
            predictions = model.infer(rgb_torch)

            depth_pred = predictions["depth"].squeeze().cpu().numpy()

            plt.figure(figsize=(10,10))
            plt.axis('off')
            plt.imshow(1/depth_pred)
            plt.savefig('temp.jpg')        

            from PIL import Image

            name = os.path.basename(filename).replace('.png', '_depth.npy')
            output_file_name = os.path.join(output_dir, dataset_id, name)
            np.save(output_file_name, depth_pred)

            pred_normal = predictor(Image.fromarray(img))
            pred_normal_norm = np.asarray(pred_normal) / 255.0
            # pred_normal, new_dims = predictor(Image.fromarray(img))
            # norm = Resize(size=new_dims)(pred_normal.permute(0,3,1,2))
            # nom = np.load("../monosdf/data/DTU/scan65/000000_normal.npy")
            name = os.path.basename(filename).replace('.png', '_normal.npy')
            output_file_name = os.path.join(output_dir, dataset_id, name)
            np.save(output_file_name, pred_normal_norm.transpose(2,0,1))
