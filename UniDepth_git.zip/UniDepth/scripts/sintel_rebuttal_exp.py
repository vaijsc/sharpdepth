import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from PIL import Image

from unidepth.models import UniDepthV1, UniDepthV2
from unidepth.utils import colorize, image_grid

import diffusers
from diffusers import UNet2DConditionModel, DDPMScheduler, AutoencoderKL
from diffusers.utils.import_utils import is_xformers_available
import transformers
from transformers import AutoTokenizer, PretrainedConfig

from scripts.util.depth_transform import (
                                        DepthNormalizerBase,
                                        get_depth_normalizer,
                                    )

from scripts.util.config_util import (
                                    find_value_in_omegaconf,
                                    recursive_load_config,
                                )

def import_model_class_from_model_name_or_path(pretrained_model_name_or_path: str, revision: str):
    text_encoder_config = PretrainedConfig.from_pretrained(
        pretrained_model_name_or_path, subfolder="text_encoder", revision=revision
    )
    model_class = text_encoder_config.architectures[0]

    if model_class == "CLIPTextModel":
        from transformers import CLIPTextModel

        return CLIPTextModel
    elif model_class == "CLIPTextModelWithProjection":
        from transformers import CLIPTextModelWithProjection

        return CLIPTextModelWithProjection
    else:
        raise ValueError(f"{model_class} is not supported.")

@torch.no_grad()
def encode_depth(vae, depth):
    depth_latent = vae.encode(depth.repeat(1, 3, 1, 1)).latent_dist.sample()
    depth_latent = depth_latent * vae.config.scaling_factor
    return depth_latent

@torch.no_grad()
def encode_image(vae, rgb):
    rgb_latent = vae.encode(rgb).latent_dist.sample()
    rgb_latent = rgb_latent * vae.config.scaling_factor
    return rgb_latent


def encode_empty_text(tokenizer, text_encoder):
    """
    Encode text embedding for empty prompt
    """
    prompt = ""
    text_inputs = tokenizer(
        prompt,
        padding="do_not_pad",
        max_length=tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
    text_input_ids = text_inputs.input_ids.to(text_encoder.device)
    empty_text_embed = text_encoder(text_input_ids)[0]

    return empty_text_embed

def abs_relative_difference_full(output, target, valid_mask=None):
    actual_output = output
    actual_target = target
    abs_relative_diff = torch.abs(actual_output - actual_target) / actual_target
    if valid_mask is not None:
        abs_relative_diff[~valid_mask] = 0
        n = valid_mask.sum((-1, -2))
    else:
        n = output.shape[-1] * output.shape[-2]
    return abs_relative_diff


if __name__ == "__main__":
    print("Torch version:", torch.__version__)
    model = UniDepthV1.from_pretrained("lpiccinelli/unidepth-v1-vitl14")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    dataset_config = '/home/ubuntu/Working/diffusion/Marigold/config/dataset/data_sintel_test.yaml'
    base_data_dir = '/home/ubuntu/Working/diffusion/data'
    config =  '/home/ubuntu/Working/diffusion/Marigold/dev/refine_plus/main_tung/configs/main_indoor.yaml'
    
    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)
    cfg = recursive_load_config(config)

    ## Lotus ##
    base_ckpt_dir = "jingheya/lotus-depth-g-v1-0"
    tokenizer = AutoTokenizer.from_pretrained(base_ckpt_dir, subfolder="tokenizer")
    text_encoder_cls = import_model_class_from_model_name_or_path(base_ckpt_dir, revision=None)
    text_encoder = text_encoder_cls.from_pretrained(base_ckpt_dir, subfolder="text_encoder", revision=None)
    vae = AutoencoderKL.from_pretrained(base_ckpt_dir, subfolder="vae", revision=None)
    unidepth_transform = get_depth_normalizer(cfg_normalizer=cfg.unidepth_normalization)
    student_unet = UNet2DConditionModel.from_pretrained(base_ckpt_dir, subfolder='unet', revision=None)
    noise_scheduler = DDPMScheduler.from_pretrained(base_ckpt_dir, subfolder="scheduler")
    
    student_unet.to(device)
    vae.to(device)
    text_encoder.to(device)

    # -------------------- Precompute null & task embedding --------------------
    empty_text_emb = encode_empty_text(tokenizer, text_encoder).to(device)
    del tokenizer
    del text_encoder
    task_emb = torch.tensor([1, 0]).float().unsqueeze(0).repeat(1, 1)
    task_emb = torch.cat([torch.sin(task_emb), torch.cos(task_emb)], dim=-1)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=4)
    
    error_high_diff = 0
    error_low_diff = 0

    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            # Read input image
            rgb = batch["rgb_int"].squeeze().numpy().astype(np.uint8)
            rgb_torch = torch.from_numpy(rgb)
            
            intrinsics = batch["intrinsics"]
            predictions = model.infer(rgb_torch, intrinsics)
            depth_pred = predictions["depth"].squeeze().cpu().numpy()
            
            valid_mask = batch['valid_mask_raw']
            

            transformed_output  = unidepth_transform(predictions["depth"], sky_mask=valid_mask)
            norm_depth_unidepth = transformed_output["norm_depth"]

            rgb             = batch["rgb_norm"][:, :3, :, :].to(device)             # rgn in range [-1, 1]
            rgb_latent = encode_image(vae, rgb)
            lotus_timesteps = torch.ones((rgb_latent.shape[0],), device=device) * (noise_scheduler.config.num_train_timesteps - 1)
            lotus_timesteps = lotus_timesteps.long()

            unidepth_latent = encode_depth(vae, norm_depth_unidepth)

            batch_empty_text_embed = empty_text_emb.repeat((rgb_latent.shape[0], 1, 1)).to(device)
            batch_task_emb = task_emb.repeat((rgb_latent.shape[0], 1)).to(device)

            # --------------------------------- 
            # extract mask
            lotus_input = torch.cat([rgb_latent.detach(), torch.randn_like(rgb_latent)], dim=1)  # this order is important
            pred_latent  = student_unet(lotus_input, lotus_timesteps, batch_empty_text_embed, class_labels=batch_task_emb).sample
            # decode pred_latent to depth
            latent = pred_latent / vae.config.scaling_factor
            z = vae.post_quant_conv(latent)
            lotus_depth = vae.decoder(z).mean(dim=1, keepdim=True)
            lotus_depth = torch.nn.functional.interpolate(lotus_depth, norm_depth_unidepth.shape[-2:], mode="bilinear")

            # calculate difference
            l1_error            = torch.abs(lotus_depth -  norm_depth_unidepth)
            l1_error            = l1_error/l1_error.max()
            l1_error            = l1_error.clip(0, 1)

            mask = l1_error > 0.8
            # inv_mask = l1_error <= 0.5

            ## ##
            gt = batch['depth_raw_linear'].to(device)
            out = abs_relative_difference_full(predictions["depth"], gt, mask)
            out_inv = abs_relative_difference_full(predictions["depth"], gt, ~mask)
            print(out.mean(), out_inv.mean())
            error_high_diff += out.mean()
            error_low_diff += out_inv.mean()

        print(f'Final High Diff Error: {error_high_diff / len(dataloader)}')
        print(f'Final Low Diff Error: {error_low_diff / len(dataloader)}')
