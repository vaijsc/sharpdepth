import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from PIL import Image

from unidepth.models import UniDepthV1, UniDepthV2
from unidepth.utils import colorize, image_grid

import time

from unidepth.models.unidepthv1.unidepthv1 import _shapes, _paddings, _preprocess
from unidepth.utils.constants import (IMAGENET_DATASET_MEAN,
                                      IMAGENET_DATASET_STD)

from ptflops import get_model_complexity_info
from functools import partial
import torch.nn.functional as F
import torchvision.transforms.functional as TF

def preproc(input_shape, model, rgbs):
    if rgbs.ndim == 3:
        rgbs = rgbs.unsqueeze(0)
    B, _, H, W = rgbs.shape

    rgbs = rgbs.to(model.device)

    # process image and intrinsiscs (if any) to match network input (slow?)
    if rgbs.max() > 5 or rgbs.dtype == torch.uint8:
        rgbs = rgbs.to(torch.float32).div(255)

    if rgbs.min() >= 0.0 and rgbs.max() <= 1.0:
        rgbs = TF.normalize(
            rgbs,
            mean=IMAGENET_DATASET_MEAN,
            std=IMAGENET_DATASET_STD,
        )

    (h, w), ratio = _shapes((H, W), model.image_shape)
    pad_left, pad_right, pad_top, pad_bottom = _paddings((h, w), model.image_shape)
    rgbs, gt_intrinsics = _preprocess(
        rgbs,
        None,
        (h, w),
        (pad_left, pad_right, pad_top, pad_bottom),
        ratio,
        model.image_shape,
    )
    inputs = dict()
    inputs['inputs'] = {"image": rgbs}
    inputs['image_metas'] = rgbs
    return inputs

if __name__ == "__main__":
    print("Torch version:", torch.__version__)
    name = "unidepth-v2-vitl14"
    model = UniDepthV1.from_pretrained("lpiccinelli/unidepth-v1-vitl14")
    # model = UniDepthV2.from_pretrained(f"lpiccinelli/{name}")

    # set resolution level (only V2)
    # model.resolution_level = 0

    # set interpolation mode (only V2)
    # model.interpolation_mode = "bilinear"

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    dataset_config = '/root/data_hai/diffusion/Marigold/config/dataset/data_kitti_train.yaml'
    base_data_dir = '/root/data_hai/diffusion/data'
    output_dir = '/root/data_hai/diffusion/data/kitti_unidepth/train'
    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=4)

    # dataset._get_data_item(0)

    num_warmup = 5
    pure_inf_time = 0
    fps = 0
    log_interval = 50
    max_iter = 2000

    with torch.no_grad():
        for i, batch in tqdm(
            enumerate(dataloader), desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            # Read input image
            rgb = batch["rgb_int"].squeeze().numpy().astype(np.uint8)
            rgb_torch = torch.from_numpy(rgb)
            
            flops_count, params_count = get_model_complexity_info(
                model, tuple(rgb_torch.shape[1:]), as_strings=True,
                input_constructor=partial(preproc, model=model, rgbs=rgb_torch),
                print_per_layer_stat=False)

            breakpoint()
            # torch.cuda.synchronize()
            # start_time = time.perf_counter()
                                 
            # predictions = model.infer(rgb_torch)
            # depth_pred = predictions["depth"].squeeze().cpu().numpy()
            
            # torch.cuda.synchronize()
            # elapsed = time.perf_counter() - start_time

            # if i >= num_warmup:
            #     pure_inf_time += elapsed
            #     if (i + 1) % log_interval == 0:
            #         fps = (i + 1 - num_warmup) / pure_inf_time
            #         print(
            #             f'Done image [{i + 1:<3}/ {max_iter}], '
            #             f'fps: {fps:.1f} img / s, '
            #             f'times per image: {1000 / fps:.1f} ms / img',
            #             flush=True)

            # if (i + 1) == max_iter:
            #     fps = (i + 1 - num_warmup) / pure_inf_time
            #     print(
            #         f'Overall fps: {fps:.1f} img / s, '
            #         f'times per image: {1000 / fps:.1f} ms / img',
            #         flush=True)
            #     break
