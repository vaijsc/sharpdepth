import os
import cv2
import argparse

def combine_images(image1, image2):
    """
    Combine two images side by side. Adjust this function to change the combination method.
    """
    return cv2.hconcat([image1, image2])

def create_video(folder1, folder2, output_path, fps=30):
    """
    Create a video by combining images from two folders.

    Args:
        folder1 (str): Path to the first folder.
        folder2 (str): Path to the second folder.
        output_path (str): Path to save the output video.
        fps (int): Frames per second for the video.
    """
    # Get the list of image files and sort them naturally (numerical order)
    def natural_sort_key(filename):
        return [int(part) if part.isdigit() else part for part in re.split(r'(\d+)', filename)]

    images1 = sorted([f for f in os.listdir(folder1) if f.endswith(('png', 'jpg', 'jpeg'))], key=natural_sort_key)
    images2 = sorted([f for f in os.listdir(folder2) if f.endswith(('png', 'jpg', 'jpeg'))], key=natural_sort_key)

    if len(images1) != len(images2):
        raise ValueError("The folders do not contain the same number of images.")

    # Read the first image to get dimensions
    first_image1 = cv2.imread(os.path.join(folder1, images1[0]))
    first_image2 = cv2.imread(os.path.join(folder2, images2[0]))

    if first_image1 is None or first_image2 is None:
        raise ValueError("One of the first images could not be loaded.")

    combined_image = combine_images(first_image1, first_image2)
    height, width, _ = combined_image.shape

    # Define the codec and create VideoWriter object
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    for img1_name, img2_name in zip(images1, images2):
        img1_path = os.path.join(folder1, img1_name)
        img2_path = os.path.join(folder2, img2_name)

        img1 = cv2.imread(img1_path)
        img2 = cv2.imread(img2_path)

        if img1 is None or img2 is None:
            print(f"Skipping {img1_name} or {img2_name} as one of them could not be loaded.")
            continue

        combined_image = combine_images(img1, img2)
        out.write(combined_image)

    out.release()
    print(f"Video saved at {output_path}")

if __name__ == "__main__":
    import re
    parser = argparse.ArgumentParser(description="Combine images from two folders into a video.")
    parser.add_argument("folder1", type=str, help="Path to the first folder containing images.")
    parser.add_argument("folder2", type=str, help="Path to the second folder containing images.")
    parser.add_argument("output", type=str, help="Output path for the video.")
    parser.add_argument("--fps", type=int, default=30, help="Frames per second for the video.")

    args = parser.parse_args()

    create_video(args.folder1, args.folder2, args.output, args.fps)