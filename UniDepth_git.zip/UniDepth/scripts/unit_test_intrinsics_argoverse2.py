
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import cv2
import numpy as np
import pandas as pd
from pyarrow import feather
from upath import UPath


def read_feather(
    path: PathType, columns: Optional[Tuple[str, ...]] = None
) -> pd.DataFrame:
    """Read Apache Feather data from a .feather file.

    AV2 uses .feather to serialize much of its data. This function handles the deserialization
    process and returns a `pandas` DataFrame with rows corresponding to the records and the
    columns corresponding to the record attributes.

    Args:
        path: Source data file (e.g., 'lidar.feather', 'calibration.feather', etc.)
        columns: Tuple of columns to load for the given record. Defaults to None.

    Returns:
        (N,len(columns)) Apache Feather data represented as a `pandas` DataFrame.
    """
    with path.open("rb") as file_handle:
        dataframe: pd.DataFrame = feather.read_feather(
            file_handle, columns=columns, memory_map=True
        )
    return dataframe

if __name__ == "__main__":
    pass