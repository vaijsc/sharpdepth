import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from unidepth.models import UniDepthV1, UniDepthV2
from unidepth.utils import colorize, image_grid
from scripts.colmap_loaders import *
import glob
import cv2

import matplotlib.pyplot as plt
from torchvision.transforms import Resize
from PIL import Image
import imageio
import depth_pro

def infer_images(frame, model, transform):
    image = transform(frame)

    # Run inference.
    prediction = model.infer(image.to(device))
    depth = prediction["depth"].cpu().numpy()  # Depth in [m].
    return depth

if __name__ == "__main__":
    print("Torch version:", torch.__version__)
    name = "unidepth-v2-vitl14"

    # model = UniDepthV1.from_pretrained("lpiccinelli/unidepth-v1-vitl14")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # model = model.to(device)
    model, transform = depth_pro.create_model_and_transforms()
    model.eval().to(device)

    ## Load Video ##
    # Create a VideoCapture object and read from input file
    # cap = cv2.VideoCapture('assets/demo/100.mp4')

    # # Check if camera opened successfully
    # if (cap.isOpened()== False):
    #     print("Error opening video file")

    # Read until video is completed
    i = 0

    

    reader = imageio.get_reader('assets/demo/100.mp4')

    for frame_number, frame in enumerate(reader):            
        ## Save images ##
        # frame_save = Image.fromarray(frame).save(f'assets/demo/svm/images/{i}.jpg')
        
        ### ###
        frame_ul = frame[0:frame.shape[0]//2, 0:frame.shape[1]//2]
        frame_dl = frame[frame.shape[0]//2:frame.shape[0], 0:frame.shape[1]//2]
        frame_ur = frame[0:frame.shape[0]//2, frame.shape[1]//2:frame.shape[1]]
        frame_dr = frame[frame.shape[0]//2:frame.shape[0], frame.shape[1]//2:frame.shape[1]]

        depth_ul = colorize(infer_images(frame_ul, model, transform), vmin=0, vmax=10)
        depth_dl = colorize(infer_images(frame_dl, model, transform), vmin=0, vmax=10)
        depth_ur = colorize(infer_images(frame_ur, model, transform), vmin=0, vmax=10)
        depth_dr = colorize(infer_images(frame_dr, model, transform), vmin=0, vmax=10)
        
        # rgb_torch = torch.from_numpy(frame_ul).to(device).permute(2,0,1)
        # predictions = model.infer(rgb_torch)
        # depth_pred = predictions["depth"].squeeze().cpu().numpy()
        # breakpoint()

        im_u = cv2.hconcat([depth_ul, depth_ur]) 
        im_d = cv2.hconcat([depth_dl, depth_dr]) 
        im_f = cv2.vconcat([im_u, im_d])
        frame_save = Image.fromarray(im_f).save(f'assets/demo/svm/depthpro/{i}.jpg')

        i+=1

    # When everything done, release
    # the video capture object
    # cap.release()
