import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from scripts.util.image_util import (
                                            chw2hwc,
                                            colorize_depth_maps,
                                            get_tv_resample_method,
                                            resize_max_res,
                                        )


from PIL import Image
import cv2
from transformers import pipeline
from transformers import AutoImageProcessor, ZoeDepthForDepthEstimation
import matplotlib.pyplot as plt

if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    repo = "isl-org/ZoeDepth"
    model_zoe_nk = torch.hub.load(repo, "ZoeD_NK", pretrained=False)
    
    pretrained_dict = torch.hub.load_state_dict_from_url('/root/data_hai/diffusion/hub/checkpoints/ZoeD_M12_NK.pt', map_location='cpu')
    model_zoe_nk.load_state_dict(pretrained_dict['model'], strict=False)
    for b in model_zoe_nk.core.core.pretrained.model.blocks:
        b.drop_path = torch.nn.Identity()

    model_zoe_nk.to(device)

    dataset_config = '/root/data_hai/diffusion/Marigold/config/dataset/data_arkit_train.yaml'
    base_data_dir = '/root/data_hai/diffusion/data'
    output_dir = '/root/data_hai/diffusion/unidepth_exp/eval/zoedepth/arkit/train'
    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.EVAL
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=4)

    # dataset._get_data_item(0)

    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            # Save predictions
            rgb_filename = batch["rgb_relative_path"][0]
            rgb_basename = os.path.basename(rgb_filename)
            scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
            if not os.path.exists(scene_dir):
                os.makedirs(scene_dir)
            pred_basename = get_pred_name(
                rgb_basename, dataset.name_mode, suffix=".npy"
            )
            save_to = os.path.join(scene_dir, pred_basename)
            if os.path.exists(save_to):
                logging.warning(f"Existing file: '{save_to}' will be overwritten")
                continue

            # Read input image
            rgb_origin = batch["rgb_int"].squeeze().permute(1,2,0).numpy().astype(np.uint8)
            pil = Image.fromarray(rgb_origin)
            depth_numpy = model_zoe_nk.infer_pil(pil)  # as numpy

            np.save(save_to, depth_numpy)

            plt.figure(figsize=(8,8))
            plt.imshow(1/depth_numpy)
            plt.axis('off')
            plt.savefig('temp_ar_zoe.jpg')
