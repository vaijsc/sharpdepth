import argparse
import logging
import os

import numpy as np
import torch
from omegaconf import OmegaConf
from PIL import Image
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from scripts.dataset import (
    BaseDepthDataset,
    DatasetMode,
    get_dataset,
    get_pred_name,
)

from PIL import Image

from unidepth.models import UniDepthV1, UniDepthV2
from unidepth.utils import colorize, image_grid
from scripts.colmap_loaders import *

from mmseg.apis import inference_model, init_model, show_result_pyplot
import mmcv


def rmse_linear(output, target, valid_mask=None):
    actual_output = output
    actual_target = target
    diff = actual_output - actual_target
    if valid_mask is not None:
        diff[~valid_mask] = 0
        n = valid_mask.sum((-1, -2))
    else:
        n = output.shape[-1] * output.shape[-2]
    diff2 = torch.pow(diff, 2)
    mse = torch.sum(diff2, (-1, -2)) / n
    rmse = torch.sqrt(mse)
    return rmse.mean()


if __name__ == "__main__":
    print("Torch version:", torch.__version__)
    name = "unidepth-v2-vitl14"
    model = UniDepthV1.from_pretrained("lpiccinelli/unidepth-v1-vitl14")
    # model = UniDepthV2.from_pretrained(f"lpiccinelli/{name}")

    # set resolution level (only V2)
    # model.resolution_level = 0

    # set interpolation mode (only V2)
    # model.interpolation_mode = "bilinear"

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    ## Sky Segmenter ##
    config_file = '../mmsegmentation/configs/segformer/segformer_mit-b4_8xb1-160k_cityscapes-1024x1024.py'
    checkpoint_file = '../data/segformer_mit-b4_8x1_1024x1024_160k_cityscapes_20211207_080709-07f6c333.pth'
    # build the model from a config file and a checkpoint file
    sky_model = init_model(config_file, checkpoint_file, device='cuda')


    dataset_config = '/home/ubuntu/Working/diffusion/Marigold/config/dataset/data_argoverse_train.yaml'
    base_data_dir = '/home/ubuntu/Working/diffusion/data'
    output_dir = '/home/ubuntu/Working/diffusion/unidepth_exp/eval/unidepthv1_with_intrinsics/argoverse2/prediction'
    # -------------------- Data --------------------
    cfg_data = OmegaConf.load(dataset_config)

    dataset: BaseDepthDataset = get_dataset(
        cfg_data, base_data_dir=base_data_dir, mode=DatasetMode.RGB_ONLY
    )

    dataloader = DataLoader(dataset, batch_size=1, num_workers=4)

    # dataset._get_data_item(0)

    with torch.no_grad():
        for batch in tqdm(
            dataloader, desc=f"Inferencing on {dataset.disp_name}", leave=True
        ):
            # Read input image
            rgb = batch["rgb_int"].squeeze().numpy().astype(np.uint8)
            rgb_torch = torch.from_numpy(rgb)
            
            rgb_filename = batch["rgb_relative_path"][0]
            rgb_basename = os.path.basename(rgb_filename)
            scene_dir = os.path.join(output_dir, os.path.dirname(rgb_filename))
            if not os.path.exists(scene_dir):
                os.makedirs(scene_dir)
            pred_basename = get_pred_name(
                rgb_basename, dataset.name_mode, suffix=".npy"
            )
            sky_basename = get_pred_name(
                rgb_basename, dataset.name_mode, suffix="_sky.npy"
            )

            save_to = os.path.join(scene_dir, pred_basename)
            save_to_sky = os.path.join(scene_dir, sky_basename)
            if os.path.exists(save_to):
                logging.warning(f"Existing file: '{save_to}' will be overwritten")
                continue

            data_path = batch['rgb_relative_path'][0]
            parts = data_path.split('/')

            intrinsics = batch["intrinsics"]
            predictions = model.infer(rgb_torch, intrinsics)
            depth_pred = predictions["depth"].squeeze().cpu().numpy()

            rgb_int = np.moveaxis(rgb, 0, -1)  # [H, W, 3]
            seg_results = inference_model(sky_model, mmcv.imread(rgb_int))
            sky_mask = seg_results.pred_sem_seg.data.squeeze(0).cpu().numpy()

            # show_result_pyplot(sky_model, mmcv.imread(rgb_int), seg_results, show=False, out_file='result.jpg', opacity=0.5)

            np.save(save_to, depth_pred)
            np.save(save_to_sky, sky_mask)
