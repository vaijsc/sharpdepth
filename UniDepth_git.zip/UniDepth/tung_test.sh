export TORCH_HOME=/lustre/scratch/client/scratch/research/group/khoigroup/haipd13/diffusion
export PYTHONPATH="$(dirname $0)/..":$PYTHONPATH 

python scripts/demo_sintel_zoedepth.py
# '1.0.11'