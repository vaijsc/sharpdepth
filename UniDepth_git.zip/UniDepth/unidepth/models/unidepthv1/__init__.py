from .unidepthv1 import UniDepthV1

__all__ = [
    "UniDepthV1",
]
