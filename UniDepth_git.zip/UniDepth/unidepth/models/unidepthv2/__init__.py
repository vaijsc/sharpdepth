from .unidepthv2 import UniDepthV2

__all__ = [
    "UniDepthV2",
]
